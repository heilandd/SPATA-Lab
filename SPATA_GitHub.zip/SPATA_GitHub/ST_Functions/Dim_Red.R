
TSNE_Genes_DHH=function(genes,matrix=ds@assays$RNA@counts, 
                        tsne=ds@reductions$tsne@cell.embeddings, 
                        alpha=0.2,pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=2)(100),
                        cex=1){
  plot_score_map=function(x=1:10,coordinates=c(4.5, 5, 0.8, 1),z_scored=T, cex=0.8, overlay=F, pal=pal){
    
    if(z_scored==T){max=1;min=-1}else{max=max(x);min=min(x)}
    val=round(seq(min(x), max(x), length.out = 5), digits = 1)
    
    
    #plot(NA,axes=F,xlab="", ylab="", bty="n", xlim=c(1,10), ylim=c(0,length(pal)+2))
    pal= colorRampPalette(pal)(50)
    
    length_x=as.numeric((coordinates[2]-coordinates[1])/4)
    length_y=as.numeric((coordinates[4]-coordinates[3])/50)
    for(i in 1:length(pal)){
      
      polygon(x=c(coordinates[1], coordinates[1]+length_x),y=c(coordinates[3]+i*length_y, coordinates[3]+i*length_y),lwd=4,border = pal[i])
      
    }
    x_task= coordinates[1]+length_x*1.3
    arrows(x_task,coordinates[3], x_task, coordinates[4]+length_y*5, length = length_x/10)
    xx=seq(coordinates[3],coordinates[4],length.out = 5)
    for ( i in 1: length(xx)){
      polygon(x=c(x_task,x_task+length_x*0.6), y=c(xx[i],xx[i] ),lwd=0.5, border = "black")
      text(x=c(x_task+length_x*2.5), y=xx[i], labels = val[i], cex=0.8)
    }
    
    text(x=x_task, y=coordinates[4]+length_y*10, labels = "Z-Score", cex=cex)
    
  }
  
  genes=genes[ genes %in% rownames(matrix)]
  
  par(mar=c(5,5,5,5), las=2)
  
  if(length(genes)>=2){
    
    getedges=c(min(as.matrix(tsne)[,1]), max(as.matrix(tsne)[,1]),min(as.matrix(tsne)[,2]), max(as.matrix(tsne)[,2]) )
    
    dif=max(getedges)+abs(min(getedges))
    
    scale_p=dif/3
    
    
    out_genes=log2(colMeans(matrix[genes, ])+1)
    col=map2color(out_genes, pal)
    plot(x=as.matrix(tsne),type="n", main="Set of Genes", axes=F, xlab="", ylab="",
         xlim = c(min(getedges)-scale_p,max(getedges)+scale_p),
         ylim = c(min(getedges)-scale_p,max(getedges)+scale_p)
    )
    
    points(as.matrix(tsne), col=alpha(col,alpha),pch=16,cex=cex)
    
    
    ad_scale=scale_p/2
    
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1], getedges[3], length = 0.1)
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1]-ad_scale, getedges[3]+ad_scale, length = 0.1)
    text(getedges[1]-ad_scale/2, getedges[3]-ad_scale/2, labels = "UMAP1")
    text(getedges[1]-ad_scale/0.7, getedges[3]+ad_scale/2, labels = "UMAP2", srt=90)
    
    #Add 
    plot_score_map(x=seq(min(out_genes), max(out_genes), length.out = 10), coordinates=c(getedges[2]+ad_scale/2,getedges[2]+ad_scale,getedges[4]-ad_scale*2,getedges[4]), pal = pal)
    
    
    
  } 
  if(length(genes)==1){
    
    getedges=c(min(as.matrix(tsne)[,1]), max(as.matrix(tsne)[,1]),min(as.matrix(tsne)[,2]), max(as.matrix(tsne)[,2]) )
    
    dif=max(getedges)+abs(min(getedges))
    
    scale_p=dif/3
    
    out_genes=log2((matrix[genes, ])+1)
    col=map2color(out_genes, pal)
    plot(x=as.matrix(tsne),type="n", main=genes, axes=F, xlab="", ylab="",
         xlim = c(min(getedges)-scale_p,max(getedges)+scale_p),
         ylim = c(min(getedges)-scale_p,max(getedges)+scale_p)
    )
    points(as.matrix(tsne), col=alpha(col,alpha),pch=16,cex=cex) 
    
    ad_scale=scale_p/2
    
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1], getedges[3], length = 0.08)
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1]-ad_scale, getedges[3]+ad_scale, length = 0.08)
    text(getedges[1]-ad_scale/2, getedges[3]-ad_scale/2, labels = "UMAP1")
    text(getedges[1]-ad_scale/0.7, getedges[3]+ad_scale/2, labels = "UMAP2", srt=90)
    
    #Add 
    plot_score_map(x=seq(min(out_genes), max(out_genes), length.out = 10), coordinates=c(getedges[2]+ad_scale/2,getedges[2]+ad_scale,getedges[4]-ad_scale*2,getedges[4]), pal = pal)
    
    
  }
  else{print("Gene not Listed")}
  #plot_score_map(as.matrix(ds@reductions$tsne@cell.embeddings),coordinates=c(1,1),z_scored=T, overlay=F, pal=inferno(100))
  
}

TSNE_GeneSets_DHH=function(TestSet= "Neftel_NPC_Comb",
                           GeneSetinput=object@Usesed_GeneSetsets,
                           matrix=ds@assays$RNA@counts,
                           tsne=ds@reductions$tsne@cell.embeddings, 
                           alpha=0.2,pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=2)(100),
                           cex=1){
  plot_score_map=function(x=1:10,coordinates=c(4.5, 5, 0.8, 1),z_scored=T, cex=0.8, overlay=F, pal=pal){
    
    if(z_scored==T){max=1;min=-1}else{max=max(x);min=min(x)}
    val=round(seq(min(x), max(x), length.out = 5), digits = 1)
    
    
    #plot(NA,axes=F,xlab="", ylab="", bty="n", xlim=c(1,10), ylim=c(0,length(pal)+2))
    pal= colorRampPalette(pal)(50)
    
    length_x=as.numeric((coordinates[2]-coordinates[1])/4)
    length_y=as.numeric((coordinates[4]-coordinates[3])/50)
    for(i in 1:length(pal)){
      
      polygon(x=c(coordinates[1], coordinates[1]+length_x),y=c(coordinates[3]+i*length_y, coordinates[3]+i*length_y),lwd=4,border = pal[i])
      
    }
    x_task= coordinates[1]+length_x*1.3
    arrows(x_task,coordinates[3], x_task, coordinates[4]+length_y*5, length = length_x/10)
    xx=seq(coordinates[3],coordinates[4],length.out = 5)
    for ( i in 1: length(xx)){
      polygon(x=c(x_task,x_task+length_x*0.6), y=c(xx[i],xx[i] ),lwd=0.5, border = "black")
      text(x=c(x_task+length_x*2.5), y=xx[i], labels = val[i], cex=0.8)
    }
    
    text(x=x_task, y=coordinates[4]+length_y*10, labels = "Z-Score", cex=cex)
    
  }
  
  GeneSets=GeneSetinput
  genes=GeneSets[GeneSets$ont==TestSet,]$gene
  genes=genes[ genes %in% rownames(matrix)]
  
  print(genes)
  
  par(mar=c(5,5,5,5), las=2)
  
  if(length(genes)>=2){
    
    getedges=c(min(as.matrix(tsne)[,1]), max(as.matrix(tsne)[,1]),min(as.matrix(tsne)[,2]), max(as.matrix(tsne)[,2]) )
    
    dif=max(getedges)+abs(min(getedges))
    
    scale_p=dif/3
    
    
    out_genes=log2(colMeans(matrix[genes, ])+1)
    col=map2color(out_genes, pal)
    plot(x=as.matrix(tsne),type="n", main=GeneSet, axes=F, xlab="", ylab="",
         xlim = c(min(getedges)-scale_p,max(getedges)+scale_p),
         ylim = c(min(getedges)-scale_p,max(getedges)+scale_p)
    )
    
    points(as.matrix(tsne), col=alpha(col,alpha),pch=16,cex=cex)
    
    
    ad_scale=scale_p/2
    
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1], getedges[3], length = 0.1)
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1]-ad_scale, getedges[3]+ad_scale, length = 0.1)
    text(getedges[1]-ad_scale/2, getedges[3]-ad_scale/2, labels = "UMAP1")
    text(getedges[1]-ad_scale/0.7, getedges[3]+ad_scale/2, labels = "UMAP2", srt=90)
    
    #Add 
    plot_score_map(x=seq(min(out_genes), max(out_genes), length.out = 10), coordinates=c(getedges[2]+ad_scale/2,getedges[2]+ad_scale,getedges[4]-ad_scale*2,getedges[4]), pal = pal)
    
    
    
  } 
  if(length(genes)==1){
    
    getedges=c(min(as.matrix(tsne)[,1]), max(as.matrix(tsne)[,1]),min(as.matrix(tsne)[,2]), max(as.matrix(tsne)[,2]) )
    
    dif=max(getedges)+abs(min(getedges))
    
    scale_p=dif/3
    
    out_genes=log2((matrix[genes, ])+1)
    col=map2color(out_genes, pal)
    plot(x=as.matrix(tsne),type="n", main=genes, axes=F, xlab="", ylab="",
         xlim = c(min(getedges)-scale_p,max(getedges)+scale_p),
         ylim = c(min(getedges)-scale_p,max(getedges)+scale_p)
    )
    points(as.matrix(tsne), col=alpha(col,alpha),pch=16,cex=cex) 
    
    ad_scale=scale_p/2
    
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1], getedges[3], length = 0.08)
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1]-ad_scale, getedges[3]+ad_scale, length = 0.08)
    text(getedges[1]-ad_scale/2, getedges[3]-ad_scale/2, labels = "UMAP1")
    text(getedges[1]-ad_scale/0.7, getedges[3]+ad_scale/2, labels = "UMAP2", srt=90)
    
    #Add 
    plot_score_map(x=seq(min(out_genes), max(out_genes), length.out = 10), coordinates=c(getedges[2]+ad_scale/2,getedges[2]+ad_scale,getedges[4]-ad_scale*2,getedges[4]), pal = pal)
    
    
  }
  else{print("Gene not Listed")}
  #plot_score_map(as.matrix(ds@reductions$tsne@cell.embeddings),coordinates=c(1,1),z_scored=T, overlay=F, pal=inferno(100))
  
}


TSNE_Groups_DHH=function(groups="seurat_clusters",
                         f_data_inp=object@seuratobject@meta.data, 
                         tsne=ds@reductions$tsne@cell.embeddings, 
                         alpha=0.2,
                         pal=brewer.pal(9, "Set1"),
                         cex=1){
  
  if(is.null(f_data_inp[,groups])) stop ("Group not in Seurat Object")
  getedges=c(min(as.matrix(tsne)[,1]), max(as.matrix(tsne)[,1]),min(as.matrix(tsne)[,2]), max(as.matrix(tsne)[,2]) )
  dif=max(getedges)+abs(min(getedges))
  scale_p=dif/3
  
  
  
  col=map2color(f_data_inp[,groups], pal)
  plot(x=as.matrix(tsne),type="n", main=groups, axes=F, xlab="", ylab="",
       xlim = c(min(getedges)-scale_p,max(getedges)+scale_p),
       ylim = c(min(getedges)-scale_p,max(getedges)+scale_p)
  )
  
  points(as.matrix(tsne), col=alpha(col[[1]],alpha),pch=16,cex=cex)
  
  
  ad_scale=scale_p/2
  
  arrows(getedges[1]-ad_scale, getedges[3], getedges[1], getedges[3], length = 0.1)
  arrows(getedges[1]-ad_scale, getedges[3], getedges[1]-ad_scale, getedges[3]+ad_scale, length = 0.1)
  text(getedges[1]-ad_scale/2, getedges[3]-ad_scale/2, labels = "UMAP1")
  text(getedges[1]-ad_scale/0.7, getedges[3]+ad_scale/2, labels = "UMAP2", srt=90)
  col[[2]]=col[[2]][order(col[[2]]$Terms), ]
  #Add 
  for(i in 1:nrow(col[[2]])){
    x=getedges[2]+ad_scale/2
    y=getedges[4]-(ad_scale*4/nrow(col[[2]]))*i
    points(x,y, pch=16, col=col[[2]][i,3])
    text(x=x+x/8, y=y, labels = col[[2]][i,1], cex=cex)
  }
  
  
}
















