#Plot function 
ST_Img_DHH_multiple=function(object,
                    sample_to_print="S4",
                    input=c("MALAT1", "ATAD3C"),
                    modus=c("Cluster", "Genes", "GeneSets")[2],
                    multiple_gene_ST="mean", 
                    TXT=NA,
                    BG=.8,
                    threshold=2,
                    bty="n",
                    cex=0.8,
                    pal=brewer.pal(6, "Reds")){
  
  
  ##----------------------------------------------------------------------------##
  ## Requirements
  ##----------------------------------------------------------------------------##
  Enrich_threshold=2
  
  ### load librarys and required functions
  library(RColorBrewer)
  library(viridis)
  library(scales)
  library(graphics)
  map2color<-function(x,pal,limits=NULL){
    if(class(x)=="numeric"){
      if(is.null(limits)) limits=range(x)
      pal[findInterval(x,seq(limits[1],limits[2],length.out=length(pal)+1), all.inside=TRUE)]
    }else{
      print(x[!duplicated(x)])
      da=data.frame(Terms=x[!duplicated(x)], Nr=seq(1,length.out = length(x[!duplicated(x)])))
      da$col=colorRampPalette(pal)(nrow(da))[da[,2]]
      daf=data.frame(x=x, col=1)
      for(i in 1:length(x)){
        daf[i, ]$col=da[da$Terms==daf[i, "x"], ]$col
        
      }
      
      return(list(daf$col, da))
    }
    
  }
  alpharamp<-function(c1,c2, alpha=128) {stopifnot(alpha>=0 & alpha<=256);function(n) paste(colorRampPalette(c(c1,c2))(n), 
                                                                                            format(as.hexmode(alpha), 
                                                                                                   upper.case=T), sep="")}
  
  
  ##----------------------------------------------------------------------------##
  ## Inputs
  ##----------------------------------------------------------------------------##
  
  data_in_mat= rownames(object@seuratobject@meta.data[object@seuratobject@meta.data$Samples==sample_to_print,  ])
  Coordinate_file=object@fdata[data_in_mat, ]
  ST_gene_matrix=object@seuratobject@assays$RNA@scale.data[, colnames(object@seuratobject@assays$RNA@scale.data)  %in% rownames(Coordinate_file)]
  
  if(is.null(modus)) stop("No Mudus selected")
  if(modus=="Cluster") {
    
    message(" Show Clusters ")
    Coordinate_file_imp=Coordinate_file
    Coordinate_file_imp$X.1=(Coordinate_file$Cluster)
    active_asign="Cluster"
  }else 
    if(modus=="Genes"){
    
    gene=input
    
    if(length(unique(rownames(ST_gene_matrix) %in% gene))!=2) stop ("The gene is not included in your expression matrix")
    gene=rownames(ST_gene_matrix)[rownames(ST_gene_matrix) %in% gene]
    
    #Align gene to ST map
    
    #For single gene
    if(length(gene)==1){
      Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
      ST_gene_matrix=ST_gene_matrix[,as.character(Coordinate_file$header_comb)]
      ncol(ST_gene_matrix)==nrow(Coordinate_file)
      Coordinate_file$X.1=as.numeric(ST_gene_matrix[gene,])
      Coordinate_file_imp=Coordinate_file[Coordinate_file$HE_Slide==2, ]
      Coordinate_file_imp=na.omit(Coordinate_file_imp)
      x=Coordinate_file_imp$X
      y=Coordinate_file_imp$Y
      Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, pal)
    }
    #For multiple genes
    if(length(gene)>1){
      
      if(multiple_gene_ST=="median" | multiple_gene_ST=="max" | multiple_gene_ST=="mean"){message(paste("For multiple_gene_ST", multiple_gene_ST, "was used"))} else stop ("Method for multiple_gene_ST not found use: mean/median or max")
      
      if(multiple_gene_ST=="mean"){
        Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
        Coordinate_file$X.1 = as.numeric(colMeans(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
      }
      if(multiple_gene_ST=="median"){
        if(length(gene)<5){message(paste("If number of tested genes are lower than 5, we recomment to use mean "))}
        Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
        Coordinate_file$X.1 = as.numeric(colMedians(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
      }
      if(multiple_gene_ST=="max"){
        Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
        Coordinate_file$X.1 = as.numeric(colMaxs(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
      }
      
      Coordinate_file_imp=Coordinate_file[Coordinate_file$HE_Slide==2, ]
      Coordinate_file_imp=na.omit(Coordinate_file_imp)
      x=Coordinate_file_imp$X
      y=Coordinate_file_imp$Y
      Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, brewer.pal(9, "Reds"))
    }
    
    active_asign=gene[1]
    
    
  }else 
      if(modus=="GeneSets"){
    
    if(length(input)>1){
      
      out_mGS=as.data.frame(do.call(cbind,lapply(1:length(input), function(i){
        gene=object@Usesed_GeneSetsets[object@Usesed_GeneSetsets$ont==input[i], ]$gene
        if(length(unique(rownames(ST_gene_matrix) %in% gene))!=2) stop ("No Gene of the Geneset is in exp matrix")
        gene=rownames(ST_gene_matrix)[rownames(ST_gene_matrix) %in% gene]
        if(length(gene)>1){
          
          if(multiple_gene_ST=="median" | multiple_gene_ST=="max" | multiple_gene_ST=="mean"){message(paste("For multiple_gene_ST", multiple_gene_ST, "was used"))} else stop ("Method for multiple_gene_ST not found use: mean/median or max")
          
          if(multiple_gene_ST=="mean"){
            Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
            Coordinate_file$X.1 = as.numeric(colMeans(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
          }
          if(multiple_gene_ST=="median"){
            if(length(gene)<5){message(paste("If number of tested genes are lower than 5, we recomment to use mean "))}
            Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
            Coordinate_file$X.1 = as.numeric(colMedians(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
          }
          if(multiple_gene_ST=="max"){
            Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
            Coordinate_file$X.1 = as.numeric(colMaxs(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
          }
          
          Coordinate_file_imp=Coordinate_file[Coordinate_file$HE_Slide==2, ]
          Coordinate_file_imp=na.omit(Coordinate_file_imp)
          x=Coordinate_file_imp$X
          y=Coordinate_file_imp$Y
          Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, brewer.pal(9, "Reds"))
        }
        
        return(Coordinate_file_imp$X.1)
        
      })))
      
      
      names(out_mGS)=input
      
      
      for(i in 1:nrow(out_mGS)){
        x=out_mGS[i, ]
        x=(x-min(x))/(max(x)-min(x))
        x=x/sum(x)
        out_mGS[i, ]=x
      }
      
      out_mGS$MAXDS=NA
      for(i in 1:nrow(out_mGS)){
        out_mGS$MAXDS[i]=names(which.max(out_mGS[i,]))
      }
      
      assign("out_mGS", value =out_mGS , envir = globalenv())
      
      
      Coordinate_file_imp=Coordinate_file[Coordinate_file$HE_Slide==2, ]
      Coordinate_file_imp=na.omit(Coordinate_file_imp)
      x=Coordinate_file_imp$X
      y=Coordinate_file_imp$Y
      Coordinate_file_imp$X.1=out_mGS$MAXDS
      Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, brewer.pal(length(input), "Set1"))[[1]]
    
    }else{
      gene=object@Usesed_GeneSetsets[object@Usesed_GeneSetsets$ont==input, ]$gene
      if(length(unique(rownames(ST_gene_matrix) %in% gene))!=2) stop ("No Gene of the Geneset is in exp matrix")
      gene=rownames(ST_gene_matrix)[rownames(ST_gene_matrix) %in% gene]
      if(length(gene)>1){
        
        if(multiple_gene_ST=="median" | multiple_gene_ST=="max" | multiple_gene_ST=="mean"){message(paste("For multiple_gene_ST", multiple_gene_ST, "was used"))} else stop ("Method for multiple_gene_ST not found use: mean/median or max")
        
        if(multiple_gene_ST=="mean"){
          Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
          Coordinate_file$X.1 = as.numeric(colMeans(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
        }
        if(multiple_gene_ST=="median"){
          if(length(gene)<5){message(paste("If number of tested genes are lower than 5, we recomment to use mean "))}
          Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
          Coordinate_file$X.1 = as.numeric(colMedians(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
        }
        if(multiple_gene_ST=="max"){
          Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
          Coordinate_file$X.1 = as.numeric(colMaxs(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
        }
        
        Coordinate_file_imp=Coordinate_file[Coordinate_file$HE_Slide==2, ]
        Coordinate_file_imp=na.omit(Coordinate_file_imp)
        x=Coordinate_file_imp$X
        y=Coordinate_file_imp$Y
        Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, brewer.pal(9, "Reds"))
      }
    }
    
    
    active_asign=input
  }else {(warning("Unknown Modus: Try Cluster or Genes or GeneSets"))}
  
  message(paste0("You selected the modus: ", modus))
  

  #print(head(Coordinate_file_imp,20))

    
    
    if(modus=="GeneSets" & length(input)>1){
      
      #pie plot
      precentage=out_mGS[,1:length(input)]
      precentage=precentage+0.01
      color=brewer.pal(length(input), "Set1")
      
      par(bty=bty, mar=c(5,5,5,5))
      plot(Coordinate_file_imp$x_Slide, Coordinate_file_imp$y_Slide, col=Coordinate_file_imp$col, 
           type="n", cex=cex, axes = F, xlab="", ylab="", xlim = c(0,max(Coordinate_file_imp$x_Slide)+20),
           ylim = c(0,max(Coordinate_file_imp$y_Slide)+20))
      
      for(z in 1:nrow(Coordinate_file_imp)){
        x_cor=Coordinate_file_imp$x_Slide[z]
        y_cor=Coordinate_file_imp$y_Slide[z]
        
        x=as.numeric(precentage[z, ])
        col=color
        
        x <- c(0, cumsum(x)/sum(x))
        dx <- diff(x)
        nx <- length(dx)
        
        radius=0.4
        
        t2xy <- function(t) {
          t2p <- 2 * pi * t + 90 * pi/180
          list(x = radius * cos(t2p), y = radius * sin(t2p))}
        
        for (i in 1L:nx) { 
          n <- max(2, floor(200 * dx[i]))
          P <- t2xy(seq.int(x[i], x[i + 1], length.out = n))
          polygon(
            x=c(P$x, 0)+x_cor, 
            y=c(P$y, 0)+y_cor,
            col=col[i],lwd=0.01)
            
        }
        
        
      }
      
      
      
      
      legende=Coordinate_file_imp[!duplicated(Coordinate_file_imp$X.1), c("X.1", "col" )]
      startx=max(Coordinate_file_imp$x_Slide)+2
      for(i in 1:nrow(legende)){
        points(x=startx, y=max(Coordinate_file_imp$y_Slide)-i*2, pch=16, col=legende$col[i], cex=cex)
        text(x=startx+1, y=max(Coordinate_file_imp$y_Slide)-i*2, labels = legende$X.1[i],cex=cex-0.4, pos = 4)
        }
      
      
      
    } 
    
    
    
    
    
    

  
  return(Coordinate_file_imp)
}
