ST_heatmap_cor=function(object,
                        sample_to_print=c("S3","S4","S5"),
                        order_to_samples=F,
                        modus=c("conturplot", "LinePlot", "Heatmap"),
                        input=c("Neftel_OPClike",  "Neftel_NPC_Comb" , "Neftel_AClike" , "Neftel_Mes_Comb"),
                        geneset_to_order=c("REACTOME_INNATE_IMMUNE_SYSTEM"),
                        span=span,
                        ylim=ylim,
                        BG=.8,
                        threshold=2,
                        bty="n",
                        cex=0.8,
                        bw=0.005,
                        breaks=c(seq(-2,3,length.out = 49)),
                        pal=brewer.pal(6, "Reds")){
  
  
  
  ### load librarys and required functions
  library(RColorBrewer)
  library(viridis)
  library(scales)
  library(graphics)
  library(pheatmap)
  
  get_Col_means_from_GS=function(GS){
    get_genes_from_GS=function(GS){
      return(object@Usesed_GeneSetsets[object@Usesed_GeneSetsets$ont==GS, 2])
    }
    order_v=colMeans(exp_m[rownames(exp_m) %in% get_genes_from_GS(GS), ])
  }
  map2color<-function(x,pal,limits=NULL){
    if(class(x)=="numeric"){
      if(is.null(limits)) limits=range(x)
      pal[findInterval(x,seq(limits[1],limits[2],length.out=length(pal)+1), all.inside=TRUE)]
    }else{
      print(x[!duplicated(x)])
      da=data.frame(Terms=x[!duplicated(x)], Nr=seq(1,length.out = length(x[!duplicated(x)])))
      da$col=colorRampPalette(pal)(nrow(da))[da[,2]]
      daf=data.frame(x=x, col=1)
      for(i in 1:length(x)){
        daf[i, ]$col=da[da$Terms==daf[i, "x"], ]$col
        
      }
      
      return(list(daf$col, da))
    }
    
  }
  
  
  
  ##----------------------------------------------------------------------------##
  ##  Input
  ##----------------------------------------------------------------------------##
  
  
  spots_to_analyze=as.character(rownames(object@seuratobject@meta.data[object@seuratobject@meta.data$Samples %in% sample_to_print, ]))
  
  #Expression matrix
  exp_m=object@seuratobject@assays$RNA@scale.data[,spots_to_analyze]
  
  
  #Order Trajectory
  get_genes_from_GS=function(GS){
    return(object@Usesed_GeneSetsets[object@Usesed_GeneSetsets$ont==GS, 2])
  }
  
  order_v=colMeans(exp_m[rownames(exp_m) %in% get_genes_from_GS(GS=geneset_to_order), ])
  order_v=order_v[order(order_v, decreasing = F)]
  order_names=names(order_v)
    
  message("order done")
  
  ##----------------------------------------------------------------------------##
  ##  Get correlation
  ##----------------------------------------------------------------------------##
  
  if(modus=="conturplot"){
  #Contur plots
  get_Col_means_from_GS=function(GS){
    get_genes_from_GS=function(GS){
      return(object@Usesed_GeneSetsets[object@Usesed_GeneSetsets$ont==GS, 2])
    }
    order_v=colMeans(exp_m[rownames(exp_m) %in% get_genes_from_GS(GS), ])
    }
  
  
  #layout(matrix(1:length(input), round(sqrt(length(input)), digits = 0),  round(sqrt(length(input)), digits = 0)))
  for(i in 1:length(input)){
    
    vectorGS=as.numeric(get_Col_means_from_GS(input[i])[order_names])
    message(input[i])
    
    x <- order_v
    y <- vectorGS
    model <- loess(y~x, span = span )
    loess=predict(model, seq(min(x),max(x),length.out = 150))
    
    smoothScatter(x=log10(seq(min(x),max(x),length.out = 150)+1), y=log10(loess+1), bandwidth=bw, 
                  colramp=colorRampPalette(cividis(50)),
                  nrpoints=0, col="black",pch=16, 
                  axes=F,
                  xlab="", ylab="", main=paste0(input[i], "  R2:", round(cor(order_v,vectorGS), digits = 2)))
    
    f_x=300
    points(x=log10(seq(min(x),max(x),length.out = 150)+1), y=log10(loess+1), type="l", col="black", lty=2, lwd=5)
    points(x=jitter(log10(seq(min(x),max(x),length.out = 150)+1), factor = f_x), 
           y=jitter(log10(loess+1),factor=f_x), pch=16, col="black")
    
    
    
    
    
    message(cor(order_v,vectorGS))
    
    
  }
  }
  
  
  
  if(modus=="LinePlot"){
    #Line plots
  col=map2color(input, brewer.pal(length(input), "Set1"))[[1]]
  for(i in 1:length(input)){
    
    vectorGS=as.numeric(get_Col_means_from_GS(input[i])[order_names])
    message(input[i])
    
    x <- order_v
    y <- vectorGS
    model <- loess(y~x, span = span )
    loess=predict(model, seq(min(x),max(x),length.out = 150))
    
    if(i==1){plot(x=seq(min(x),max(x),length.out = 150), y=loess,ylab="Loess Fit of GenSet Enrichment", 
                  xlab=paste0("GeneSet: ",geneset_to_order ), type="l", col=col[i], bty="n", ylim=ylim)}else{
      
      points(x=seq(min(x),max(x),length.out = 150), y=loess, type="l", col=col[i])}
    
    
    
    message(cor(order_v,vectorGS))
    
    
  }
  legend("topleft", legend=c(as.character(map2color(input, brewer.pal(length(input), "Set1"))[[2]]$Terms)),
         col=c(map2color(input, brewer.pal(length(input), "Set1"))[[2]]$col), lty=1, cex=0.8,
         box.lty=0)
  }
  
  
  
  #heatmaps
  
  if(modus=="Heatmap"){
    
    genes_into_plot=unlist(lapply(1:length(input), function(i) get_genes_from_GS(GS=input[i])))
    genes_into_plot=genes_into_plot[!duplicated(genes_into_plot)]
    

      vectorGS=exp_m[rownames(exp_m) %in% genes_into_plot, order_names]
      mat_loess=matrix(NA, nrow(vectorGS), 1000)
      rownames(mat_loess)=rownames(vectorGS)
      
      for(ii in 1:nrow(mat_loess)){
        x <- order_v
        y <- vectorGS[ii, ]
        model <- loess(y~x, span = span )
        loess=predict(model, seq(min(x),max(x),length.out = 1000))
        mat_loess[ii, ]=loess
      }
      
      heatmaps_inp=mat_loess
      mat_all=heatmaps_inp
    
    message("loess done")
    message("remove duplicates")
    #Align/sort data in order to pseudotome
    
    print(rownames(mat_all)[1:10])
    print(mat_all[1:10,1:10])
    
    print(nrow(mat_all))
    
    order=as.data.frame(do.call(rbind,lapply(1:nrow(mat_all), function(i){
      data.frame(Max=max(mat_all[i,]), ID=as.numeric(which(mat_all[i,]==max(mat_all[i,])))[1])
    })))
    
    print(c(length(rownames(order)), length(rownames(mat_all))))
    
    rownames(order)=rownames(mat_all)
    
    
    
    
    
    message("Alignment Done")
    
    
    order=order[order(order$ID), ]
    
    
    print(order[1:10, ])
    mat_all=mat_all[rownames(order), ]
    
    
    print("Alignment done")
    
    
    
    
    annotation_row=as.data.frame(do.call(rbind,lapply(1:length(input), function(i){
      data.frame(GS=rep(input[i], nrow(mat_all[rownames(mat_all) %in% get_genes_from_GS(GS=input[i]), ])), Gene=rownames(mat_all[rownames(mat_all) %in% get_genes_from_GS(GS=input[i]), ]))
    })))
    annotation_row=annotation_row[!duplicated(annotation_row$Gene), ]
    rownames(annotation_row)=annotation_row$Gene
    
    
    annotation_row=data.frame(GeneSet=annotation_row[rownames(mat_all), "GS"], row.names = rownames(mat_all))
    
    col=map2color(input, brewer.pal(length(input), "Set1"))[[2]]
    colx=as.character(col$col)
    names(colx)=col$Terms
    
    
    options(stringsAsFactors = F)
    ann_colors=list(GeneSet=colx)

    
    
    print("start ploting")
    
    
    pheatmap::pheatmap((as.matrix(mat_all)),
                       cluster_row = F,
                       breaks=breaks,
                       annotation_row=annotation_row,
                       annotation_colors=ann_colors,
                       cluster_cols = F,
                       scale="row",
                       color = viridis(50), 
                       show_colnames=F)
  }
 
  


}





