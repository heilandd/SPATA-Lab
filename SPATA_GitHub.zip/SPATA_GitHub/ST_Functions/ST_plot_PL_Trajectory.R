ST_plot_PL_Trajectory=function(es.max,object,
                            modus=c("spatial", "scRNAseq")[2],
                            ExpR,ExpL, 
                            quantil_test=.8, 
                            Return_vislab=F,
                            plot_model=c("Connectivity Heatmap", "R-L-Interaction", "Connected-Spots-Graph"),
                            theta=3,
                            scale_z=1,
                            pal,
                            select_pat=c("S3", "S4", "S5")[2]){
  
  #required function
  norm_s=function(x){(x-min(x))/(max(x)-min(x))}
  
  if(modus=="spatial"){
    
    message("Start Fitting the Model by using spatial Data")
    #Fit model
    score1=es.max[1,]
    upper=quantile(score1, .995)
    score1[score1>upper]=jitter(rep(upper,length(score1[score1>upper])), factor=upper)
    y1=2-norm_s(score1)
    
    
    upper=quantile(ExpR, .995)
    ExpR[ExpR>upper]=jitter(rep(upper,length(ExpR[ExpR>upper])), factor=upper)
    x1=2-(norm_s(score1))
    
    #print(y1)
    
    message("Finished Fitting Receptor")
    
    score=es.max[2, ]
    upper=quantile(score, .995)
    score[score>upper]=jitter(rep(upper,length(score[score>upper])), factor=upper)
    y2=norm_s(score)
    
    upper=quantile(ExpL, .995)
    ExpL[ExpL>upper]=jitter(rep(upper,length(ExpL[ExpL>upper])), factor=upper)
    x2=(norm_s(score))
    #print(x1)
    message("Finished Fitting the Model by using spatial Data")
    
    #Start ploting
    message("Start Create Plots")
    
    
    
    if(plot_model=="R-L-Interaction"){
      
      scale_f=0.4
      plot(NA,xlim = c(0-scale_f,2+scale_f), ylim=c(0-scale_f,2+scale_f), axes=F, xlab="", ylab="")
      lo <- loess(c(y1,y2) ~ c(x1,x2))
      xl <- seq(0.05, 1.9, length.out = 1000)
      
      
      
      points(c(x1,x2), jitter(predict(lo,c(x1,x2)), factor=900), 
             col=c(map2color(x1, rev(pal)),map2color(x2, (pal)) ), pch=19,
             cex=c(y1-1,rev(y2)+0.3)*2)
      
      points(xl, predict(lo,xl), type="l", lty=2, lwd=1.5, col="black")
      
      #Add scales
      z_point=0
      up_z_point=2
      arrows(z_point,z_point, 1, z_point,  length=0.1) 
      arrows(z_point,z_point, z_point, 1,  length=0.1)
      arrows(up_z_point,up_z_point, 1, up_z_point,  length=0.1) 
      arrows(up_z_point,up_z_point, up_z_point, 1,  length=0.1)
      
      threshold=quantil_test
      
      polygon(x=c(threshold,1+(1-threshold), (1-threshold)+1, threshold ), 
              y=c(threshold,threshold,(1-threshold)+1, (1-threshold)+1), lty=2, lwd=1.5)
      
      #lables
      text(x=z_point+0.4, y=z_point-0.1, labels = "Expression Ligand")
      text(x=z_point-0.1, y=z_point+0.4, labels = "GSVA-Score Induction", srt=90)
      
      text(x=up_z_point-0.4, y=up_z_point+0.1, labels = "Expression Receptor")
      text(x=up_z_point+0.1, y=up_z_point-0.4, labels = "GSVA-Score Activation",srt=90 )
      
      #Show top cells in cluster
      
      #quantil_test=0.8
    }
    
    if(plot_model=="Connected-Spots-Graph"){
      
      plot(x=object@fdata[object@fdata$Sample==select_pat, ]$x_Slide, 
           y=object@fdata[object@fdata$Sample==select_pat, ]$y_Slide, 
           pch=19, col=alpha("black",0.3), bty="n", axes=F, xlab="", ylab="")
      #points(ds@reductions$umap@cell.embeddings[names(ExpL[ExpL>quantile(ExpL,quantil_test)]), ],col="navy", pch=19,cex=0.3 )
      #plot(ds@reductions$umap@cell.embeddings, pch=19, col=alpha("grey", 0.2), bty="n", axes=F, xlab="", ylab="")
      #points(ds@reductions$umap@cell.embeddings[names(ExpR[ExpR>quantile(ExpR,quantil_test)]), ],col="darkgreen", pch=19, cex=0.3 )
      
      #Add connection lines
      
      map=data.frame(x=object@fdata[object@fdata$Sample==select_pat, ]$x_Slide, y=object@fdata[object@fdata$Sample==select_pat, ]$y_Slide)
      rownames(map)=object@fdata[object@fdata$Sample==select_pat, ]$header_comb
      
      
      quantil_test=0.2
      
      #(1) Rank gene set
      ExpL_r=y1[y1<1.8]
      ExpR_r=y2[y2>quantile(y2,quantil_test)]
      
      ExpR_r=ExpR_r[order(ExpR_r)]
      ExpL_r=ExpL_r[order(ExpL_r)]
      
      df_r=data.frame(ExpR_r,QT=ecdf(ExpR_r)(ExpR_r), row.names = names(ExpR_r))
      df_l=data.frame(ExpL_r,QT=ecdf(ExpL_r)(ExpL_r), row.names = names(ExpL_r))
      
      col=alpha(map2color(df_r$QT, pal), 0.7)
      
      df_r=df_r[rownames(df_r) %in% object@fdata[object@fdata$Sample==select_pat, ]$header_comb, ]
      df_l=df_l[rownames(df_l) %in%object@fdata[object@fdata$Sample==select_pat, ]$header_comb,]
      
      
      Coordinate_file_imp=object@fdata
      Coordinate_file_imp$X.1=0
      
      for(i in 1:nrow(df_r)){#Loop for connected lines defined by neares neighbour based on quantil similary
        inp=df_r[i,2]
        x=df_l[,2]
        FROM=rownames(df_r)[i]
        TO=rownames(df_l)[which.min(abs(x - inp))]
        
        start=map[FROM, ]
        end=map[TO, ]
        
        Coordinate_file_imp[FROM, ]$X.1=Coordinate_file_imp[FROM, ]$X.1+1
        Coordinate_file_imp[TO, ]$X.1=Coordinate_file_imp[TO, ]$X.1+1
        
        if(abs(start[1]-end[1])<10 & abs(start[2]-end[2])<10){
          polygon(x=c(start[1], end[1]),y=c(start[2], end[2]),border = col[i], lwd = 4, lty=2)
        }
        
        
        
      }
      
      
      scale_z=scale_z
      
      mat_co=matrix(0, max(Coordinate_file_imp$x_Slide), max(Coordinate_file_imp$y_Slide))
      for(i in 1:nrow(Coordinate_file_imp)){
        mat_co[Coordinate_file_imp$x_Slide[i], Coordinate_file_imp$y_Slide[i] ]=Coordinate_file_imp$X.1[i]+scale_z
      }
      
      out_list=image.smooth(mat_co, theta=theta)
      mat_out=as.matrix(out_list$z)
      mat_out[mat_out<0.5]=NA
      #image(mat_out, col=colorRampPalette(viridis(50))(100), axes=F, xlim=c(-0.5,1.5), ylim=c(-0.5,1.5))
      
      
      
      
      
      
      
      
      
      
      
    }
    
    if(plot_model=="Connectivity Heatmap"){
      
      
      message("Start Create Heatmap")
      #Add connection lines
      
      map=data.frame(x=object@fdata[object@fdata$Sample==select_pat, ]$x_Slide, y=object@fdata[object@fdata$Sample==select_pat, ]$y_Slide)
      rownames(map)=object@fdata[object@fdata$Sample==select_pat, ]$header_comb
      
      
      quantil_test=quantil_test
      
      #(1) Rank gene set
      ExpL_r=y1[y1<1.8]
      ExpR_r=y2[y2>quantile(y2,quantil_test)]
      
      ExpR_r=ExpR_r[order(ExpR_r)]
      ExpL_r=ExpL_r[order(ExpL_r)]
      
      df_r=data.frame(ExpR_r,QT=ecdf(ExpR_r)(ExpR_r), row.names = names(ExpR_r))
      df_l=data.frame(ExpL_r,QT=ecdf(ExpL_r)(ExpL_r), row.names = names(ExpL_r))
      
      col=alpha(map2color(df_r$QT, viridis(50)), 0.7)
      
      df_r=df_r[rownames(df_r) %in% object@fdata[object@fdata$Sample==select_pat, ]$header_comb, ]
      df_l=df_l[rownames(df_l) %in%object@fdata[object@fdata$Sample==select_pat, ]$header_comb,]
      
      
      Coordinate_file_imp=object@fdata
      Coordinate_file_imp$X.1=0
      
      for(i in 1:nrow(df_r)){#Loop for connected lines defined by neares neighbour based on quantil similary
        inp=df_r[i,2]
        x=df_l[,2]
        FROM=rownames(df_r)[i]
        TO=rownames(df_l)[which.min(abs(x - inp))]
        
        start=map[FROM, ]
        end=map[TO, ]
        
        Coordinate_file_imp[FROM, ]$X.1=Coordinate_file_imp[FROM, ]$X.1+1
        Coordinate_file_imp[TO, ]$X.1=Coordinate_file_imp[TO, ]$X.1+1
        
        
        
        
      }
      
      
      scale_z=1
      
      mat_co=matrix(0, max(Coordinate_file_imp$x_Slide), max(Coordinate_file_imp$y_Slide))
      for(i in 1:nrow(Coordinate_file_imp)){
        mat_co[Coordinate_file_imp$x_Slide[i], Coordinate_file_imp$y_Slide[i] ]=Coordinate_file_imp$X.1[i]+scale_z
      }
      
      out_list=image.smooth(mat_co, theta=3)
      mat_out=as.matrix(out_list$z)
      mat_out[mat_out<0.5]=NA
      image(mat_out, col=colorRampPalette(pal)(100), axes=F, xlim=c(-0.5,1.5), ylim=c(-0.5,1.5))
      
      
      message("Finish Create Heatmap")
      
      
      
      
      
      
      
      
    }
    

    
  }
  
}

#ST_plot_PL_Trajectory(es.max,object, modus="spatial",ExpR, ExpL,quantil_test=.8, plot_model="Connectivity Heatmap")


