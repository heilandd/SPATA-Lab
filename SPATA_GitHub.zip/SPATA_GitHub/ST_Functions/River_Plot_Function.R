River_Plot_Function=function(sample,
                             modus,
                             Geneset="NA",
                             genes="NA", plot=T){
  
  
  ########################################
  #Function required
  ########################################
  #coordinates=c(xstart=4.5, xend=5, ystart=0, yend=1)
  plot_score_map=function(x=1:10,coordinates=c(4.5, 5, 0.8, 1),z_scored=T, overlay=F, pal=pal){
    
    if(z_scored==T){max=1;min=-1}else{max=max(x);min=min(x)}
    val=round(seq(min, max, length.out = 5), digits = 1)
    

      #plot(NA,axes=F,xlab="", ylab="", bty="n", xlim=c(1,10), ylim=c(0,length(pal)+2))
      pal= colorRampPalette(pal)(50)
      
      length_x=as.numeric((coordinates[2]-coordinates[1])/4)
      length_y=as.numeric((coordinates[4]-coordinates[3])/50)
      for(i in 1:length(pal)){

        polygon(x=c(coordinates[1], coordinates[1]+length_x),y=c(coordinates[3]+i*length_y, coordinates[3]+i*length_y),lwd=4,border = pal[i])
        
      }
    x_task= coordinates[1]+length_x*1.3
    arrows(x_task,coordinates[3], x_task, coordinates[4]+length_y*5, length = length_x/4)
    xx=seq(coordinates[3],coordinates[4],length.out = 5)
    for ( i in 1: length(xx)){
      polygon(x=c(x_task,x_task+length_x*0.2), y=c(xx[i],xx[i] ),lwd=0.5, border = "black")
      text(x=c(x_task+length_x*2), y=xx[i], labels = val[i], cex=0.8)
    }
    
    text(x=x_task, y=coordinates[4]+length_y*20, labels = "Z-Score")
      
  }
  map2color<-function(x,pal,limits=NULL){
    if(class(x)=="numeric"){
      if(is.null(limits)) limits=range(x)
      pal[findInterval(x,seq(limits[1],limits[2],length.out=length(pal)+1), all.inside=TRUE)]
    }else{
      print(x[!duplicated(x)])
      da=data.frame(Terms=x[!duplicated(x)], Nr=seq(1,length.out = length(x[!duplicated(x)])))
      da$col=colorRampPalette(pal)(nrow(da))[da[,2]]
      daf=data.frame(x=x, col=1)
      for(i in 1:length(x)){
        daf[i, ]$col=da[da$Terms==daf[i, "x"], ]$col
        
      }
      
      return(list(daf$col, da))
    }
    
  }
  require(RColorBrewer)
  require(scales)
  require(dplyr)
  require(viridis)
  
  
  ########################################
  #Define Input
  ########################################
  expr=sample@data@norm_Exp
  if(is.null(expr)) stop("sample@data@norm_Exp is not avaiable in input")
  
  #Load genesets and transforme input to data.frame
  GS=sample@Gene_Sets_used
  GS1=GS %>% filter(GS$ont %in% Geneset) 
  print("##################Here 1")
  
  print(c(Geneset, GS1 ))
  
  if(Geneset[1]!="NA"){
    genes=GS1$gene
  }
  if(genes[1]!="NA"){genes=genes}
  if (Geneset[1]=="NA" & genes[1]=="NA" ){stop("genes and modus is NA")}
  
  print(genes)
  
  print("############## Here ")
  #genes=sample@Gene_Sets_used[sample@Gene_Sets_used=="KEGG_OXIDATIVE_PHOSPHORYLATION", "gene"]
  
  ########################################
  #Start plot
  ########################################
  
  
  
  nr_plots=length(c(levels(sample@fdata[,modus])))+1
  nr_con=length(c(levels(sample@fdata[,modus])))
  cond=c(levels(sample@fdata[,modus]))
  
  print("##################Here 1")
  
  if(plot==T){plot(NA, xlim=c(-0.5,nr_plots+1), ylim=c(-0.2,1.2), bty="n", ylab="", xlab="", axes=F)}
  
  #Get mean Expression of groups
  heat=as.data.frame(do.call(cbind, lapply(1:nr_con, function(i){
    sample_x=as.character(sample@fdata[as.character(sample@fdata[,modus])==cond[i], "Sample"])
    heat_1=data.frame(rowMeans(expr[,sample_x]))
    names(heat_1)=cond[i]
    return(heat_1)
  } )))
  
  #Start plot heatmaps
  q=nrow(heat)
  x_size=0.2
  y_size=1/q 
  gene_order=lapply(1:nr_con, function(ii){
    w=data.frame(heat[order(heat[,ii], decreasing = T), ii , drop = F])
    w$rank=1:nrow(w)
    w$col=map2color(w[,1], pal=viridis(50))
    if(plot==T){
    for(i in 1:q){
      polygon(y=c(y_size*i,y_size*i) , x=c((ii),(ii)+x_size), border= w$col[i])
    }
    }
    return(w)
  })
  
  ranks_1=gene_order[[1]][,"rank", drop=F]
  for(i in 2:nr_con){
    ranks_1=cbind(ranks_1, gene_order[[i]][rownames(ranks_1),"rank", drop=F])
    
    
  }
  
  colors_1=gene_order[[1]][,"col", drop=F]
  for(i in 2:nr_con){
    colors_1=cbind(colors_1, gene_order[[i]][rownames(colors_1),"col", drop=F])
    
    
  }
  
  
  ranks_1=ranks_1[rownames(ranks_1) %in% genes, ]
  colors_1=colors_1[rownames(colors_1) %in% genes,]
  if(ncol(ranks_1)>2){
    mat_plot=as.data.frame(do.call(rbind, lapply(1:nrow(ranks_1), function(i){
      inp_loess=data.frame(y=as.numeric(ranks_1[i, ]), x=1:ncol(ranks_1))
      col=unlist(lapply(2:ncol(ranks_1),function(cc){ colorRampPalette(c(colors_1[i,cc-1],colors_1[i,cc]) )(50)}))
      
      inp_loess$x=inp_loess$x+0.1
      inp_loess$y=inp_loess$y/q
      
      model <- loess(y~x,inp_loess , span = 1 )
      loess=predict(model, seq(1,ncol(ranks_1),length.out = 150))
      loess[is.na(loess)]=loess[6]
      if(plot==T){
        points(y=loess, x=seq(1,ncol(ranks_1),length.out = 150),type = "l",lwd=2, col=scales::alpha(col, 0.6) )
      }
      return(loess)
      
      
      
      
      
      
    })))
  } else{
    mat_plot=as.data.frame(do.call(rbind, lapply(1:nrow(ranks_1), function(i){
      if(plot==T){
        points(y=as.numeric(ranks_1[i,1:ncol(ranks_1)])/q, x=c(1+x_size, 2+x_size ),type = "l",lwd=2, col=scales::alpha(col, 0.6) )
      }
      #return(loess)
      
      
      
      
      
      
    })))
  }
  
  rownames(mat_plot)=rownames(ranks_1)
  
  if(plot==T){
  ##Add Text
  for(i in 1:nr_con){
    text(x=i+0.2, y=1+0.1, labels = cond[i], cex=1, srt=45)
  }
  
  #Add Genes
  pos_genes_y=seq(0,1, length.out = nrow(ranks_1) )
  
  text(y=pos_genes_y, x=c(0.2), labels = rownames(ranks_1), cex=0.5)
  for(i in 1:length(pos_genes_y)){
    polygon(y=c(pos_genes_y[i],ranks_1[i,1]/q ), x=c(0.2, 1), lwd=0.1)
  }
  
  x=c(4.5,4.5)
  y=c(0,1)
  arrows(x[1], y[1], x[1+1], y[1+1],length = 0.1,code=3, lwd=2)
  text(x=4.5, y=c(-0.02), labels ="Expression high" , cex=0.5)
  text(x=4.5, y=c(1.02), labels ="Expression low" , cex=0.5)
  
  plot_score_map(x=1:10,coordinates=c(5, 5.5, 0.8, 1),overlay=T, pal=viridis(50) )
  }
  return(mat_plot)
}













