Plot_Enrichment=function(object){ message("Check quality and print summary")
  
  #check if used is defined
  if(ncol(object@data@used)>0){mat=object@data@used}else{mat=object@data@counts}
  dim(mat)
  
  ### plot basic data per slite
  
  #data for Table
  dat_tab=matrix(1:6, 3,2)
  dat_tab[1,1]=max(colSums(mat))
  dat_tab[2,1]=min(colSums(mat))
  dat_tab[3,1]=round(mean(colSums(mat)),digits = 2)
  dat_tab[1,2]=max(rowSums(mat))
  dat_tab[2,2]=min(rowSums(mat))
  dat_tab[3,2]=round(mean(rowSums(mat)),digits = 2)
  
  
  require(plotly)
  
  
  #print table 
  plot_ly(
    type = 'table',
    header = list(
      values = c("<b>Features</b>", "<b>Max Counts</b>","<b>Min Counts</b>","<b>Mean Counts</b>"),
      align = c('left', rep('center', 3)),
      line = list(width = 1, color = 'black'),
      fill = list(color = "lightblue"),
      font = list(family = "Helvetica", size = 14, color = "black")
    ),
    
    cells = list(
      values = rbind(
        c("Counts per Spot", "Counts per Gene"), 
        dat_tab
      ),
      
      align = c('left', rep('center', 3)),
      line = list(color = "black", width = 1),
      fill = list(color = c('lightblue', 'lightgrey')),
      font = list(family = "Helvetica", size = 12, color = c("black"))
      
    ))
  
  #print scatter plots 
  layout(matrix(1:4,2,2))
  par(mar=c(5,5,5,5), las=1, cex=0.6, pch=19)
  require(viridis)
  plot(rev(sort(rowSums(mat))), col=map2color(rev(sort(rowSums(mat))), pal=viridis(20)), xlab="Counts per Gene", ylab="Frequence")
  plot(rev(sort(colSums(mat))), col=map2color(rev(sort(colSums(mat))), pal=viridis(20)), xlab="Counts per Spot", ylab="Frequence")
  
  par(mar=c(1,1,1,1))
  #UMI per spot
  ST_Img_DHH(Coordinate_file=object@fdata, 
             plot_overlay=T, 
             POINTS_only=T,
             plot_genes=F, 
             Enrichment_DF=NA,
             Enrichment_DF_col=1,
             Enrich_threshold=4,
             ST_gene_matrix=mat, 
             multiple_gene_ST="mean", 
             TXT=NA,
             gene="QC", 
             BG=.8,
             threshold=0,
             bty="n",
             cex=0.8,
             pal=viridis(5))
  
  
  
  ST_Img_DHH(Coordinate_file=object@fdata, 
             plot_overlay=T, 
             POINTS_only=F,
             plot_genes=F, 
             Enrichment_DF=NA,
             Enrichment_DF_col=1,
             Enrich_threshold=4,
             ST_gene_matrix=mat, 
             multiple_gene_ST="mean", 
             TXT=NA,
             gene=as.character(names(rev(rowSums(mat)))[1]), 
             BG=.8,
             threshold=0,
             bty="n",
             cex=0.8,
             pal=viridis(5))
  
}