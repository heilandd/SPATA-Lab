#Plot function 
ST_Img_DHH_surface_multiple=function(object,
                    sample_to_print="S4",
                    input=c("Neftel_OPClike","Neftel_NPC_Comb"),
                    modus=c("Cluster", "Genes", "GeneSets")[3],
                    multiple_gene_ST="mean", 
                    TXT=NA,
                    scale_z=0.8,
                    theta=1.5,
                    BG=.8,
                    threshold=2,
                    bty="n",
                    cex=0.8,
                    pal=brewer.pal(6, "Reds")){
  
  
  ##----------------------------------------------------------------------------##
  ## Requirements
  ##----------------------------------------------------------------------------##
  
  
  ### load librarys and required functions
  library(RColorBrewer)
  library(viridis)
  library(scales)
  library(graphics)
  library(plotly)
  map2color<-function(x,pal,limits=NULL){
    if(class(x)=="numeric"){
      if(is.null(limits)) limits=range(x)
      pal[findInterval(x,seq(limits[1],limits[2],length.out=length(pal)+1), all.inside=TRUE)]
    }else{
      print(x[!duplicated(x)])
      da=data.frame(Terms=x[!duplicated(x)], Nr=seq(1,length.out = length(x[!duplicated(x)])))
      da$col=colorRampPalette(pal)(nrow(da))[da[,2]]
      daf=data.frame(x=x, col=1)
      for(i in 1:length(x)){
        daf[i, ]$col=da[da$Terms==daf[i, "x"], ]$col
        
      }
      
      return(list(daf$col, da))
    }
    
  }
  alpharamp<-function(c1,c2, alpha=128) {stopifnot(alpha>=0 & alpha<=256);function(n) paste(colorRampPalette(c(c1,c2))(n), 
                                                                                            format(as.hexmode(alpha), 
                                                                                                   upper.case=T), sep="")}
  
  
  ##----------------------------------------------------------------------------##
  ## Inputs
  ##----------------------------------------------------------------------------##
  
  data_in_mat= rownames(object@seuratobject@meta.data[object@seuratobject@meta.data$Samples==sample_to_print,  ])
  Coordinate_file=object@fdata[data_in_mat, ]
  ST_gene_matrix=object@seuratobject@assays$RNA@scale.data[, colnames(object@seuratobject@assays$RNA@scale.data)  %in% rownames(Coordinate_file)]
  
  if(is.null(modus)) stop("No Mudus selected")
  if(modus=="Cluster") {
    
    message(" Show Clusters ")
    Coordinate_file_imp=Coordinate_file
    Coordinate_file_imp$X.1=(Coordinate_file$Cluster)
    active_asign="Cluster"
  }else 
    if(modus=="Genes"){
    
    gene=input
    
    if(length(unique(rownames(ST_gene_matrix) %in% gene))!=2) stop ("The gene is not included in your expression matrix")
    gene=rownames(ST_gene_matrix)[rownames(ST_gene_matrix) %in% gene]
    
    #Align gene to ST map
    
    #For single gene
    if(length(gene)==1){
      Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
      ST_gene_matrix=ST_gene_matrix[,as.character(Coordinate_file$header_comb)]
      ncol(ST_gene_matrix)==nrow(Coordinate_file)
      Coordinate_file$X.1=as.numeric(ST_gene_matrix[gene,])
      Coordinate_file_imp=Coordinate_file[Coordinate_file$HE_Slide==2, ]
      Coordinate_file_imp=na.omit(Coordinate_file_imp)
      x=Coordinate_file_imp$X
      y=Coordinate_file_imp$Y
      Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, pal)
    }
    #For multiple genes
    if(length(gene)>1){
      
      if(multiple_gene_ST=="median" | multiple_gene_ST=="max" | multiple_gene_ST=="mean"){message(paste("For multiple_gene_ST", multiple_gene_ST, "was used"))} else stop ("Method for multiple_gene_ST not found use: mean/median or max")
      
      if(multiple_gene_ST=="mean"){
        Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
        Coordinate_file$X.1 = as.numeric(colMeans(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
      }
      if(multiple_gene_ST=="median"){
        if(length(gene)<5){message(paste("If number of tested genes are lower than 5, we recomment to use mean "))}
        Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
        Coordinate_file$X.1 = as.numeric(colMedians(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
      }
      if(multiple_gene_ST=="max"){
        Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
        Coordinate_file$X.1 = as.numeric(colMaxs(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
      }
      
      Coordinate_file_imp=Coordinate_file[Coordinate_file$HE_Slide==2, ]
      Coordinate_file_imp=na.omit(Coordinate_file_imp)
      x=Coordinate_file_imp$X
      y=Coordinate_file_imp$Y
      Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, brewer.pal(9, "Reds"))
    }
    
    active_asign=gene[1]
    
    
  }else 
      if(modus=="GeneSets"){
    
    
      out_mGS=lapply(1:length(input), function(i){
        gene=object@Usesed_GeneSetsets[object@Usesed_GeneSetsets$ont==input[i], ]$gene
        if(length(unique(rownames(ST_gene_matrix) %in% gene))!=2) stop ("No Gene of the Geneset is in exp matrix")
        gene=rownames(ST_gene_matrix)[rownames(ST_gene_matrix) %in% gene]
        if(length(gene)>1){
          
          if(multiple_gene_ST=="median" | multiple_gene_ST=="max" | multiple_gene_ST=="mean"){message(paste("For multiple_gene_ST", multiple_gene_ST, "was used"))} else stop ("Method for multiple_gene_ST not found use: mean/median or max")
          
          if(multiple_gene_ST=="mean"){
            Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
            Coordinate_file$X.1 = as.numeric(colMeans(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
          }
          if(multiple_gene_ST=="median"){
            if(length(gene)<5){message(paste("If number of tested genes are lower than 5, we recomment to use mean "))}
            Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
            Coordinate_file$X.1 = as.numeric(colMedians(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
          }
          if(multiple_gene_ST=="max"){
            Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
            Coordinate_file$X.1 = as.numeric(colMaxs(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
          }
          
          Coordinate_file_imp=Coordinate_file[Coordinate_file$HE_Slide==2, ]
          Coordinate_file_imp=na.omit(Coordinate_file_imp)
          x=Coordinate_file_imp$X
          y=Coordinate_file_imp$Y
          Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, brewer.pal(9, "Reds"))
        }
        
        return(Coordinate_file_imp$X.1)
        
      })
      
      gene=object@Usesed_GeneSetsets[object@Usesed_GeneSetsets$ont==input[1], ]$gene
      if(length(unique(rownames(ST_gene_matrix) %in% gene))!=2) stop ("No Gene of the Geneset is in exp matrix")
      gene=rownames(ST_gene_matrix)[rownames(ST_gene_matrix) %in% gene]
      if(length(gene)>1){
        
        if(multiple_gene_ST=="median" | multiple_gene_ST=="max" | multiple_gene_ST=="mean"){message(paste("For multiple_gene_ST", multiple_gene_ST, "was used"))} else stop ("Method for multiple_gene_ST not found use: mean/median or max")
        
        if(multiple_gene_ST=="mean"){
          Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
          Coordinate_file$X.1 = as.numeric(colMeans(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
        }
        if(multiple_gene_ST=="median"){
          if(length(gene)<5){message(paste("If number of tested genes are lower than 5, we recomment to use mean "))}
          Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
          Coordinate_file$X.1 = as.numeric(colMedians(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
        }
        if(multiple_gene_ST=="max"){
          Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
          Coordinate_file$X.1 = as.numeric(colMaxs(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
        }
        
        Coordinate_file_imp=Coordinate_file[Coordinate_file$HE_Slide==2, ]
        Coordinate_file_imp=na.omit(Coordinate_file_imp)
        x=Coordinate_file_imp$X
        y=Coordinate_file_imp$Y
        Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, brewer.pal(9, "Reds"))
      }
   
    
    
    active_asign=input
    
    
  }else {(warning("Unknown Modus: Try Cluster or Genes or GeneSets"))}
  
  message(paste0("You selected the modus: ", modus))
  

  #print(head(Coordinate_file_imp,20))
  if(modus=="Cluster"){
    Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, pal)
  }else{
    
    
    if(length(Coordinate_file_imp[Coordinate_file_imp$X.1>Enrich_threshold, ]$X.1)>1){Coordinate_file_imp[Coordinate_file_imp$X.1>Enrich_threshold, ]$X.1=Enrich_threshold}
    if(length(Coordinate_file_imp[Coordinate_file_imp$X.1<c(-Enrich_threshold), ]$X.1)>1){Coordinate_file_imp[Coordinate_file_imp$X.1<c(-Enrich_threshold), ]$X.1=c(-Enrich_threshold)}
    
    
    Coordinate_file_imp$col=map2color(as.numeric(Coordinate_file_imp$X.1), pal)}
  
  #theta=0.75
  #scale_z=0.8

    #Add diffuse background with a limit of expressio 
  #create a matrix from the Coordinate_file_imp
  mat_out=lapply(1:length(input), function(i){
    mat_co=matrix(0, max(Coordinate_file_imp$x_Slide), max(Coordinate_file_imp$y_Slide))
    for(ii in 1:nrow(Coordinate_file_imp)){
      mat_co[Coordinate_file_imp$x_Slide[ii], Coordinate_file_imp$y_Slide[ii] ]=out_mGS[[i]][ii]+scale_z
    }
    out_list=image.smooth(mat_co, theta=theta)
    mat_out=as.matrix(out_list$z)
    return(mat_out)
  })

  
  
  
  
  
  
  
  
  library(fields)
  library(viridis)
  
  
  print(mat_out)
  
  p=plot_ly(x=out_list$x, y=out_list$y, z =  mat_out[[1]], opacity = 1, colorscale='Reds') %>% 
  add_surface() %>%
  add_surface(x=out_list$x, y=out_list$y, z =  mat_out[[2]], opacity = 0.9, colorscale='Greens', reversescale=T) %>%
    layout(
      scene = list(
        yaxis = list(title = '', showticklabels = FALSE),
        xaxis = list(nticks = 20, title = '', showticklabels = FALSE),
        zaxis = list(nticks = 4, title = '', showticklabels = FALSE),
        aspectratio = list(x = .9, y = .8, z = 0.2)))
  

  
  p
  return(p)
}
















