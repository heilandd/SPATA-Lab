#Plot function 
ST_Img_DHH_surface_classic=function(object,
                    sample_to_print="S4",
                    input=c("MALAT1", "ATAD3C"),
                    modus=c("Cluster", "Genes", "GeneSets")[2],
                    multiple_gene_ST="mean", 
                    TXT=NA,
                    scale_z=1,
                    theta=1.5,
                    BG=.8,
                    threshold=2,
                    bty="n",
                    cex=0.8,
                    Add_polygon=F,
                    pal=brewer.pal(6, "Reds")){
  
  
  ##----------------------------------------------------------------------------##
  ## Requirements
  ##----------------------------------------------------------------------------##
  Enrich_threshold=2
  
  ### load librarys and required functions
  library(RColorBrewer)
  library(viridis)
  library(scales)
  library(graphics)
  map2color<-function(x,pal,limits=NULL){
    if(class(x)=="numeric"){
      if(is.null(limits)) limits=range(x)
      pal[findInterval(x,seq(limits[1],limits[2],length.out=length(pal)+1), all.inside=TRUE)]
    }else{
      print(x[!duplicated(x)])
      da=data.frame(Terms=x[!duplicated(x)], Nr=seq(1,length.out = length(x[!duplicated(x)])))
      da$col=colorRampPalette(pal)(nrow(da))[da[,2]]
      daf=data.frame(x=x, col=1)
      for(i in 1:length(x)){
        daf[i, ]$col=da[da$Terms==daf[i, "x"], ]$col
        
      }
      
      return(list(daf$col, da))
    }
    
  }
  alpharamp<-function(c1,c2, alpha=128) {stopifnot(alpha>=0 & alpha<=256);function(n) paste(colorRampPalette(c(c1,c2))(n), 
                                                                                            format(as.hexmode(alpha), 
                                                                                                   upper.case=T), sep="")}
  
  
  ##----------------------------------------------------------------------------##
  ## Inputs
  ##----------------------------------------------------------------------------##
  
  data_in_mat= rownames(object@seuratobject@meta.data[object@seuratobject@meta.data$Samples==sample_to_print,  ])
  Coordinate_file=object@fdata[data_in_mat, ]
  ST_gene_matrix=object@seuratobject@assays$RNA@scale.data[, colnames(object@seuratobject@assays$RNA@scale.data)  %in% rownames(Coordinate_file)]
  
  if(is.null(modus)) stop("No Mudus selected")
  if(modus=="Cluster") {
    
    message(" Show Clusters ")
    Coordinate_file_imp=Coordinate_file
    Coordinate_file_imp$X.1=(Coordinate_file$Cluster)
    active_asign="Cluster"
  }else 
    if(modus=="Genes"){
    
    gene=input
    
    if(length(unique(rownames(ST_gene_matrix) %in% gene))!=2) stop ("The gene is not included in your expression matrix")
    gene=rownames(ST_gene_matrix)[rownames(ST_gene_matrix) %in% gene]
    
    #Align gene to ST map
    
    #For single gene
    if(length(gene)==1){
      Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
      ST_gene_matrix=ST_gene_matrix[,as.character(Coordinate_file$header_comb)]
      ncol(ST_gene_matrix)==nrow(Coordinate_file)
      Coordinate_file$X.1=as.numeric(ST_gene_matrix[gene,])
      Coordinate_file_imp=Coordinate_file[Coordinate_file$HE_Slide==2, ]
      Coordinate_file_imp=na.omit(Coordinate_file_imp)
      x=Coordinate_file_imp$X
      y=Coordinate_file_imp$Y
      Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, pal)
    }
    #For multiple genes
    if(length(gene)>1){
      
      if(multiple_gene_ST=="median" | multiple_gene_ST=="max" | multiple_gene_ST=="mean"){message(paste("For multiple_gene_ST", multiple_gene_ST, "was used"))} else stop ("Method for multiple_gene_ST not found use: mean/median or max")
      
      if(multiple_gene_ST=="mean"){
        Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
        Coordinate_file$X.1 = as.numeric(colMeans(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
      }
      if(multiple_gene_ST=="median"){
        if(length(gene)<5){message(paste("If number of tested genes are lower than 5, we recomment to use mean "))}
        Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
        Coordinate_file$X.1 = as.numeric(colMedians(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
      }
      if(multiple_gene_ST=="max"){
        Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
        Coordinate_file$X.1 = as.numeric(colMaxs(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
      }
      
      Coordinate_file_imp=Coordinate_file[Coordinate_file$HE_Slide==2, ]
      Coordinate_file_imp=na.omit(Coordinate_file_imp)
      x=Coordinate_file_imp$X
      y=Coordinate_file_imp$Y
      Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, brewer.pal(9, "Reds"))
    }
    
    active_asign=gene[1]
    
    
  }else 
      if(modus=="GeneSets"){
    
    
    gene=object@Usesed_GeneSetsets[object@Usesed_GeneSetsets$ont==input, ]$gene
    if(length(unique(rownames(ST_gene_matrix) %in% gene))!=2) stop ("No Gene of the Geneset is in exp matrix")
    gene=rownames(ST_gene_matrix)[rownames(ST_gene_matrix) %in% gene]
    if(length(gene)>1){
      
      if(multiple_gene_ST=="median" | multiple_gene_ST=="max" | multiple_gene_ST=="mean"){message(paste("For multiple_gene_ST", multiple_gene_ST, "was used"))} else stop ("Method for multiple_gene_ST not found use: mean/median or max")
      
      if(multiple_gene_ST=="mean"){
        Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
        Coordinate_file$X.1 = as.numeric(colMeans(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
      }
      if(multiple_gene_ST=="median"){
        if(length(gene)<5){message(paste("If number of tested genes are lower than 5, we recomment to use mean "))}
        Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
        Coordinate_file$X.1 = as.numeric(colMedians(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
      }
      if(multiple_gene_ST=="max"){
        Coordinate_file=as.data.frame(Coordinate_file[Coordinate_file$header_comb %in% colnames(ST_gene_matrix), ])
        Coordinate_file$X.1 = as.numeric(colMaxs(ST_gene_matrix[rownames(ST_gene_matrix) %in% gene,]))
      }
      
      Coordinate_file_imp=Coordinate_file[Coordinate_file$HE_Slide==2, ]
      Coordinate_file_imp=na.omit(Coordinate_file_imp)
      x=Coordinate_file_imp$X
      y=Coordinate_file_imp$Y
      Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, brewer.pal(9, "Reds"))
    }
    active_asign=input
  }else {(warning("Unknown Modus: Try Cluster or Genes or GeneSets"))}
  
  message(paste0("You selected the modus: ", modus))
  

  #print(head(Coordinate_file_imp,20))
  if(modus=="Cluster"){
    Coordinate_file_imp$col=map2color(Coordinate_file_imp$X.1, pal)
  }else{
    
    
    if(length(Coordinate_file_imp[Coordinate_file_imp$X.1>Enrich_threshold, ]$X.1)>1){Coordinate_file_imp[Coordinate_file_imp$X.1>Enrich_threshold, ]$X.1=Enrich_threshold}
    if(length(Coordinate_file_imp[Coordinate_file_imp$X.1<c(-Enrich_threshold), ]$X.1)>1){Coordinate_file_imp[Coordinate_file_imp$X.1<c(-Enrich_threshold), ]$X.1=c(-Enrich_threshold)}
    
    
    Coordinate_file_imp$col=map2color(as.numeric(Coordinate_file_imp$X.1), pal)}
  
  

    #Add diffuse background with a limit of expressio 
  #create a matrix from the Coordinate_file_imp
  
  mat_co=matrix(0, max(Coordinate_file_imp$x_Slide), max(Coordinate_file_imp$y_Slide))
  for(i in 1:nrow(Coordinate_file_imp)){
    mat_co[Coordinate_file_imp$x_Slide[i], Coordinate_file_imp$y_Slide[i] ]=Coordinate_file_imp$X.1[i]+scale_z
  }
  
  
  library(fields)
  library(viridis)
  #image(mat_co)
  plot.new()
  #polygon around
  poly_forw=as.data.frame(do.call(rbind,lapply(1:ncol(mat_co), function(i){
    x=which(mat_co[,i ]!=0)[1]-0.7
    y=i
    data.frame(X=x, Y=y)
  })))
  
  #smooth polygon
  smooth=loess(poly_forw$X~poly_forw$Y, span=0.25)
  X=predict(smooth, seq(min(poly_forw$Y), max(poly_forw$Y), length.out = 1000))
  Y=seq(min(poly_forw$Y), max(poly_forw$Y), length.out = 1000)
  polygon(X,Y)
  
  #plot(poly_forw$X, poly_forw$Y)
  #points(X,Y)
  
  smooth_forw=data.frame(X=X, Y=Y)
  
  
  poly_rev=as.data.frame(do.call(rbind,lapply(ncol(mat_co):1, function(i){
    print(i)
    if(length(which(mat_co[,i ]!=0))==0){x=NA}else{
      x=which(mat_co[,i ]!=0)[length(which(mat_co[,i ]!=0))]+0.7
    }
    
    y=i
    data.frame(X=x, Y=y)
  })))
  
  #smooth polygon
  smooth=loess(poly_rev$X~poly_rev$Y, span=0.25)
  X=predict(smooth, seq(min(poly_rev$Y), max(poly_rev$Y), length.out = 1000))
  Y=seq(min(poly_rev$Y), max(poly_rev$Y), length.out = 1000)
  polygon(X,Y)
  
  #plot(poly_rev$X, poly_rev$Y)
  #points(X,Y)
  
  smooth_rev=data.frame(X=X, Y=Y)
  smooth_rev$Y=rev(smooth_rev$Y)
  
  
  
  
  
  
  poly_forw=rbind(smooth_forw, smooth_rev)
  
  poly_forw=na.omit(poly_forw)
  poly_forw=poly_forw/ncol(mat_co)
 
  
  
  out_list=image.smooth(mat_co, theta=theta)
  mat_out=as.matrix(out_list$z)
  mat_out[mat_out<0.5]=NA
  image(mat_out, col=colorRampPalette(pal)(100), axes=F, xlim=c(-0.5,1.5), ylim=c(-0.5,1.5))
  if(Add_polygon==T){polygon(x=poly_forw$X, y=poly_forw$Y, lty=2, border = "black", lwd=1)}
  
  legend(x=c(-0.2), y=c(1.2),legend=input, xjust=0.5)
  
  
}
















