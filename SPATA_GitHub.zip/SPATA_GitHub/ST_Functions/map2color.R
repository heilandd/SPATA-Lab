map2color<-function(x,pal,limits=NULL){
  if(class(x)=="numeric"){
    if(is.null(limits)) limits=range(x)
    pal[findInterval(x,seq(limits[1],limits[2],length.out=length(pal)+1), all.inside=TRUE)]
  }else{
    print(x[!duplicated(x)])
    da=data.frame(Terms=x[!duplicated(x)], Nr=seq(1,length.out = length(x[!duplicated(x)])))
    da$col=colorRampPalette(pal)(nrow(da))[da[,2]]
    daf=data.frame(x=x, col=1)
    for(i in 1:length(x)){
      daf[i, ]$col=da[da$Terms==daf[i, "x"], ]$col
      
    }
    
    return(list(daf$col, da))
  }
  
}