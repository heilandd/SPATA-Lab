Trajectory_State_3D=function(sample, Geneset_m,
                          xscale=10,
                          yscale=1, 
                          cex=1.5,
                          col_samples="NA",
                          pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=1)(10), 
                          genes="NA",
                          signature="NA",
                          Plot=T,
                          cex_GS=0.2,
                          coordinates=NA)
{
  
  
  print("############## Start plotly :::::::: ''''''''''''''''''''''###############################")
  ########################################
  #Function required
  ########################################
  map2color<-function(x,pal,limits=NULL){
    if(class(x)=="numeric"){
      if(is.null(limits)) limits=range(x)
      pal[findInterval(x,seq(limits[1],limits[2],length.out=length(pal)+1), all.inside=TRUE)]
    }else{
      print(x[!duplicated(x)])
      da=data.frame(Terms=x[!duplicated(x)], Nr=seq(1,length.out = length(x[!duplicated(x)])))
      da$col=colorRampPalette(pal)(nrow(da))[da[,2]]
      daf=data.frame(x=x, col=1)
      for(i in 1:length(x)){
        daf[i, ]$col=da[da$Terms==daf[i, "x"], ]$col
        
      }
      
      return(list(daf$col, da))
    }
    
  }
  require(RColorBrewer)
  require(scales)
  require(dplyr)
  require(viridis)
  ########################################
  #Define Input
  ########################################
  expr=sample@data@norm_Exp
  if(is.null(expr)) stop("sample@data@norm_Exp is not avaiable in input")
  
  #Load genesets and transforme input to data.frame
  GS=sample@Gene_Sets_used
  GS1=GS %>% filter(GS$ont %in% Geneset_m) 
  
  
  geneSets=lapply(1:6, function(i){GS1[GS1$ont==Geneset_m[i], "gene" ]})
  names(geneSets)=Geneset_m
  
  
  print(signature)
  if(!is.na(signature)){
    geneSets_signature=lapply(1, function(i){GS[GS$ont==signature, "gene" ]})
    names(geneSets_signature)=signature
    geneSets=c(geneSets,geneSets_signature)
  }
  
  
  
  
  #Use GSVA to get enrichment Scores for each sample 
  gs_out=GSVA::gsva(expr, geneSets, mx.diff=1)
  print(gs_out)
  
  #Normalize Score 
  normalize_DHH=function(x){(x-min(x))/(max(x)-min(x))}
  #for(i in 1:ncol(gs_out)){gs_out[,i]=normalize_DHH(gs_out[,i])}
  nrx=t(gs_out)
  
  print(signature)
  #Set color
  if(signature[1]!="NA"){color_set=map2color( nrx[,signature], pal )}
  if(genes[1]!="NA"){color_set=map2color( expr[rownames(expr) %in% genes, ], pal )}
  if(col_samples[1]!="NA"){color_set=as.character(map2color( sample@fdata[,col_samples], brewer.pal(9,"Set1") )[[1]])}
  if (signature[1]=="NA" & genes[1]=="NA" & col_samples=="NA"){color_set=c(rep("black", nrow(nrx)))}
  print(color_set)
  
  #xscale=1.2
  
  print(nrx)
  print("############## Start plotly 2 :::::::: ''''''''''''''''''''''###############################")

    
    mat_coordinates=matrix(NA, nrow(nrx), 3)
    colnames(mat_coordinates)=c("x", "y", "z")
    
    for(i in 1:nrow(nrx)){
      #print(nrx$col[i])
      nr=as.numeric(nrx[i,1:6 ])
      #define fetal vs. adult y axis
      y_a=nr[2]-nr[1]
      if(y_a>0){y=as.numeric(log2(abs(y_a)))}
      if(y_a<0){y=as.numeric(-log2(abs(y_a)))}
      
      print(y_a)
      
      #define A1 vs. A2 y axis
      y_a_X=nr[4]-nr[3]
      if(y_a_X>0){x=as.numeric(log2(abs(y_a_X)))}
      if(y_a_X<0){x=as.numeric(-log2(abs(y_a_X)))}
      
      print(y_a_X)
      
      #define A1 vs. A2 y axis
      y_a_Z=nr[6]-nr[5]
      if(y_a_Z>0){z=as.numeric(log2(abs(y_a_Z)))}
      if(y_a_Z<0){z=as.numeric(-log2(abs(y_a_Z)))}
      
      
      
      print(y_a_Z)
      
      #points(y=y,x=x, col=color_set[i], pch=16,cex=cex)
      mat_coordinates[i, ]=c(x,y,z)
      
    }
    #text(x=(-xscale)+(xscale/2), y=xscale, labels = colnames(nrx)[1], cex=cex_GS )
    #text(x=(xscale)-(xscale/2), y=xscale, labels = colnames(nrx)[2], cex=cex_GS)
    #text(x=(-xscale)+(xscale/2), y=-xscale, labels = colnames(nrx)[3], cex=cex_GS)
    #text(x=(xscale)-(xscale/2), y=-xscale, labels = colnames(nrx)[4], cex=cex_GS)
    
    print(data.frame(mat_coordinates))
    
    
    out_samp=map2color( sample@fdata[,col_samples], brewer.pal(9,"Set1") )[[1]]
    print("############## Start plotly :::::::: ''''''''''''''''''''''###############################")
    plotly::plot_ly(x=~x,
                    y=~y,
                    z=~z, 
                    data=data.frame(mat_coordinates),
                    mode = "markers",
                    color= sample@fdata[,col_samples], 
                    colors=levels(as.factor(out_samp)),
                    type = "scatter3d")  %>% 
      add_markers() %>%
      
      layout(scene = list(xaxis = list(title = 'Trajectory 1'),
                          yaxis = list(title = 'Trajectory 2'),
                          zaxis = list(title = 'Trajectory 3'),
                          aspectmode = "manual", 
                          aspectratio = list(x=xscale, y=xscale, z=xscale))
            )

  
}





