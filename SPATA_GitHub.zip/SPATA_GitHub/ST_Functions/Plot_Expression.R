Plot_Expression=function(object, gene="GFAP", threshold=0, pal=viridis(50), cex=0.1,TXT="TXT"){
  message("Plot Genes in Spatial plot")
  out=ST_Img_DHH(Coordinate_file=object@fdata,
                 Cluster=cluster,
                 plot_clusters=F,
                 plot_overlay=T, 
                 POINTS_only=F,
                 plot_genes=F, 
                 Enrichment_DF=NA,
                 Enrichment_DF_col=1,
                 Enrich_threshold=4,
                 ST_gene_matrix=object@data@used, 
                 multiple_gene_ST="mean", 
                 TXT=TXT,
                 gene=gene,
                 BG=.8,
                 threshold=threshold,
                 bty="n",
                 cex=cex,
                 pal=pal)
  
  return(out)
}