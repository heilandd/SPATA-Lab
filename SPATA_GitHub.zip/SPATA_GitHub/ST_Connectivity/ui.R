
##----------------------------------------------------------------------------##
## UI-Connectivity
##----------------------------------------------------------------------------##

tab_Connectivity <- tabItem(
  tabName = "Connectivity",
  
  fluidRow(
    
    valueBoxOutput("Col", width = 3),
    valueBoxOutput("Basline",width = 3),
    valueBoxOutput("Kernel",width = 3),
    valueBoxOutput("Quantile",width = 3),
    #Selection Box
  ),
  fluidRow(
    
    box(
      width = 4, status = "primary", solidHeader = TRUE,
      title = "Parameters for Connectivity Plot:",
      height="500px",
      #### Checkbox for Groups
      uiOutput("Load_Data"),
      
      withSpinner(uiOutput("PlotSelection")),
      uiOutput("Options"),
  
      
      
    ),
    
    
    #Plot TabBox
    box(
      title = "Connectivity Plots",
      status = "primary", solidHeader = TRUE,
      id="Plots_XX",
      width = 8,
      height="500px",
      downloadLink("downloadplot_Spatial_Plot_Con", "PDF"),
      withSpinner(plotOutput("Spatial_Plot_Con", width = "400px", height = "400px"))
      
    ),
    
    
  ),
  fluidRow(
  box(
    width = 8,
    title = "About Nearest functional connected neighbour (NFCN)",
    helpText("This algorithm identifies the nearest connected cell from a base and a target data set with respect to a defined receptor-ligand pair. More infos: https://github.com/heilandd/NFCN. The Tool was written by Dr. D. H.. Heiland, Microenvironemnet and Immunology Laboratory any questions mailto: dieter.henrik.heiland@uniklinik-freiburg.de") 
  ),
  )
)


