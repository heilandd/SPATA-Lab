##----------------------------------------------------------------------------##
## Server-Connectivity
##----------------------------------------------------------------------------##


##----------------------------------------------------------------------------##
## UiOutputs
##----------------------------------------------------------------------------##

output$PlotSelection <- renderUI({
  selectInput(inputId="PlotSelection", 
              label="Select Type Connectivity Plot:",
              choices = c("Connectivity Heatmap", "R-L-Interaction", "Connected-Spots-Graph"),
              selected= c("Connectivity Heatmap", "R-L-Interaction", "Connected-Spots-Graph")[1],
              multiple = F
  )
})

output$Load_Data <- renderUI({
  fileInput(
    inputId = "Load_Data",
    label = "Select input data from Connections",
    multiple = FALSE,
    accept = c(".RDS"),
    width = '350px',
    buttonLabel = "Browse...",
    placeholder = "No file selected"
  )
})

data_Input=reactive({
  if ( is.null(input[["Load_Data"]]) || is.na(input[["Load_Data"]]) ) {
    out <- readRDS(paste0(folder,"/IL_10.RDS"))
    print("We use non selected DF")
    return(out)
  } else {
    req(input[["Load_Data"]])
    out <- readRDS(input[["Load_Data"]]$datapath)
    return(out)
  }
  
  
  
  
  if(!is.null(input$Load_Data)){out=readRDS("IL_10.RDS")}else{out=readRDS(input$Load_Data)}
  return(input$Load_Data)
})

output$Options=renderUI({
  actionButton("Options", "Options")
})

Patienttoplot<- reactiveValues(data = "S5")
color_pal_new <- reactiveValues(data = "RdYlBu")
Threshold_data <- reactiveValues(data = .8 )
scalex_data <- reactiveValues(data = 1)
Theta_data <- reactiveValues(data = 2)

dataModal <- function(failed = FALSE) {
  modalDialog(
    title = "Option Parameters for Plot",
    
    selectInput(inputId="palx", 
                label="Color Set",
                choices = c("RdYlBu","RdBu", "Reds", "Blues", "Oranges", "Purples","viridis","inferno"),
                selected=color_pal_new$data ,
                multiple = F
    ),
    selectInput(inputId="ID_Select", 
                label="Select Patient",
                choices = c("S3", "S4", "S5"),
                selected= Patienttoplot$data,
                multiple = F
    ),
    
    sliderInput("Thresholdx", "Select Quantile for Connectivity Score:", 0, 1, Threshold_data$data, step=0.01),
    sliderInput("scalex_x", "Baseline Correction:", 0.001, 3, scalex_data$data, step=0.01),
    sliderInput("Thetax", "Kernel:", 0.4, 6, Theta_data$data, step=0.01),
    
    
    footer = tagList(
      modalButton("Cancel"),
      actionButton("ok", "Save Changes")
    )
  )
}

observeEvent(input$Options, {
  showModal(dataModal())
})

observeEvent(input$ok, {
  Patienttoplot$data <- input$ID_Select
  color_pal_new$data <- input$palx
  Threshold_data$data <- input$Thresholdx
  scalex_data$data <- input$scalex_x
  Theta_data$data <- input$Thetax
  removeModal()
  
})

color_pal_x=reactive({
  color_sh=color_pal_new$data
  print(color_sh)
  if(color_sh=="RdYlBu"){pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")))(50)}
  if(color_sh=="inferno"){pal=inferno(50)}
  if(color_sh=="viridis"){pal=viridis(50)}
  if(color_sh=="Blues"){pal=colorRampPalette((brewer.pal(9, "Blues")))(50)}
  if(color_sh=="Reds"){pal=colorRampPalette((brewer.pal(9, "Reds")))(50)}
  if(color_sh=="Oranges"){pal=colorRampPalette((brewer.pal(9, "Oranges")))(50)}
  if(color_sh=="Purples"){pal=colorRampPalette((brewer.pal(9, "Purples")))(50)}
  if(color_sh=="RdBu"){pal=rev(colorRampPalette((brewer.pal(9, "RdBu")))(50))}
  
  return(pal)
})


output$Col <- renderValueBox({
  valueBox(
    value = if (is.null(color_pal_new$data)){
      tags$p("No options Selected",style = "font-size: 40%;")
    }else{ 
      tags$p(paste0(color_pal_new$data), style = "font-size: 60%;")
      
      
      },
    
    subtitle = "Color",
    width = 30,
    color = "purple"
  )
})
output$Basline <- renderValueBox({
  valueBox(
    value = if (is.null(color_pal_new$data)){
      tags$p("No options Selected",style = "font-size: 40%;")
    }else{ 
      tags$p(paste0(scalex_data$data), style = "font-size: 60%;")
      
      
    },
    
    subtitle = "Baseline",
    width = 30,
    color = "green"
  )
})
output$Kernel <- renderValueBox({
  valueBox(
    value = if (is.null(color_pal_new$data)){
      tags$p("No options Selected",style = "font-size: 40%;")
    }else{ 
      tags$p(paste0(Theta_data$data), style = "font-size: 60%;")
      
      
    },
    
    subtitle = "Kernel",
    width = 30,
    color = "blue"
  )
})
output$Quantile <- renderValueBox({
  valueBox(
    value = if (is.null(color_pal_new$data)){
      tags$p("No options Selected",style = "font-size: 40%;")
    }else{ 
      tags$p(paste0(Threshold_data$data*100, "%"), style = "font-size: 60%;")
      
      
    },
    
    subtitle = "Quantile",
    width = 30,
    color = "yellow"
  )
})





##----------------------------------------------------------------------------##
## Functions for Tab
##----------------------------------------------------------------------------##

source(paste0(folder,"/ST_Functions/ST_plot_PL_Trajectory.R"),local = T)


##----------------------------------------------------------------------------##
##  Tab Outputs
##----------------------------------------------------------------------------##
output$Spatial_Plot_Con <- renderPlot({
  print(color_pal_x())
  print(Patienttoplot$data)
  ST_plot_PL_Trajectory(es.max=data_Input()[[1]],
                                 object=sample_data(),
                                 modus="spatial",
                                 ExpR=data_Input()[[2]],
                                 ExpL=data_Input()[[3]],
                                 quantil_test=Threshold_data$data, 
                                 Return_vislab=F,
                                 plot_model=input$PlotSelection,
                                 theta=Theta_data$data,
                                 scale_z=scalex_data$data,
                                pal= color_pal_x(),
                                select_pat=Patienttoplot$data)
})
  




# Downloads of Plots  
output$downloadplot_Spatial_Plot_Con <- downloadHandler(
  filename = "Connectivityplot.pdf",
  content = function(file) {pdf(file, useDingbats = F)
    
    ST_plot_PL_Trajectory(es.max=data_Input()[[1]],
                          object=sample_data(),
                          modus="spatial",
                          ExpR=data_Input()[[2]],
                          ExpL=data_Input()[[3]],
                          quantil_test=Threshold_data$data, 
                          Return_vislab=F,
                          plot_model=input$PlotSelection,
                          theta=Theta_data$data,
                          scale_z=scalex_data$data,
                          pal= color_pal_x(),
                          select_pat=Patienttoplot$data)
    
    
    dev.off()},
  contentType = "application/pdf"
)


