
##----------------------------------------------------------------------------##
## UI-Cor
##----------------------------------------------------------------------------##

tab_Spatial_cor <- tabItem(
  tabName = "Spatial_cor",

  fluidRow(

    
    tags$p("First select parameters of the state plot: Select the four states of interest (pathways)"),
    
    dropdownButton(
      
      inputId = "Options2",
      tags$h2("Options"),
      tags$br(),
      tags$p("Select Paarameter for state plots"),
      
      circle = F, 
      status = "info", 
      icon = icon("gear"), 
      width = "600px",
      tooltip = tooltipOptions(title = "Change Options Plot !"),
      
      #### Checkbox for Groups
      uiOutput("Choice_cor"),
      uiOutput("Modus_Cor"),
      uiOutput("Input_cor"),
      uiOutput("geneset_to_order"),
      uiOutput("span"),
      uiOutput("ylim")
      
    ),
    
    #Plot TabBox
    box(
      title = "Spatial Plots Cor", solidHeader = TRUE,
      id="Plots_GSEA_1_1",
      width = 10, height = "800px",
      uiOutput("render"),
      downloadLink("downloadplot_heatmap_cor", "PDF"),
      plotOutput("Heatmap_cor",height = "700px", width = "600px")
      
    ),
    
    ),
  )


