##----------------------------------------------------------------------------##
## Server-Cor
##----------------------------------------------------------------------------##


##----------------------------------------------------------------------------##
## UiOutputs
##----------------------------------------------------------------------------##
output$Choice_cor <- renderUI({
  selectInput(inputId="Choice_cor", 
              label="Select Sample that was used:",
              choices = c(sample_data()@slices),
              selected= c(sample_data()@slices)[1],
              multiple = T
  )
})


output$Modus_Cor <- renderUI({
  selectInput(inputId="Modus_Cor", 
              label="Select Modus:",
              choices = c("conturplot", "LinePlot", "Heatmap"),
              selected= c("conturplot", "LinePlot", "Heatmap")[3],
              
  )
})


output$Input_cor <- renderUI({
  selectInput(inputId="Input_cor", 
              label="Select Input:",
              choices = unique(sample_data()@Usesed_GeneSetsets$ont),
              selected= unique(sample_data()@Usesed_GeneSetsets$ont)[1:3],
              multiple = T
  )
})

output$geneset_to_order <- renderUI({
  selectInput(inputId="geneset_to_order", 
              label="Select Input GeneSet to order X:",
              choices = unique(sample_data()@Usesed_GeneSetsets$ont),
              selected= unique(sample_data()@Usesed_GeneSetsets$ont)[1],
              multiple = F
  )
})




output$span=renderUI({
  sliderInput("span", "Kernel:", 0.1, 2, 1, step=0.01)
})


output$ylim=renderUI({
    if (input$Modus_Cor=="LinePlot"){sliderInput("ylim", label = h3("Y-Range for Line Plot"), min = -5, 
                max = 5, value = c(0, 1), step=0.01)} else {
                  
                  if (input$Modus_Cor=="conturplot"){sliderInput("ylim", label = h3("smothcolor:"), min = 0.0001, 
                                                                 max = 0.05, 0.005, step=0.0001)} else {
                                                                   
                                                                   if (input$Modus_Cor=="Heatmap"){sliderInput("ylim", label = h3("Breaks"), min = -10, 
                                                                                                               max = 10, value = c(-2, 2), step=0.01)}
                                                                 }
                }
    
   
  
   
  
})


output$render=renderUI({
  actionButton("render", "Render Plot")
})

##----------------------------------------------------------------------------##
## Functions for Tab
##----------------------------------------------------------------------------##
require(dplyr)
require(DESeq2)
source(paste0(folder,"/ST_Functions/ST_heatmap_cor.R"),local = T)


##----------------------------------------------------------------------------##
##  Tab Outputs
##----------------------------------------------------------------------------##

observeEvent(input$render, {
  
output$Heatmap_cor <- renderPlot({
  
  show_modal_spinner(
    spin = "cube-grid",
    color = "firebrick",
    text = "Plot is running ...."
    
  )
  
  if(is.null(input$span)){span_X=c(1)}else{span_X=input$span}
  if(is.null(input$Choice_cor)){Choice_cor=c("S3")}else{Choice_cor=input$Choice_cor}
  if(is.null(input$Modus_Cor)){Modus_Cor=c("Heatmap")}else{Modus_Cor=input$Modus_Cor}
  if(is.null(input$geneset_to_order)){geneset_to_order=c("Neftel_Mes_Comb")}else{geneset_to_order=input$geneset_to_order}
  if(is.null(input$Input_cor)){Input_cor=c("Neftel_AClike")}else{Input_cor=input$Input_cor}
  if(is.null(input$ylim)){ylim_X=c(-2, 2)}else{ylim_X=input$ylim}
  
  
  ST_heatmap_cor(object=sample_data(),
                          sample_to_print=Choice_cor,
                          order_to_samples=F,
                          modus=Modus_Cor,
                          input=Input_cor,
                          geneset_to_order=geneset_to_order,
                          span=span_X,
                          bw=input$ylim,
                          ylim=c(input$ylim),
                          BG=.8,
                          threshold=2,
                          bty="n",
                          cex=0.8,
                          breaks=seq(ylim_X[1], ylim_X[2], length.out = 49),
                          pal=brewer.pal(6, "Reds"))
  
  remove_modal_spinner()
 
})

})



# Downloads of Plots  
output$downloadplot_heatmap_cor <- downloadHandler(
  filename = function() { paste(input$geneset_to_order, '.pdf', sep='') },
  content = function(file) {pdf(file, useDingbats = F)
    show_modal_spinner(
      spin = "cube-grid",
      color = "firebrick",
      text = "Plot is running ...."
      
    )
    
    if(is.null(input$span)){span_X=c(1)}else{span_X=input$span}
    if(is.null(input$Choice_cor)){Choice_cor=c("S3")}else{Choice_cor=input$Choice_cor}
    if(is.null(input$Modus_Cor)){Modus_Cor=c("Heatmap")}else{Modus_Cor=input$Modus_Cor}
    if(is.null(input$geneset_to_order)){geneset_to_order=c("Neftel_Mes_Comb")}else{geneset_to_order=input$geneset_to_order}
    if(is.null(input$Input_cor)){Input_cor=c("Neftel_AClike")}else{Input_cor=input$Input_cor}
    if(is.null(input$ylim)){ylim_X=c(-2, 2)}else{ylim_X=input$ylim}
    
    
    ST_heatmap_cor(object=sample_data(),
                   sample_to_print=Choice_cor,
                   order_to_samples=F,
                   modus=Modus_Cor,
                   input=Input_cor,
                   geneset_to_order=geneset_to_order,
                   span=span_X,
                   bw=input$ylim,
                   ylim=c(input$ylim),
                   BG=.8,
                   threshold=2,
                   bty="n",
                   cex=0.8,
                   breaks=seq(ylim_X[1], ylim_X[2], length.out = 49),
                   pal=brewer.pal(6, "Reds"))
    
    remove_modal_spinner()
    
    dev.off()},
  contentType = "application/pdf"
)


