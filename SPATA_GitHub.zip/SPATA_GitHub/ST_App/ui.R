##----------------------------------------------------------------------------##
## Custom functions.
##----------------------------------------------------------------------------##

##----------------------------------------------------------------------------##
##
##----------------------------------------------------------------------------##

source(paste0(folder,"/ST_Load_data/ui.R"),local = T)
source(paste0(folder,"/ST_DimRed/ui.R"),local = T)
source(paste0(folder,"/ST_Spatial/ui.R"),local = T)
source(paste0(folder,"/ST_State_Plots/ui.R"),local = T)
source(paste0(folder,"/ST_Spatial_cor/ui.R"),local = T)
source(paste0(folder,"/ST_Connectivity/ui.R"),local = T)

##----------------------------------------------------------------------------##
##
##----------------------------------------------------------------------------##
ui <- dashboardPage(
  
  
  
  dashboardHeader(
    title = tags$a(href='http://www.themilolab.com', "MILO Laboratory", style = "color:black")
  ),
  dashboardSidebar(
    tags$head(tags$style(HTML(".content-wrapper {overflow-x: scroll;}"))),
    tags$style(type="text/css",
               ".shiny-output-error { visibility: hidden; }",
               ".shiny-output-error:before { visibility: hidden; }",
               "body{
                    min-height: 611px;
                    height: auto;
                    max-width: 1200px;
                    margin: auto;
                     }"),
    
    sidebarMenu(
      tags$img(src="Sidebar.png", width= '230px'),
      sidebarMenuOutput("sidebar_menu")
    )
  ),
  dashboardBody(
    shinyDashboardThemes(theme = "grey_light"),
    
    tags$script(HTML('$("body").addClass("fixed");')),
    
    tags$head(tags$style(HTML(
      '.myClass { 
                                    font-size: 20px;
                                    line-height: 50px;
                                    text-align: left;
                                    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                                    padding: 0 15px;
                                    overflow: hidden;
                                    color: white;
                                    }'))),
    
    tags$script(HTML('$(document).ready(function() {
                                        $("header").find("nav").append(\'<img src="top.png" width="730px" height="50px"/>\');})')),
    
    tags$head(tags$style(HTML('
                                 /* body */
                                .content-wrapper, .right-side {
                                background-color: #E5E3E3;
                                }
                                
                                /* body */
                                .content-wrapper, .left-side {
                                background-color: #E5E3E3;
                                }
                                
                                /* left Frame  */
                                .skin-blue .left-side, .skin-blue .wrapper {
                                background-color: #E5E3E3;
                                }
                                
                                /* left Frame  */
                                .skin-blue .right-side, .skin-blue .wrapper {
                                background-color: #E5E3E3;
                                }
                                
                                
                                

                                '))),
    
    setBackgroundColor(
      color = c("#E5E3E3"), shinydashboard=T
    ),
    
    tabItems(
      tab_load_data,
      tab_DimRed,
      tab_Spatial,
      tab_State_Plots,
      tab_Spatial_cor,
      tab_Connectivity
 
    )
  )
)

