##----------------------------------------------------------------------------##
##  Server Functions 
##----------------------------------------------------------------------------##

server <- function(input, output, session) {
  
  options(shiny.maxRequestSize=1000*1024^2)
  
  ##--------------------------------------------------------------------------##
  ## Colors
  ##--------------------------------------------------------------------------##
  
  
  ##--------------------------------------------------------------------------##
  ## Central parameters.
  ##--------------------------------------------------------------------------##
  scatter_plot_dot_size <- list(
    min = 1,
    max = 20,
    step = 1,
    default = 5
  )
  
  scatter_plot_alpha <- list(
    min = 0.1,
    max = 1.0,
    step = 0.1,
    default = 1.0
  )
  
  preferences <- reactiveValues(use_webgl = TRUE)
  
  ##--------------------------------------------------------------------------##
  ## Sidebar menu.
  ##--------------------------------------------------------------------------##
  output[["sidebar_menu"]] <- renderMenu({
    sidebarMenu(id = "sidebar",
                menuItem(
                  "Load data", tabName = "loadData",
                  icon = icon("spinner"), selected = TRUE
                ),
                menuItem(
                  "Dimensional Reduction", tabName = "DimRed",
                  icon = icon("brain"), selected = F
                ),
                menuItem(
                  "Spatial Plots", tabName = "Spatial",
                  icon = icon("spa"), selected = F
                ),
                menuItem(
                  "State Plots", tabName = "StatePlots",
                  icon = icon("cloud"), selected = F
                ),
                menuItem(
                  "Spatial Correlation", tabName = "Spatial_cor",
                  icon = icon("chart-area"), selected = F
                ),
                menuItem(
                  "Spatial Connections", tabName = "Connectivity",
                  icon = icon("connectdevelop"), selected = F
                )
                
                

    )
  })

  
  ##--------------------------------------------------------------------------##
  ## Sample data
  ##--------------------------------------------------------------------------##
  sample_data <- reactive({
    if ( is.null(input[["input_file"]]) || is.na(input[["input_file"]]) ) {
      sample_data <- readRDS(paste0(folder,"/Spatial_dataset_1.RDS"))
      print("We use non selected DF")
      return(sample_data)
    } else {
      req(input[["input_file"]])
      sample_data <- readRDS(input[["input_file"]]$datapath)
      print(sample_data@fdata)
      print(sample_data@data@counts[1:4,1:4])
      return(sample_data)
    }
  })
  
  
  ##--------------------------------------------------------------------------##
  ## Tabs.
  ##--------------------------------------------------------------------------##
  source(paste0(folder,"/ST_Load_data/server.R"), local = T)
  source(paste0(folder,"/ST_DimRed/server.R"), local = T)
  source(paste0(folder,"/ST_Spatial/server.R"), local = T)
  source(paste0(folder,"/ST_State_Plots/server.R"), local = T)
  source(paste0(folder,"/ST_Spatial_cor/server.R"), local = T)
  source(paste0(folder,"/ST_Connectivity/server.R"), local = T)
  
}

