

##----------------------------------------------------------------------------##
## Opimize Input all Datasets in a sample description
##----------------------------------------------------------------------------##

#Read in all Cordinate files  (sample 3,4,5)
Coordinate_list=list(
  read.csv("~/Desktop/SpatialTranscriptomics/Fastq/Coordinates_S3.csv", sep=";",stringsAsFactors = F),
  read.csv("~/Desktop/SpatialTranscriptomics/Fastq/Coordinates_S4.csv", sep=";",stringsAsFactors = F),
  read.csv("~/Desktop/SpatialTranscriptomics/Fastq/Coordinates_S5.csv", sep=";",stringsAsFactors = F)
  
);names(Coordinate_list)=c("S3", "S4", "S5")


Gene_matrix_list=list(
  read.csv("~/Desktop/SpatialTranscriptomics/Fastq/S3_stdata_genes.tsv", sep="\t",row.names = 1, stringsAsFactors = F),
  read.csv("~/Desktop/SpatialTranscriptomics/Fastq/S4_stdata_genes.tsv", sep="\t",row.names = 1, stringsAsFactors = F),
  read.csv("~/Desktop/SpatialTranscriptomics/Fastq/S5_stdata_genes.tsv", sep="\t",row.names = 1, stringsAsFactors = F)
);names(Gene_matrix_list)=c("S3", "S4", "S5")

slices=c("S3", "S4", "S5")


##----------------------------------------------------------------------------##
## Merge all Datasets in a sample description
##----------------------------------------------------------------------------##
f_data=as.data.frame(do.call(rbind, lapply(1:length(slices), function(i){
  require(dplyr)
  #summarize sample names and reduce unused Spots in all coordinate files
  f_dat_ip=Coordinate_list[[slices[i]]]
  f_dat_ip=f_dat_ip %>% filter(f_dat_ip$HE_Slide==2)
  f_dat_ip$header_comb=paste0(f_dat_ip$header,"_",slices[i])
  f_dat_ip$Sample=slices[i]
  return(f_dat_ip)
})))

##----------------------------------------------------------------------------##
## Merge Count Matrixes
##----------------------------------------------------------------------------##

Gene_matrix_list[[1]][1:10,1:10]

#look for genes
genes_of_all_data=unlist(lapply(1:length(slices), function(i){names(Gene_matrix_list[[i]])}))
genes_of_all_data=genes_of_all_data[!duplicated(genes_of_all_data)]

#create matrix to input all expression files
count_matrix=as.matrix(do.call(cbind, lapply(1:length(slices), function(i){
  print(paste0("Get samples for Dataset ", slices[i]))
  mat_ip=Gene_matrix_list[[slices[i]]]
  mat_ip[1:10,1:10]
  
  samples_to_get=f_data[f_data$Sample==slices[i], ]$header
  mat_ip=mat_ip[rownames(mat_ip) %in% samples_to_get, ]
  mat_ip[1:10,1:10]
  
  #Remove slots from where are no data avaiable
  remove=f_data[f_data$Sample==slices[i] & f_data$header %in% rownames(mat_ip)==F,  ]$header_comb
  f_data=f_data[!f_data$header_comb %in% remove, ]
  
  
  
  #check if all genes are avaiable
  genes_not_df=genes_of_all_data[genes_of_all_data %in% names(mat_ip)==F]
  
  #Add genes with zero counts
  mat2_ip=matrix(0,nrow(mat_ip), length(genes_not_df))
  rownames(mat2_ip)=rownames(mat_ip);colnames(mat2_ip)=genes_not_df
  mat2_ip[1:10,1:10]
  
  mat_ip=cbind(mat_ip,as.data.frame(mat2_ip))
  mat_ip[1:10,1:10]
  
  #Add new rownames to mat_ip
  mat_ip=mat_ip[rownames(mat_ip) %in% f_data[f_data$Sample==slices[i], ]$header, ]
  mat_ip[1:10,1:10]
  
  rownames(mat_ip)=f_data[f_data$Sample==slices[i], ]$header_comb
  
  mat_ip=t(as.matrix(mat_ip))
  mat_ip=mat_ip[genes_of_all_data, ]
  
  return(mat_ip)
  
})))


##----------------------------------------------------------------------------##
## Create the new class for ST_Lab
##----------------------------------------------------------------------------##


message(" Required functions are loaded ")
#create new class
data_counts=setClass("data_counts", slots = c(counts="matrix", 
                                              norm_Exp = "matrix", 
                                              batch_corrected = "matrix", 
                                              used="matrix"))


ST_Lab<- setClass("ST_Lab", slots = c(fdata = "data.frame",
                                         slices= "character",
                                         data =   "data_counts" ,
                                         seuratobject="Seurat",
                                         Marker_Genes="data.frame",
                                         AutoEncoder="matrix",
                                         UMAP="matrix",
                                         cluster="data.frame",
                                         Marker_genes="data.frame",
                                         GSEA="list",
                                         Usesed_GeneSetsets="data.frame"
))

setMethod("initialize",signature = "ST_Lab", definition = function(.Object, count_matrix, f_data){
  .Object@fdata=f_data
  .Object@data@counts=count_matrix
  return(.Object)
})


#input data to object
object=ST_Lab(count_matrix=count_matrix, f_data = f_data)


##----------------------------------------------------------------------------##
## Create Seurtat Object
##----------------------------------------------------------------------------##

library(Seurat)
library(dplyr)

dat=object@data@counts
dat <- dat[,Matrix::colSums(dat) != 0]
dat <- dat[Matrix::rowSums(dat) != 0, ]


test <- CreateSeuratObject(counts = dat)

test[["percent.mt"]] <- PercentageFeatureSet(test, pattern = "^MT.")
VlnPlot(test, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
test <- NormalizeData(test, normalization.method = "LogNormalize", scale.factor = 1000)
test <- FindVariableFeatures(test, selection.method = "vst", nfeatures = 2000)
#Add samples to meta.data
rownames(object@fdata)=object@fdata$header_comb
test@meta.data$Samples=object@fdata[rownames(test@meta.data), ]$Sample


test <- ScaleData(test, features = rownames(test),vars.to.regress = c("Samples")) #vars.to.regress = c("Samples", "percent.mt")
test <- RunPCA(test, features = VariableFeatures(object = test))
test <- FindNeighbors(test, dims = 1:10)
test <- FindClusters(test, resolution = 0.8)
test <- RunUMAP(test, dims = 1:10, n.components=3, n.neighbors=50)
DimPlot(test, reduction = "umap")
DimPlot(test, reduction = "umap", group.by = "Samples")

#3D plot
library(plotly)

red_df=as.data.frame(test@reductions$umap@cell.embeddings)

p=plot_ly(red_df,x= ~UMAP_1,y= ~UMAP_2, z= ~UMAP_3, color = test@meta.data$seurat_clusters, size=0.5) %>%
        add_markers() %>%
        layout(scene = list(xaxis = list(title = 'UMAP 1'),
                      yaxis = list(title = 'UMAP 2'),
                      zaxis = list(title = 'UMAP 3'),
                      aspectmode = "manual", 
                      aspectratio = list(x=10, y=10, z=10))
  )
p




library(htmlwidgets)

# Save viewer settings (e.g. RStudio viewer pane)
op <- options()

# Set viewer to web browser
options(viewer = NULL)

# Use web browser to save image
p %>% htmlwidgets::onRender(
  "function(el, x) {
  var gd = document.getElementById(el.id); 
  Plotly.downloadImage(gd, {format: 'pdf', width: 10000, height: 10000, filename: 'plot.pdf'});
  }"
)

# Restore viewer to old setting (e.g. RStudio)
options(viewer = op$viewer)








if ( !require(RSelenium) ) {
  install.packages("RSelenium", repos = "https://cloud.r-project.org/")
}

p %>%
  export(file = "filename.svg",
         selenium = RSelenium::rsDriver(browser = "chrome"))



pbmc.markers <- FindAllMarkers(test,  only.pos = TRUE, min.pct = 0.01, logfc.threshold = 0.15)


object@seuratobject=test
object@Marker_Genes=pbmc.markers

#Add the cluster to f_data
object@fdata$Cluster=as.numeric(object@seuratobject@meta.data[rownames(object@fdata), ]$seurat_clusters)+1


TSNE_Genes_DHH=function(genes,matrix=ds@assays$RNA@counts, 
                  tsne=ds@reductions$tsne@cell.embeddings, 
                  alpha=0.2,pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=2)(100),
                  cex=1){
  plot_score_map=function(x=1:10,coordinates=c(4.5, 5, 0.8, 1),z_scored=T, cex=0.8, overlay=F, pal=pal){
    
    if(z_scored==T){max=1;min=-1}else{max=max(x);min=min(x)}
    val=round(seq(min(x), max(x), length.out = 5), digits = 1)
    
    
    #plot(NA,axes=F,xlab="", ylab="", bty="n", xlim=c(1,10), ylim=c(0,length(pal)+2))
    pal= colorRampPalette(pal)(50)
    
    length_x=as.numeric((coordinates[2]-coordinates[1])/4)
    length_y=as.numeric((coordinates[4]-coordinates[3])/50)
    for(i in 1:length(pal)){
      
      polygon(x=c(coordinates[1], coordinates[1]+length_x),y=c(coordinates[3]+i*length_y, coordinates[3]+i*length_y),lwd=4,border = pal[i])
      
    }
    x_task= coordinates[1]+length_x*1.3
    arrows(x_task,coordinates[3], x_task, coordinates[4]+length_y*5, length = length_x/10)
    xx=seq(coordinates[3],coordinates[4],length.out = 5)
    for ( i in 1: length(xx)){
      polygon(x=c(x_task,x_task+length_x*0.6), y=c(xx[i],xx[i] ),lwd=0.5, border = "black")
      text(x=c(x_task+length_x*2.5), y=xx[i], labels = val[i], cex=0.8)
    }
    
    text(x=x_task, y=coordinates[4]+length_y*10, labels = "Z-Score", cex=cex)
    
  }
  
  genes=genes[ genes %in% rownames(matrix)]
  
  par(mar=c(5,5,5,5), las=2)
  
  if(length(genes)>=2){
    
    getedges=c(min(as.matrix(tsne)[,1]), max(as.matrix(tsne)[,1]),min(as.matrix(tsne)[,2]), max(as.matrix(tsne)[,2]) )
    
    dif=max(getedges)+abs(min(getedges))
    
    scale_p=dif/3
    
    
    out_genes=log2(colMeans(matrix[genes, ])+1)
    col=map2color(out_genes, pal)
    plot(x=as.matrix(tsne),type="n", main="Set of Genes", axes=F, xlab="", ylab="",
         xlim = c(min(getedges)-scale_p,max(getedges)+scale_p),
         ylim = c(min(getedges)-scale_p,max(getedges)+scale_p)
    )
    
    points(as.matrix(tsne), col=alpha(col,alpha),pch=16,cex=cex)

    
    ad_scale=scale_p/2
    
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1], getedges[3], length = 0.1)
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1]-ad_scale, getedges[3]+ad_scale, length = 0.1)
    text(getedges[1]-ad_scale/2, getedges[3]-ad_scale/2, labels = "UMAP1")
    text(getedges[1]-ad_scale/0.7, getedges[3]+ad_scale/2, labels = "UMAP2", srt=90)
    
    #Add 
    plot_score_map(x=seq(min(out_genes), max(out_genes), length.out = 10), coordinates=c(getedges[2]+ad_scale/2,getedges[2]+ad_scale,getedges[4]-ad_scale*2,getedges[4]), pal = pal)
    
    
    
  } 
  if(length(genes)==1){
    
    getedges=c(min(as.matrix(tsne)[,1]), max(as.matrix(tsne)[,1]),min(as.matrix(tsne)[,2]), max(as.matrix(tsne)[,2]) )
    
    dif=max(getedges)+abs(min(getedges))
    
    scale_p=dif/3
    
    out_genes=log2((matrix[genes, ])+1)
    col=map2color(out_genes, pal)
    plot(x=as.matrix(tsne),type="n", main=genes, axes=F, xlab="", ylab="",
         xlim = c(min(getedges)-scale_p,max(getedges)+scale_p),
         ylim = c(min(getedges)-scale_p,max(getedges)+scale_p)
        )
    points(as.matrix(tsne), col=alpha(col,alpha),pch=16,cex=cex) 
    
    ad_scale=scale_p/2
    
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1], getedges[3], length = 0.08)
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1]-ad_scale, getedges[3]+ad_scale, length = 0.08)
    text(getedges[1]-ad_scale/2, getedges[3]-ad_scale/2, labels = "UMAP1")
    text(getedges[1]-ad_scale/0.7, getedges[3]+ad_scale/2, labels = "UMAP2", srt=90)
    
    #Add 
    plot_score_map(x=seq(min(out_genes), max(out_genes), length.out = 10), coordinates=c(getedges[2]+ad_scale/2,getedges[2]+ad_scale,getedges[4]-ad_scale*2,getedges[4]), pal = pal)
    
    
    }
  else{print("Gene not Listed")}
  #plot_score_map(as.matrix(ds@reductions$tsne@cell.embeddings),coordinates=c(1,1),z_scored=T, overlay=F, pal=inferno(100))
  
}

TSNE_GeneSets_DHH=function(GeneSet= "Neftel_NPC_Comb",matrix=ds@assays$RNA@counts,
                        tsne=ds@reductions$tsne@cell.embeddings, 
                        alpha=0.2,pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=2)(100),
                        cex=1){
  plot_score_map=function(x=1:10,coordinates=c(4.5, 5, 0.8, 1),z_scored=T, cex=0.8, overlay=F, pal=pal){
    
    if(z_scored==T){max=1;min=-1}else{max=max(x);min=min(x)}
    val=round(seq(min(x), max(x), length.out = 5), digits = 1)
    
    
    #plot(NA,axes=F,xlab="", ylab="", bty="n", xlim=c(1,10), ylim=c(0,length(pal)+2))
    pal= colorRampPalette(pal)(50)
    
    length_x=as.numeric((coordinates[2]-coordinates[1])/4)
    length_y=as.numeric((coordinates[4]-coordinates[3])/50)
    for(i in 1:length(pal)){
      
      polygon(x=c(coordinates[1], coordinates[1]+length_x),y=c(coordinates[3]+i*length_y, coordinates[3]+i*length_y),lwd=4,border = pal[i])
      
    }
    x_task= coordinates[1]+length_x*1.3
    arrows(x_task,coordinates[3], x_task, coordinates[4]+length_y*5, length = length_x/10)
    xx=seq(coordinates[3],coordinates[4],length.out = 5)
    for ( i in 1: length(xx)){
      polygon(x=c(x_task,x_task+length_x*0.6), y=c(xx[i],xx[i] ),lwd=0.5, border = "black")
      text(x=c(x_task+length_x*2.5), y=xx[i], labels = val[i], cex=0.8)
    }
    
    text(x=x_task, y=coordinates[4]+length_y*10, labels = "Z-Score", cex=cex)
    
  }
  
  genes=GeneSets[GeneSets$ont==GeneSet,]$gene
  genes=genes[ genes %in% rownames(matrix)]
  
  par(mar=c(5,5,5,5), las=2)
  
  if(length(genes)>=2){
    
    getedges=c(min(as.matrix(tsne)[,1]), max(as.matrix(tsne)[,1]),min(as.matrix(tsne)[,2]), max(as.matrix(tsne)[,2]) )
    
    dif=max(getedges)+abs(min(getedges))
    
    scale_p=dif/3
    
    
    out_genes=log2(colMeans(matrix[genes, ])+1)
    col=map2color(out_genes, pal)
    plot(x=as.matrix(tsne),type="n", main=GeneSet, axes=F, xlab="", ylab="",
         xlim = c(min(getedges)-scale_p,max(getedges)+scale_p),
         ylim = c(min(getedges)-scale_p,max(getedges)+scale_p)
    )
    
    points(as.matrix(tsne), col=alpha(col,alpha),pch=16,cex=cex)
    
    
    ad_scale=scale_p/2
    
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1], getedges[3], length = 0.1)
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1]-ad_scale, getedges[3]+ad_scale, length = 0.1)
    text(getedges[1]-ad_scale/2, getedges[3]-ad_scale/2, labels = "UMAP1")
    text(getedges[1]-ad_scale/0.7, getedges[3]+ad_scale/2, labels = "UMAP2", srt=90)
    
    #Add 
    plot_score_map(x=seq(min(out_genes), max(out_genes), length.out = 10), coordinates=c(getedges[2]+ad_scale/2,getedges[2]+ad_scale,getedges[4]-ad_scale*2,getedges[4]), pal = pal)
    
    
    
  } 
  if(length(genes)==1){
    
    getedges=c(min(as.matrix(tsne)[,1]), max(as.matrix(tsne)[,1]),min(as.matrix(tsne)[,2]), max(as.matrix(tsne)[,2]) )
    
    dif=max(getedges)+abs(min(getedges))
    
    scale_p=dif/3
    
    out_genes=log2((matrix[genes, ])+1)
    col=map2color(out_genes, pal)
    plot(x=as.matrix(tsne),type="n", main=genes, axes=F, xlab="", ylab="",
         xlim = c(min(getedges)-scale_p,max(getedges)+scale_p),
         ylim = c(min(getedges)-scale_p,max(getedges)+scale_p)
    )
    points(as.matrix(tsne), col=alpha(col,alpha),pch=16,cex=cex) 
    
    ad_scale=scale_p/2
    
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1], getedges[3], length = 0.08)
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1]-ad_scale, getedges[3]+ad_scale, length = 0.08)
    text(getedges[1]-ad_scale/2, getedges[3]-ad_scale/2, labels = "UMAP1")
    text(getedges[1]-ad_scale/0.7, getedges[3]+ad_scale/2, labels = "UMAP2", srt=90)
    
    #Add 
    plot_score_map(x=seq(min(out_genes), max(out_genes), length.out = 10), coordinates=c(getedges[2]+ad_scale/2,getedges[2]+ad_scale,getedges[4]-ad_scale*2,getedges[4]), pal = pal)
    
    
  }
  else{print("Gene not Listed")}
  #plot_score_map(as.matrix(ds@reductions$tsne@cell.embeddings),coordinates=c(1,1),z_scored=T, overlay=F, pal=inferno(100))
  
}


TSNE_Groups_DHH=function(groups="seurat_clusters",
                         f_data_inp=object@seuratobject@meta.data, 
                           tsne=ds@reductions$tsne@cell.embeddings, 
                           alpha=0.2,
                          pal=brewer.pal(9, "Set1"),
                           cex=1){
    
    if(is.null(f_data_inp[,groups])) stop ("Group not in Seurat Object")
    getedges=c(min(as.matrix(tsne)[,1]), max(as.matrix(tsne)[,1]),min(as.matrix(tsne)[,2]), max(as.matrix(tsne)[,2]) )
    dif=max(getedges)+abs(min(getedges))
    scale_p=dif/3
    
    

    col=map2color(f_data_inp[,groups], pal)
    plot(x=as.matrix(tsne),type="n", main=groups, axes=F, xlab="", ylab="",
         xlim = c(min(getedges)-scale_p,max(getedges)+scale_p),
         ylim = c(min(getedges)-scale_p,max(getedges)+scale_p)
    )
    
    points(as.matrix(tsne), col=alpha(col[[1]],alpha),pch=16,cex=cex)
    
    
    ad_scale=scale_p/2
    
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1], getedges[3], length = 0.1)
    arrows(getedges[1]-ad_scale, getedges[3], getedges[1]-ad_scale, getedges[3]+ad_scale, length = 0.1)
    text(getedges[1]-ad_scale/2, getedges[3]-ad_scale/2, labels = "UMAP1")
    text(getedges[1]-ad_scale/0.7, getedges[3]+ad_scale/2, labels = "UMAP2", srt=90)
    col[[2]]=col[[2]][order(col[[2]]$Terms), ]
    #Add 
    for(i in 1:nrow(col[[2]])){
      x=getedges[2]+ad_scale/2
      y=getedges[4]-(ad_scale*4/nrow(col[[2]]))*i
      points(x,y, pch=16, col=col[[2]][i,3])
      text(x=x+x/8, y=y, labels = col[[2]][i,1], cex=cex)
    }
    

}


source("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/ST__Lab/ST_Functions/map2color.R")
library(RColorBrewer)

###Test Function

TSNE_Genes_DHH(genes="GFAP",
         matrix = object@seuratobject@assays$RNA@scale.data,
         tsne=object@seuratobject@reductions$umap@cell.embeddings,
         alpha=0.7,
         pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=2)(100),
         cex=0.5)



#load genesets
GeneSets_all=readRDS("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/ST__Lab/MILO_MsigDB1_14_Feb.RDS")
tail(GeneSets_all[!duplicated(GeneSets_all$ont), ]$ont, 50)
object@Usesed_GeneSetsets=GeneSets_all

TSNE_GeneSets_DHH(GeneSet="Neftel_Mes_Comb",
               matrix = object@seuratobject@assays$RNA@scale.data,
               tsne=object@seuratobject@reductions$umap@cell.embeddings,
               alpha=0.7,
               pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=2)(100),
               cex=0.5)


TSNE_Groups_DHH(groups="seurat_clusters",
                  f_data_inp = object@seuratobject@meta.data,
                  tsne=object@seuratobject@reductions$umap@cell.embeddings,
                  alpha=0.7,
                  pal=brewer.pal(9, "Set1"),
                  cex=0.5)

















##----------------------------------------------------------------------------##
## Spatial Plots 
##----------------------------------------------------------------------------##

source("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/ST__Lab/ST_Functions/ST_Img_DHH.R")

ST_Img_DHH(object,
           sample_to_print="S4",
           input=c("MALAT1", "ATAD3C"),
           modus=c("Cluster", "Genes", "GeneSets")[2],
           multiple_gene_ST="mean", 
           TXT=NA,
           BG=.8,
           threshold=1.9,
           bty="n",
           cex=0.8,
           pal=brewer.pal(6, "Reds"))

ST_Img_DHH(object,
           sample_to_print="S4",
           input=c("MALAT1", "ATAD3C"),
           modus=c("Cluster", "Genes", "GeneSets")[1],
           multiple_gene_ST="mean", 
           TXT=NA,
           BG=.8,
           threshold=1.9,
           bty="n",
           cex=0.8,
           pal=brewer.pal(9, "Set1"))


ST_Img_DHH(object,
           sample_to_print="S3",
           input="REACTOME_NEUTROPHIL_DEGRANULATION",
           modus=c("Cluster", "Genes", "GeneSets")[3],
           multiple_gene_ST="mean", 
           TXT=NA,
           BG=.8,
           threshold=0,
           bty="n",
           cex=0.8,
           pal=brewer.pal(6, "Reds") )



ST_SC_Metaplot_4D_DASH(object, Geneset=c("Neftel_OPClike","Neftel_NPC_Comb", "Neftel_AClike", "Neftel_Mes_Comb"),
                                xscale=3,
                                yscale=2, 
                                cex=1.5, 
                                col_samples="NA",
                                pal=viridis(50), 
                                genes="NA",
                                signature="Neftel_AClike",
                                Plot=T,
                                cex_GS=0.2)






  
##----------------------------------------------------------------------------##
## Export Data
##----------------------------------------------------------------------------##

object@slices=slices

saveRDS(object, "Spatial_dataset_2.RDS")

sample_data=readRDS("Spatial_dataset_2.RDS")








#Qualitycontrol dataset and cleaning for non image overlapping spots 

setGeneric("Quality_MILO", function(object) standardGeneric("Quality_MILO"))
setMethod("Quality_MILO",signature = "ST_MILO", definition = function(object){
  
  message("Check quality and print summary")
  
  #check if used is defined
  if(ncol(object@data@used)>0){mat=object@data@used}else{mat=object@data@counts}
  dim(mat)
  
  ### plot basic data per slite
  
  #data for Table
  dat_tab=matrix(1:6, 3,2)
  dat_tab[1,1]=max(colSums(mat))
  dat_tab[2,1]=min(colSums(mat))
  dat_tab[3,1]=round(mean(colSums(mat)),digits = 2)
  dat_tab[1,2]=max(rowSums(mat))
  dat_tab[2,2]=min(rowSums(mat))
  dat_tab[3,2]=round(mean(rowSums(mat)),digits = 2)
  
  
  require(plotly)
  
  
  #print table 
  plot_ly(
    type = 'table',
    header = list(
      values = c("<b>Features</b>", "<b>Max Counts</b>","<b>Min Counts</b>","<b>Mean Counts</b>"),
      align = c('left', rep('center', 3)),
      line = list(width = 1, color = 'black'),
      fill = list(color = "lightblue"),
      font = list(family = "Helvetica", size = 14, color = "black")
    ),
    
    cells = list(
      values = rbind(
        c("Counts per Spot", "Counts per Gene"), 
        dat_tab
      ),
      
      align = c('left', rep('center', 3)),
      line = list(color = "black", width = 1),
      fill = list(color = c('lightblue', 'lightgrey')),
      font = list(family = "Helvetica", size = 12, color = c("black"))
      
    ))
  
  #print scatter plots 
  layout(matrix(1:4,2,2))
  par(mar=c(5,5,5,5), las=1, cex=0.6, pch=19)
  require(viridis)
  plot(rev(sort(rowSums(mat))), col=map2color(rev(sort(rowSums(mat))), pal=viridis(20)), xlab="Counts per Gene", ylab="Frequence", 
       main="Counts per Gene")
  plot(rev(sort(colSums(mat))), col=map2color(rev(sort(colSums(mat))), pal=viridis(20)), xlab="UMI per Spot", ylab="Frequence",
       main="UMI per Spot")
  
  par(mar=c(1,1,1,1))
  #UMI per spot
  ST_Img_DHH(Coordinate_file=object@fdata, 
             plot_overlay=T,
             plot_clusters = F,
             POINTS_only=T,
             plot_genes=F, 
             Enrichment_DF=NA,
             Enrichment_DF_col=1,
             Enrich_threshold=4,
             ST_gene_matrix=mat, 
             multiple_gene_ST="mean", 
             TXT=NA,
             gene="QC", 
             BG=.8,
             threshold=0,
             bty="n",
             cex=0.8,
             pal=viridis(50))
  
  
  
  ST_Img_DHH(Coordinate_file=object@fdata, 
             plot_overlay=T, 
             POINTS_only=F,
             plot_genes=F, 
             Enrichment_DF=NA,
             Enrichment_DF_col=1,
             Enrich_threshold=4,
             ST_gene_matrix=mat, 
             multiple_gene_ST="mean", 
             TXT=NA,
             gene="GFAP", 
             BG=.8,
             threshold=0,
             bty="n",
             cex=0.8,
             pal=viridis(5))
  
  
})


#Cluster function based on graph clustering included in Seurat of Autoencoder based on deep-learning combined with UMAP


setGeneric("Pipe_MILO", function(object, clustertype=c("graph","Autoencoder"), 
                                 cluster=c("mstknnclust","Autopipe"), epochs=2000) standardGeneric("Pipe_MILO"))
setMethod("Pipe_MILO",signature = "ST_MILO", definition = function(object, clustertype=c("graph","Autoencoder"), 
                                                                   cluster=c("mstknnclust","Autopipe"), epochs=2000){
  
  message("###############Start Clustering by the MILO lab package for Spatial Transcriptomics ########################")
  
  if(clustertype!="graph" & clustertype!="Autoencoder") stop("Clustertype is undefined")
  message(paste("You are using the ",clustertype, " Method for Clustering")); if(clustertype=="Autoencoder") warning(
    "Check if your system is ready-to-use Keras ... and enough computational power etc....otherwise use graph clustering")
  
  ### start with the usage of Keras and autoencoder
  if(clustertype=="Autoencoder"){
    #data neet to be converted into data with spot
    mat=object@data@counts
    fdat=object@fdata
    library(dplyr)
    library(Seurat)
    used_spots=as.character((fdat %>% filter(fdat$header %in% colnames(mat) & fdat$HE_Slide==2))[,6])
    mat=mat[,used_spots]
    
    
    #Transform data into expression by the seurat algorithm 
    require(Seurat)
    S1=CreateSeuratObject(counts = mat)
    S1[["percent.mt"]] <- PercentageFeatureSet(S1, pattern = "^MT-")
    VlnPlot(S1, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
    
    S1 <- NormalizeData(S1, normalization.method = "LogNormalize", scale.factor = 1000)
    
    S1 <- FindVariableFeatures(S1, selection.method = "vst", nfeatures = 2000)
    S1 <- ScaleData(S1, features = rownames(S1))    
    
    #get data back fill up our data 
    
    object@data@norm_Exp=S1@assays$RNA@scale.data
    object@data@used=object@data@norm_Exp
    mat=object@data@used
    
    message("Expression data were normalized and scaled")
    
    ###Autoenencoder
    
    library(keras)
    library(tensorflow)
    library(dplyr)
    library(purrr)
    
    ### Start Auto encoder for dimensional reduction and clustering 
    
    
    #Given a dataset and normalization constants it will create a min-max normalized
    normalization_minmax <- function(x, desc) {
      map2_dfc(x, desc, ~(.x - .y$min)/(.y$max - .y$min))
    }
    get_desc <- function(x) {
      map(x, ~list(
        min = min(.x),
        max = max(.x),
        mean = mean(.x),
        sd = sd(.x)
      ))
    } 
    
    
    #create train and test
    
    df_train=as.data.frame((mat))
    desc <- df_train %>% 
      get_desc()
    x_train <- df_train %>%
      normalization_minmax(desc) %>%
      as.matrix()
    
    x_train=t(x_train)
    
    # set model
    model <- keras_model_sequential()
    model %>%
      layer_dense(units = 100, activation = "tanh", input_shape = ncol(x_train)) %>%
      layer_dense(units = 30, activation = "tanh", name = "bottleneck") %>%
      layer_dense(units = 100, activation = "tanh") %>%
      layer_dense(units = ncol(x_train))
    
    # view model layers
    summary(model)
    
    # compile model
    model %>% compile(
      loss = "mean_squared_error", 
      optimizer = "adam"
    )
    
    # fit model
    model %>% fit(
      x = x_train, 
      y = x_train, 
      epochs = epochs,
      verbose = 1
    )
    
    # evaluate the performance of the model
    mse.ae2 <- evaluate(model, x_train, x_train)
    mse.ae2
    
    
    # extract the bottleneck layer
    intermediate_layer_model <- keras_model(inputs = model$input, outputs = get_layer(model, "bottleneck")$output)
    intermediate_output <- predict(intermediate_layer_model, x_train)
    
    #use the output from Autoencoder
    
    dat=umap::umap(intermediate_output)
    plot(dat$layout, bty="n", pch=19, cex=0.5, xaxt="n", xlab="", yaxt="n", ylab="")
    
    rownames(intermediate_output)=colnames(mat)
    rownames(dat$layout)=colnames(mat)
    
    message(" Finished with Autoencoder start clustering")
    
    object@AutoEncoder=intermediate_output
    object@UMAP=dat$layout
    
    if(cluster=="mstknnclust"){
      #Start with Cluster
      library(mstknnclust)
      datx=as.matrix(intermediate_output)
      
      #create distance matrix
      dist=as.matrix(dist(datx, method="maximum"))
      #heatmap(dist, col=rev(viridis(50)))
      
      res=mst.knn(dist)
      
      
      
      cluster=data.frame(Cluster=as.numeric(res$cluster), row.names = names(res$cluster))
      object@cluster=cluster
      
      
      #plot results
      cluster$col=map2color(cluster$Cluster, pal=brewer.pal(9, "Set1"))
      dev.off()
      layout(matrix(1:2, 1,2))
      par(mar=c(5,5,5,5), cex=0.8, pch=19)
      plot(dat$layout, col=cluster[rownames(dat$layout),2] , axes=F, xlab="", ylab="", 
           main="Autoencoder MAP of Spots")
      
      ST_Img_DHH(Coordinate_file=object@fdata,
                 Cluster=cluster,
                 plot_clusters=T,
                 plot_overlay=F, 
                 POINTS_only=F,
                 plot_genes=F, 
                 Enrichment_DF=NA,
                 Enrichment_DF_col=1,
                 Enrich_threshold=4,
                 ST_gene_matrix=object@data@counts, 
                 multiple_gene_ST="mean", 
                 TXT="Cluster",
                 gene="Cluster",
                 BG=.8,
                 threshold=0,
                 bty="n",
                 cex=1.5,
                 pal=brewer.pal(9, "Set1"))
      
      #Marker genes
      S1@meta.data$seurat_clusters=cluster[rownames(S1@meta.data),1]
      S1@active.ident=as.factor(S1@meta.data$seurat_clusters)
      names(S1@active.ident)=rownames(S1@meta.data)
      
      MG=FindAllMarkers(S1,  only.pos = T, min.pct = 0.0001, logfc.threshold = 0.01)
      object@Marker_genes=MG
      
      #Run GSEA
      
      #GSEA
      # if required GSEA
      library(clusterProfiler)
      
      
      MsigDB=("~/Desktop/TCGA Data/msigdb_v5.0_files_to_download_locally/msigdb_v5.0_GMTs/msigdb.v7.0.symbols.gmt")
      MsigDB <- read.gmt(MsigDB)
      
      #sort the MsigDB
      MsigDB1=MsigDB[grepl("^KEGG", MsigDB$ont) | grepl("^GSE", MsigDB$ont) | grepl("^HALLMARK", MsigDB$ont) | grepl("^REACTOME", MsigDB$ont)| grepl("^BIOCARTA_", MsigDB$ont), ] 
      dim(MsigDB1)
      
      
      
      GSEA=lapply(1:max(unique(cluster$Cluster)), function(i){
        message("Run GSEA")
        if(nrow(MG %>% filter(cluster==i) )>20){
          
          ranks=data.frame(ID=as.character(MG[MG$cluster==i, ]$gene),t=as.numeric(MG[MG$cluster==i, ]$avg_logFC))
          
          rank_f=function(x){(x-min(x))/(max(x)-min(x))}
          ranks$t=rank_f(ranks$t)
          ranks=ranks[order(ranks$t, decreasing = T), ]
          ranks <- setNames(ranks$t, ranks$ID)
          str(ranks)
          egmt5 <- GSEA(ranks, TERM2GENE=MsigDB1, verbose = T, pvalueCutoff= 1)
          results_GSEA_5=egmt5@result
          
          
          
        }else{message(paste("Cluster:",i, "   Number of DE is to low for GSEA"))}
        
      })
      
      object@GSEA=GSEA
      
      
      
    }
    
    
    
    if(cluster=="Autopipe"){
      me_x=t(intermediate_output)
      rownames(me_x)=paste("AEC", 1:30)
      require(AutoPipe)
      res=TopPAM(me_x,max_clusters = 6, TOP=30)
      
      me_TOP=res[[1]]
      number_of_k=res[[3]]
      File_genes=Groups_Sup(me_TOP, me=me_x, number_of_k,TRw=-1)
      groups_men=File_genes[[2]]
      me_x=File_genes[[1]]
      
      cluster=data.frame(Cluster=as.numeric(groups_men$cluster), row.names = rownames(groups_men))
      object@cluster=cluster
      
      #plot results
      cluster$col=map2color(cluster$Cluster, pal=brewer.pal(9, "Set1"))
      dev.off()
      layout(matrix(1:2, 1,2))
      par(mar=c(5,5,5,5), cex=0.8, pch=19)
      plot(dat$layout, col=cluster[rownames(dat$layout),2] , axes=F, xlab="", ylab="", 
           main="Autoencoder MAP of Spots")
      
      ST_Img_DHH(Coordinate_file=object@fdata,
                 Cluster=cluster,
                 plot_clusters=T,
                 plot_overlay=F, 
                 POINTS_only=F,
                 plot_genes=F, 
                 Enrichment_DF=NA,
                 Enrichment_DF_col=1,
                 Enrich_threshold=4,
                 ST_gene_matrix=object@data@counts, 
                 multiple_gene_ST="mean", 
                 TXT="Cluster",
                 gene="Cluster",
                 BG=.8,
                 threshold=0,
                 bty="n",
                 cex=1.5,
                 pal=brewer.pal(9, "Set1"))
      
      
      #Marker genes
      S1@meta.data$seurat_clusters=cluster[rownames(S1@meta.data),1]
      S1@active.ident=as.factor(S1@meta.data$seurat_clusters)
      names(S1@active.ident)=rownames(S1@meta.data)
      
      MG=FindAllMarkers(S1,  only.pos = T, min.pct = 0.00001, logfc.threshold = 0.0001)
      object@Marker_genes=MG
      
      #Run GSEA
      
      #GSEA
      # if required GSEA
      library(clusterProfiler)
      
      
      MsigDB=("~/Desktop/TCGA Data/msigdb_v5.0_files_to_download_locally/msigdb_v5.0_GMTs/msigdb.v7.0.symbols.gmt")
      MsigDB <- read.gmt(MsigDB)
      
      #sort the MsigDB
      MsigDB1=MsigDB[grepl("^KEGG", MsigDB$ont) | grepl("^GSE", MsigDB$ont) | grepl("^HALLMARK", MsigDB$ont) | grepl("^REACTOME", MsigDB$ont)| grepl("^BIOCARTA_", MsigDB$ont), ] 
      dim(MsigDB1)
      
      
      
      GSEA=lapply(1:max(unique(cluster$Cluster)), function(i){
        message("Run GSEA")
        if(nrow(MG %>% filter(cluster==i) )>20){
          
          ranks=data.frame(ID=as.character(MG[MG$cluster==i, ]$gene),t=as.numeric(MG[MG$cluster==i, ]$avg_logFC))
          
          rank_f=function(x){(x-min(x))/(max(x)-min(x))}
          ranks$t=rank_f(ranks$t)
          ranks=ranks[order(ranks$t, decreasing = T), ]
          ranks <- setNames(ranks$t, ranks$ID)
          str(ranks)
          egmt5 <- GSEA(ranks, TERM2GENE=MsigDB1, verbose = T, pvalueCutoff= 1)
          results_GSEA_5=egmt5@result
          
          
          
        }else{message(paste("Cluster:",i, "   Number of DE is to low for GSEA"))}
        
      })
      
      object@GSEA=GSEA
      
      
      
      
    }
    
    
    
    
    
    
    
    
    
    
  }
  
  
  
  
  
  if(clustertype=="graph"){
    
    message("Start with Clustering using graph cluster und PCA")
    #data neet to be converted into data with spot
    mat=object@data@counts
    fdat=object@fdata
    require(dplyr)
    
    used_spots=as.character((fdat %>% filter(fdat$header %in% colnames(mat) & fdat$HE_Slide==2))[,6])
    mat=mat[,used_spots]
    
    
    #Transform data into expression by the seurat algorithm 
    require(Seurat)
    S1=CreateSeuratObject(counts = mat)
    S1[["percent.mt"]] <- PercentageFeatureSet(S1, pattern = "^MT-")
    VlnPlot(S1, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
    
    S1 <- NormalizeData(S1, normalization.method = "LogNormalize", scale.factor = 1000)
    
    S1 <- FindVariableFeatures(S1, selection.method = "vst", nfeatures = 2000)
    S1 <- ScaleData(S1, features = rownames(S1))    
    
    #get data back fill up our data 
    
    object@data@norm_Exp=S1@assays$RNA@scale.data
    object@data@used=object@data@norm_Exp
    
    S1 <- RunPCA(S1, features = VariableFeatures(object = test))
    
    
    S1 <- FindNeighbors(S1, dims = 1:30)
    S1 <- FindClusters(S1, resolution = 0.5)
    
    S1 <- RunUMAP(S1, dims = 1:30)
    DimPlot(S1, reduction = "umap")
    pbmc.markers <- FindAllMarkers(S1,  only.pos = TRUE, min.pct = 0.0001, logfc.threshold = 0.01)
    
    object@Marker_genes=pbmc.markers
    MG=pbmc.markers
    pbmc.markers %>% group_by(cluster) %>% top_n(n = 50, wt = avg_logFC)
    top10 <- pbmc.markers %>% group_by(cluster) %>% top_n(n = 50, wt = avg_logFC)
    library(ggplot2)
    library(viridis)
    DoHeatmap(S1, features = top10$gene,size = 1) + scale_fill_viridis() 
    
    
    cluster=data.frame(Cluster=as.numeric(S1@meta.data$seurat_clusters)+1, row.names = row.names(S1@meta.data))
    object@cluster=cluster
    
    
    #plot results
    cluster$col=map2color(cluster$Cluster, pal=brewer.pal(9, "Set1"))
    dev.off()
    layout(matrix(1:2, 1,2))
    par(mar=c(5,5,5,5), cex=0.8, pch=19)
    plot(S1@reductions$umap@cell.embeddings, col=cluster[rownames(S1@reductions$umap@cell.embeddings),2] , axes=F, xlab="", ylab="", 
         main="UMAP of Spots")
    
    ST_Img_DHH(Coordinate_file=object@fdata,
               Cluster=cluster,
               plot_clusters=T,
               plot_overlay=F, 
               POINTS_only=F,
               plot_genes=F, 
               Enrichment_DF=NA,
               Enrichment_DF_col=1,
               Enrich_threshold=4,
               ST_gene_matrix=object@data@counts, 
               multiple_gene_ST="mean", 
               TXT="Cluster",
               gene="Cluster",
               BG=.8,
               threshold=0,
               bty="n",
               cex=1.5,
               pal=brewer.pal(9, "Set1"))
    
    
    #Run GSEA
    
    #GSEA
    # if required GSEA
    library(clusterProfiler)
    
    
    MsigDB=("~/Desktop/TCGA Data/msigdb_v5.0_files_to_download_locally/msigdb_v5.0_GMTs/msigdb.v7.0.symbols.gmt")
    MsigDB <- read.gmt(MsigDB)
    
    #sort the MsigDB
    MsigDB1=MsigDB[grepl("^KEGG", MsigDB$ont) | grepl("^GSE", MsigDB$ont) | grepl("^HALLMARK", MsigDB$ont) | grepl("^REACTOME", MsigDB$ont)| grepl("^BIOCARTA_", MsigDB$ont), ] 
    dim(MsigDB1)
    
    
    
    GSEA=lapply(1:max(unique(cluster$Cluster)), function(i){
      message("Run GSEA")
      if(nrow(MG %>% filter(cluster==i) )>20){
        
        ranks=data.frame(ID=as.character(MG[MG$cluster==i, ]$gene),t=as.numeric(MG[MG$cluster==i, ]$avg_logFC))
        
        rank_f=function(x){(x-min(x))/(max(x)-min(x))}
        ranks$t=rank_f(ranks$t)
        ranks=ranks[order(ranks$t, decreasing = T), ]
        ranks <- setNames(ranks$t, ranks$ID)
        str(ranks)
        egmt5 <- GSEA(ranks, TERM2GENE=MsigDB1, verbose = T, pvalueCutoff= 1)
        results_GSEA_5=egmt5@result
        
        
        
      }else{message(paste("Cluster:",i, "   Number of DE is to low for GSEA"))}
      
    })
    
    object@GSEA=GSEA
    
    
  }
  
  return(object)
  
  
})









Coordinate_file=read.csv("Coordinates_S2.csv", sep=";", stringsAsFactors = F)
names(Coordinate_file)=c("HE_Slide","X","Y","x.Slide","y.Slide","header")
Coordinate_file$X.1=NA
expression_matrix=read.csv("S2_stdata_genes.tsv", sep="\t", stringsAsFactors = F)
col_n=expression_matrix$X
expression_matrix=as.matrix(t(expression_matrix[,2:ncol(expression_matrix)]))
colnames(expression_matrix)=col_n

object=ST_MILO(count_matrix=expression_matrix, f_data = Coordinate_file)
Quality_MILO(object)
object=Pipe_MILO(object,clustertype="Autoencoder",cluster="Autopipe",epochs=20)
object=Pipe_MILO(object,clustertype="graph")







object@GSEA

#Marker
marker=object@Marker_genes


dev.off()


TOP=head(arrange(marker,desc(avg_logFC),p_val_adj ) %>% filter(cluster==2),18)$gene

layout(matrix(1:18,3,6))
par(mar=c(0,0,0,0))
for(i in 1:18){
  Plot_Expression(object, gene = TOP[i], cex=0.3, pal = brewer.pal(9,"Purples"))
}


GSEA=object@GSEA[[2]]


genes=(MsigDB%>%filter(ont=="REACTOME_INNATE_IMMUNE_SYSTEM"))[,2]
Plot_Expression(object, gene = genes, cex=0.3, pal = brewer.pal(9,"Purples"), TXT="IMMUNE_SYSTEM")

genes=(MsigDB%>%filter(ont=="REACTOME_NEUTROPHIL_DEGRANULATION"))[,2]
Plot_Expression(object, gene = genes, cex=0.3, pal = brewer.pal(9,"Purples"), TXT="NEUTROPHIL_DEGRANULATION")


genes=(MsigDB%>%filter(ont=="REACTOME_SIGNALING_BY_INTERLEUKINS"))[,2]
Plot_Expression(object, gene = genes, cex=0.3, pal = brewer.pal(9,"Purples"), TXT="SIGNALING_BY_INTERLEUKINS")

genes=(MsigDB%>%filter(ont=="REACTOME_CYTOKINE_SIGNALING_IN_IMMUNE_SYSTEM"))[,2]
Plot_Expression(object, gene = genes, cex=0.3, pal = brewer.pal(9,"Purples"), TXT="CYTOKINE_SIGNALING_IN_IMMUNE_SYSTEM")

genes=(MsigDB%>%filter(ont=="REACTOME_AXON_GUIDANCE"))[,2]
Plot_Expression(object, gene = genes, cex=0.3, pal = brewer.pal(9,"Purples"), TXT="AXON_GUIDANCE")

genes=(MsigDB%>%filter(ont=="REACTOME_CELL_CYCLE"))[,2]
Plot_Expression(object, gene = genes, cex=0.3, pal = brewer.pal(9,"Purples"), TXT="REACTOME_CELL_CYCLE")

genes=(MsigDB%>%filter(ont=="GSE1432_CTRL_VS_IFNG_24H_MICROGLIA_UP"))[,2]
Plot_Expression(object, gene = genes, cex=0.3, pal = brewer.pal(9,"Purples"), TXT="GSE1432_CTRL_VS_IFNG_1H_MICROGLIA_UP")




MES=c(GenesetMM$MESlike1,GenesetMM$MESlike2)
MES=Plot_Expression(object, gene = MES, cex=0.3, pal = brewer.pal(9,"Oranges"), TXT="MES")

OPC=c(GenesetMM$OPClike)
OPC=Plot_Expression(object, gene = OPC, cex=0.3, pal = brewer.pal(9,"Reds"), TXT="OPC")

AC=c(GenesetMM$AClike)
AC=Plot_Expression(object, gene = AC, cex=0.3, pal = brewer.pal(9,"Greens"), TXT="AC")

NPC=c(GenesetMM$NPClike1,GenesetMM$NPClike2)
NPC=Plot_Expression(object, gene = NPC, cex=0.3, pal = brewer.pal(9,"Blues"), TXT="NPC")

Cycle=GenesetMM$G2.M
Cycle=Plot_Expression(object, gene = Cycle, cex=0.3, pal = brewer.pal(9,"Purples"), TXT="Cycle")


display.brewer.pal(n = 100, name = 'Reds')
display.brewer.pal(n = 100, name = 'Blues')
display.brewer.pal(n = 100, name = 'Greens')
display.brewer.pal(n = 100, name = 'Oranges')


output_DL=data.frame(LOC=MES$header,MES=MES$X.1, OPC=OPC$X.1,  AC=AC$X.1, NPC=NPC$X.1, Cycle=Cycle$X.1)

write.table(output_DL, file="Voxel_def.csv", sep=";", row.names = F)



Plot_Expression(object, gene = "GFAP", cex=0.3, pal = brewer.pal(9,"Oranges"), TXT="MES")










#data that we need
score=read.csv("Mappe1.csv", sep=";", stringsAsFactors = F)
#IL10
Activation_score=unique(score[,2])[!unique(score[,2])==""]
Induction_score=unique(score[,1])[!unique(score[,1])==""]

#SPP1
Activation_score=unique(score[,4])[!unique(score[,4])==""]
Induction_score=unique(score[,3])[!unique(score[,3])==""]

#IFNG
Activation_score=unique(score[,6])[!unique(score[,6])==""]
Induction_score=unique(score[,5])[!unique(score[,5])==""]






Receptor=c("IL10RA", "IL10RB")
Ligant="IL10"

Receptor=c("CD44")
Ligant="SPP1"

Receptor=c("IFNGR1", "IFNGR2")
Ligant="IFNG"





#Input lists!!
R_Input=list(Receptor, Activation_score)
L_Input=list(Ligant, Induction_score)




#Defining classes for input data 
data_counts=setClass("data_counts", slots = c(counts="matrix", 
                                              norm_Exp = "matrix", 
                                              batch_corrected = "matrix", 
                                              used="matrix"))

R_L_Set <- setClass("R_L_Set", slots = c(  R_Input="list",
                                           L_Input = "list",
                                           data = "data_counts" ,
                                           spatial_info="data.frame",
                                           Cluster_to_check="list",
                                           UMAP="data.frame",
                                           data_fdat="data.frame"
))



setMethod("initialize",signature = "R_L_Set", definition = function(.Object, R_Input, L_Input,data){
  .Object@R_Input=R_Input
  .Object@L_Input=L_Input
  .Object@data@norm_Exp=data
  return(.Object)
})



####  Input parameters are defined by R/L and Ind/Act.


#Create feature db

exp_db=object@seuratobject@assays$RNA@scale.data

exp_db[1:10, 1:10]
max(exp_db)



R_L_Set=R_L_Set(R_Input, L_Input, data=exp_db)


#First ealuate the z-scored enrichment of Induktion and Response Genesets 
require(GSVA)

Activation_score=R_L_Set@R_Input[[2]]
Induction_score=R_L_Set@L_Input[[2]]
Ligant=R_L_Set@L_Input[[1]]
Receptor=R_L_Set@R_Input[[1]]

gs=list(Activation_score, Induction_score)
es.max <- gsva(exp_db, gs, mx.diff=T, method=c("zscore"), parallel.sz=8)

#Input data used for map
ExpR=colMeans(exp_db[Receptor, ])
#ExpR=(exp_db[Receptor, ])
ExpL=exp_db["IFNE", ]




#saveRDS(list(es.max,ExpR,ExpL), file="IL_10.RDS" )
#saveRDS(list(es.max,ExpR,ExpL), file="SPP1.RDS" )
saveRDS(list(es.max,ExpR,ExpL), file="IFNG.RDS" )

readRDS("IL_10.RDS")


### plot

plot_PL_Trajectory=function(es.max,
                            modus=c("spatial", "scRNAseq")[2],
                            ExpR,ExpL, 
                            quantil_test=.8, 
                            Return_vislab=F,
                            plot_model=T,
                            plot_circel=F,
                            plot_connectivity=F,
                            plot_barplots=F,
                            theta=3,
                            scale_z=1,...){
  
  #required function
  norm_s=function(x){(x-min(x))/(max(x)-min(x))}
  
  if(modus=="scRNAseq"){
    
    message("Start Fitting the Model by using sc_RNAseq Data")
    #Fit model
    score1=es.max[1,TC_cells]
    upper=quantile(score1, .995)
    score1[score1>upper]=jitter(rep(upper,length(score1[score1>upper])), factor=upper)
    y1=2-norm_s(score1)
    
    
    upper=quantile(ExpR, .995)
    ExpR[ExpR>upper]=jitter(rep(upper,length(ExpR[ExpR>upper])), factor=upper)
    x1=2-(norm_s(ExpR))
    
    score=es.max[2,c(MG_cells,MP_cells)]
    upper=quantile(score, .995)
    score[score>upper]=jitter(rep(upper,length(score[score>upper])), factor=upper)
    y2=norm_s(score)
    
    upper=quantile(ExpL, .995)
    ExpL[ExpL>upper]=jitter(rep(upper,length(ExpL[ExpL>upper])), factor=upper)
    x2=(norm_s(ExpL))
    
    
    #Start ploting
    message("Start Create Plots")
    
    dev.off()
    
    if(plot_model==T){
      
      scale_f=0.4
      plot(NA,xlim = c(0-scale_f,2+scale_f), ylim=c(0-scale_f,2+scale_f), axes=F, xlab="", ylab="")
      lo <- loess(c(y1,y2) ~ c(x1,x2))
      xl <- seq(0.05, 1.9, length.out = 1000)
      
      
      
      points(c(x1,x2), jitter(predict(lo,c(x1,x2)), factor=900), 
             col=c(map2color(x1, rev(viridis(20))),map2color(x2, (viridis(20))) ), pch=19,
             cex=c(y1-1,y2+0.3)*2)
      
      points(xl, predict(lo,xl), type="l", lty=2, lwd=1.5, col="black")
      
      #Add scales
      z_point=0
      up_z_point=2
      arrows(z_point,z_point, 1, z_point,  length=0.1) 
      arrows(z_point,z_point, z_point, 1,  length=0.1)
      arrows(up_z_point,up_z_point, 1, up_z_point,  length=0.1) 
      arrows(up_z_point,up_z_point, up_z_point, 1,  length=0.1)
      
      threshold=quantil_test
      
      polygon(x=c(threshold,1+(1-threshold), (1-threshold)+1, threshold ), 
              y=c(threshold,threshold,(1-threshold)+1, (1-threshold)+1), lty=2, lwd=1.5)
      
      #lables
      text(x=z_point+0.4, y=z_point-0.1, labels = "Expression Ligand")
      text(x=z_point-0.1, y=z_point+0.4, labels = "GSVA-Score Induction", srt=90)
      
      text(x=up_z_point-0.4, y=up_z_point+0.1, labels = "Expression Receptor")
      text(x=up_z_point+0.1, y=up_z_point-0.4, labels = "GSVA-Score Activation",srt=90 )
      
      #Show top cells in cluster
      
      #quantil_test=0.8
    }
    if(plot_barplots==T){
      
      #plot
      #-> Calculate percentage
      A=table(TC@meta.data[names(ExpR[ExpR>quantile(ExpR,quantil_test)]), ]$seurat_clusters)
      B=table(TC@meta.data$seurat_clusters)
      C=A/B
      C=prop.table(C)
      barplot((C), col=brewer.pal(5, "Set1"), main = "Cluster Receptor")
      
      
      A=table(ds@meta.data[names(ExpL[ExpL>quantile(ExpL,quantil_test)]), ]$seurat_clusters)
      B=table(ds@meta.data$seurat_clusters)
      C=A/B
      barplot(C, col=brewer.pal(5, "Set1"), main = "Cluster Ligant")
      
    }
    if(plot_connectivity==T){
      
      plot(ds@reductions$umap@cell.embeddings, pch=19, col=alpha("black", 0.2), bty="n", axes=F, xlab="", ylab="")
      #points(ds@reductions$umap@cell.embeddings[names(ExpL[ExpL>quantile(ExpL,quantil_test)]), ],col="navy", pch=19,cex=0.3 )
      #plot(ds@reductions$umap@cell.embeddings, pch=19, col=alpha("grey", 0.2), bty="n", axes=F, xlab="", ylab="")
      #points(ds@reductions$umap@cell.embeddings[names(ExpR[ExpR>quantile(ExpR,quantil_test)]), ],col="darkgreen", pch=19, cex=0.3 )
      
      #Add connection lines
      
      #(1) Rank gene set
      ExpL_r=y1[y1>quantile(y1,quantil_test)]
      ExpR_r=y2[y2>quantile(y2,quantil_test)]
      
      ExpR_r=ExpR_r[order(ExpR_r)]
      ExpL_r=ExpL_r[order(ExpL_r)]
      
      df_r=data.frame(ExpR_r,QT=ecdf(ExpR_r)(ExpR_r), row.names = names(ExpR_r))
      df_l=data.frame(ExpL_r,QT=ecdf(ExpL_r)(ExpL_r), row.names = names(ExpL_r))
      col=alpha(map2color(df_r$QT, inferno(50)), 0.7)
      
      for(i in 1:nrow(df_r)){#Loop for connected lines defined by neares neighbour based on quantil similary
        inp=df_r[i,2]
        x=df_l[,2]
        FROM=rownames(df_r)[i]
        TO=rownames(df_l)[which.min(abs(x - inp))]
        
        start=ds@reductions$umap@cell.embeddings[FROM, ]
        end=ds@reductions$umap@cell.embeddings[TO, ]
        curveMaker <- function(x1, y1, x2, y2, ...){
          curve( plogis( x, scale = 0.9, loc = (x1 + x2) /2 ) * (y2-y1) + y1, 
                 x1, x2, add = TRUE, ...)
        }
        
        #curveMaker(start[1], start[2], end[1], end[2], col=col[i], lwd = inp*2)
        
        polygon(x=c(start[1], end[1]),y=c(start[2], end[2]),border = col[i], lwd = inp*2)
        
      }
      
      
    }
    if(plot_circel==T){
      
      #require functions
      library(circlize)
      
      
      
      #input data
      #(1) Rank gene set
      ExpL_r=y1
      ExpR_r=y2
      
      ExpR_r=ExpR_r[order(ExpR_r)]
      ExpL_r=ExpL_r[order(ExpL_r)]
      
      
      df_r=data.frame(ExpR_r,QT=ecdf(ExpR_r)(ExpR_r), row.names = names(ExpR_r))
      df_l=data.frame(ExpL_r,QT=ecdf(ExpL_r)(ExpL_r), row.names = names(ExpL_r))
      col=alpha(map2color(df_r$QT, inferno(50)), 0.7)
      
      #file of connectios
      cells_all=c(rownames(df_r), rownames(df_l))
      
      names(df_l)=c("ExpR_r", "QT" )
      cells_p=rbind(df_r, df_l)
      fdat=data.frame(feature)
      
      fdat[which(fdat$Cluster=="Gamma Delta T-cells"), ]="T-Cells"
      cells_p$cluster=NA
      for(i in 1:nrow(cells_p)){print(i);cells_p$cluster[i]=(as.character(fdat[rownames(cells_p)[i], ]))}
      cells_p$col=alpha(map2color(cells_p$QT, inferno(50)), 1)
      cells_p$x=NA
      
      cells_p$cluster4=cells_p$cluster
      cells_inter=intersect(rownames(TC@meta.data), rownames(cells_p))
      cells_p[cells_inter, ]$cluster4=TC@meta.data[cells_inter, ]$cell_type
      
      
      for(i in 1:length(unique(cells_p$cluster4))){
        print(i)
        cells_p[cells_p$cluster4==unique(cells_p$cluster4)[i], "x"]=1:length(cells_p[cells_p$cluster4==unique(cells_p$cluster4)[i], "x"])
      }
      
      #ad cluster informations here
      cells_p$cluster2=ds@meta.data[rownames(cells_p), ]$Pat
      cells_p$cluster3=ds@meta.data[rownames(cells_p), ]$seurat_clusters
      
      
      
      
      
      
      
      library(circlize)
      circos.par("track.height" = 0.1)
      circos.initialize(x=cells_p$x, factors = cells_p$cluster4)
      col=map2color(cells_p$cluster4,rev(brewer.pal(6,"Set1")))[[2]]
      
      circos.track(factors = cells_p$cluster4, ylim = c(0, 1),
                   panel.fun = function(x, y) {
                     xlim = CELL_META$xlim
                     ylim = CELL_META$ylim
                     breaks = seq(xlim[1], xlim[2], by = 1)
                     n_breaks = length(breaks)
                     print(CELL_META$sector.index)
                     col_x=col[col==CELL_META$sector.index, ]$col
                     
                     
                     circos.rect(breaks[-n_breaks], 
                                 rep(ylim[1], n_breaks - 1),
                                 breaks[-1], 
                                 rep(ylim[2], n_breaks - 1),
                                 col = col_x, 
                                 border = NA)
                     
                     circos.text(CELL_META$xcenter, CELL_META$cell.ylim[2] + uy(5, "mm"), CELL_META$sector.index)
                   })
      
      circos.track(ylim = c(0, 1), panel.fun = function(x, y) {
        xlim = CELL_META$xlim
        ylim = CELL_META$ylim
        breaks = seq(xlim[1], xlim[2], by = 1)
        n_breaks = length(breaks)
        col=map2color(cells_p$QT, viridis(50))
        circos.rect(breaks[-n_breaks], 
                    rep(ylim[1], n_breaks - 1),
                    breaks[-1], 
                    rep(ylim[2], n_breaks - 1),
                    col = col, 
                    border = NA)
      })
      
      
      
      df_r=df_r[df_r$QT>0.95, ]
      
      df_r$col=alpha(map2color(df_r$QT, inferno(50)), 1)
      
      for(i in 1:nrow(df_r)){#Loop for connected lines defined by neares neighbour based on quantil similary
        inp=df_r[i,2]
        x=df_l[,2]
        FROM=rownames(df_r)[i]
        TO=rownames(df_l)[which.min(abs(x - inp))]
        cell1=FROM
        cell2=TO
        #add link
        sector1=cells_p[cell1, ]$cluster4
        p1=cells_p[cell1, ]$x
        sector2=cells_p[cell2, ]$cluster4
        p2=cells_p[cell2, ]$x
        col=df_r$col[i]
        
        circos.link(sector1, p1, sector2, p2, col=col, h = 0.4)
        
        
        
        
      }
      
      
      
      
      
      
      
      
      
      
    }
    
    
    
    
    
    
    
    
    #Map Tcells
    
    #plot(TC@reductions$umap@cell.embeddings, pch=19, col=alpha("grey", 0.2), bty="n", axes=F, xlab="", ylab="")
    #points(TC@reductions$umap@cell.embeddings[names(ExpR[ExpR>quantile(ExpR,quantil_test)]), ],col=viridis(10)[6], pch=19, cex=0.8 )
    
    
    #compare top connected and not connected 
    
    if(Return_vislab==T){
      
      ExpL_r_up=names(y2[y2>quantile(y2,0.975)])
      ExpL_r_down=names(y2[y2<quantile(y2,0.025)])
      
      df_De=data.frame(Sample=c(ExpL_r_up,ExpL_r_down ), row.names = c(ExpL_r_up,ExpL_r_down ))
      df_De$group="up"
      df_De[ExpL_r_down,]$group="down"
      df_De$group=as.factor(df_De$group)
      df_De$treatment=as.factor(df_De$group)
      
      DeSeq_matrix=ds@assays$RNA@counts[, rownames(df_De)]
      dim(DeSeq_matrix)
      
      Data.character=list(ExpID=paste0(Ligant,"_",Receptor[1]), 
                          Researcher="DHH", 
                          Bioinformatic="DHH",
                          Institute="MILO",
                          Date_of_Analysis=Sys.Date(),
                          Datatype="scRNA-seq",
                          Sequencer="Illumina",
                          Species="Human")
      
      source("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab_v1.4.1/pipeline_Create_Vizfile.R")
      
      
      
      pipline_Create_Vizfile(Modus="fromMatrix", 
                             CountMatrix=DeSeq_matrix,
                             f_data=df_De, 
                             Data.character=Data.character, 
                             HOMER=F, 
                             Addgene=F, 
                             norm="vst",
                             minCounts=1,
                             Outputname=Data.character[[1]],
                             export="/Users/HenrikHeiland/Desktop/T-Cell Project/21_new/TC")
      
      
    }
    
    
  }
  if(modus=="spatial"){
    
    message("Start Fitting the Model by using sc_RNAseq Data")
    #Fit model
    score1=es.max[1,]
    upper=quantile(score1, .995)
    score1[score1>upper]=jitter(rep(upper,length(score1[score1>upper])), factor=upper)
    y1=2-norm_s(score1)
    
    
    upper=quantile(ExpR, .995)
    ExpR[ExpR>upper]=jitter(rep(upper,length(ExpR[ExpR>upper])), factor=upper)
    x1=2-norm_s(score1)
    
    score=es.max[2, ]
    upper=quantile(score, .995)
    score[score>upper]=jitter(rep(upper,length(score[score>upper])), factor=upper)
    y2=norm_s(score)
    
    upper=quantile(ExpL, .995)
    ExpL[ExpL>upper]=jitter(rep(upper,length(ExpL[ExpL>upper])), factor=upper)
    x2=(norm_s(score))
    
    
    #Start ploting
    message("Start Create Plots")
    
    dev.off()
    
    if(plot_model==T){
      
      scale_f=0.4
      plot(NA,xlim = c(0-scale_f,2+scale_f), ylim=c(0-scale_f,2+scale_f), axes=F, xlab="", ylab="")
      lo <- loess(c(y1,y2) ~ c(x1,x2))
      xl <- seq(0.05, 1.9, length.out = 1000)
      
      
      
      points(c(x1,x2), jitter(predict(lo,c(x1,x2)), factor=900), 
             col=c(map2color(x1, rev(viridis(20))),map2color(x2, (viridis(20))) ), pch=19,
             cex=c(y1-1,y2+0.3)*2)
      
      points(xl, predict(lo,xl), type="l", lty=2, lwd=1.5, col="black")
      
      #Add scales
      z_point=0
      up_z_point=2
      arrows(z_point,z_point, 1, z_point,  length=0.1) 
      arrows(z_point,z_point, z_point, 1,  length=0.1)
      arrows(up_z_point,up_z_point, 1, up_z_point,  length=0.1) 
      arrows(up_z_point,up_z_point, up_z_point, 1,  length=0.1)
      
      threshold=quantil_test
      
      polygon(x=c(threshold,1+(1-threshold), (1-threshold)+1, threshold ), 
              y=c(threshold,threshold,(1-threshold)+1, (1-threshold)+1), lty=2, lwd=1.5)
      
      #lables
      text(x=z_point+0.4, y=z_point-0.1, labels = "Expression Ligand")
      text(x=z_point-0.1, y=z_point+0.4, labels = "GSVA-Score Induction", srt=90)
      
      text(x=up_z_point-0.4, y=up_z_point+0.1, labels = "Expression Receptor")
      text(x=up_z_point+0.1, y=up_z_point-0.4, labels = "GSVA-Score Activation",srt=90 )
      
      #Show top cells in cluster
      
      #quantil_test=0.8
    }
   
    if(plot_connectivity==T){
      
      plot(x=object@fdata[object@fdata$Sample=="S5", ]$x_Slide, 
           y=object@fdata[object@fdata$Sample=="S5", ]$y_Slide, 
           pch=19, col=alpha("black",0.3), bty="n", axes=F, xlab="", ylab="")
      #points(ds@reductions$umap@cell.embeddings[names(ExpL[ExpL>quantile(ExpL,quantil_test)]), ],col="navy", pch=19,cex=0.3 )
      #plot(ds@reductions$umap@cell.embeddings, pch=19, col=alpha("grey", 0.2), bty="n", axes=F, xlab="", ylab="")
      #points(ds@reductions$umap@cell.embeddings[names(ExpR[ExpR>quantile(ExpR,quantil_test)]), ],col="darkgreen", pch=19, cex=0.3 )
      
      #Add connection lines
      
      map=data.frame(x=object@fdata[object@fdata$Sample=="S5", ]$x_Slide, y=object@fdata[object@fdata$Sample=="S5", ]$y_Slide)
      rownames(map)=object@fdata[object@fdata$Sample=="S5", ]$header_comb
      
      
      quantil_test=0.2
      
      #(1) Rank gene set
      ExpL_r=y1[y1<1.8]
      ExpR_r=y2[y2>quantile(y2,quantil_test)]
      
      ExpR_r=ExpR_r[order(ExpR_r)]
      ExpL_r=ExpL_r[order(ExpL_r)]
      
      df_r=data.frame(ExpR_r,QT=ecdf(ExpR_r)(ExpR_r), row.names = names(ExpR_r))
      df_l=data.frame(ExpL_r,QT=ecdf(ExpL_r)(ExpL_r), row.names = names(ExpL_r))
      
      col=alpha(map2color(df_r$QT, viridis(50)), 0.7)
      
      df_r=df_r[rownames(df_r) %in% object@fdata[object@fdata$Sample=="S5", ]$header_comb, ]
      df_l=df_l[rownames(df_l) %in%object@fdata[object@fdata$Sample=="S5", ]$header_comb,]
      
      
      Coordinate_file_imp=object@fdata
      Coordinate_file_imp$X.1=0
      
      for(i in 1:nrow(df_r)){#Loop for connected lines defined by neares neighbour based on quantil similary
        inp=df_r[i,2]
        x=df_l[,2]
        FROM=rownames(df_r)[i]
        TO=rownames(df_l)[which.min(abs(x - inp))]
        
        start=map[FROM, ]
        end=map[TO, ]
        
        Coordinate_file_imp[FROM, ]$X.1=Coordinate_file_imp[FROM, ]$X.1+1
        Coordinate_file_imp[TO, ]$X.1=Coordinate_file_imp[TO, ]$X.1+1
        
        if(abs(start[1]-end[1])<10 & abs(start[2]-end[2])<10){
          polygon(x=c(start[1], end[1]),y=c(start[2], end[2]),border = col[i], lwd = 4, lty=2)
        }
        
        
        
      }
      
      
      scale_z=scale_z
      
      mat_co=matrix(0, max(Coordinate_file_imp$x_Slide), max(Coordinate_file_imp$y_Slide))
      for(i in 1:nrow(Coordinate_file_imp)){
        mat_co[Coordinate_file_imp$x_Slide[i], Coordinate_file_imp$y_Slide[i] ]=Coordinate_file_imp$X.1[i]+scale_z
      }
      
      out_list=image.smooth(mat_co, theta=theta)
      mat_out=as.matrix(out_list$z)
      mat_out[mat_out<0.5]=NA
      #image(mat_out, col=colorRampPalette(viridis(50))(100), axes=F, xlim=c(-0.5,1.5), ylim=c(-0.5,1.5))
      
      
      
      
      
      
      
    
      
      
      
    }
    
    if(plot_connectivity_Heatmap==T){
      

      
      #Add connection lines
      
      map=data.frame(x=object@fdata[object@fdata$Sample=="S5", ]$x_Slide, y=object@fdata[object@fdata$Sample=="S5", ]$y_Slide)
      rownames(map)=object@fdata[object@fdata$Sample=="S5", ]$header_comb
      
      
      quantil_test=quantil_test
      
      #(1) Rank gene set
      ExpL_r=y1[y1<1.8]
      ExpR_r=y2[y2>quantile(y2,quantil_test)]
      
      ExpR_r=ExpR_r[order(ExpR_r)]
      ExpL_r=ExpL_r[order(ExpL_r)]
      
      df_r=data.frame(ExpR_r,QT=ecdf(ExpR_r)(ExpR_r), row.names = names(ExpR_r))
      df_l=data.frame(ExpL_r,QT=ecdf(ExpL_r)(ExpL_r), row.names = names(ExpL_r))
      
      col=alpha(map2color(df_r$QT, viridis(50)), 0.7)
      
      df_r=df_r[rownames(df_r) %in% object@fdata[object@fdata$Sample=="S5", ]$header_comb, ]
      df_l=df_l[rownames(df_l) %in%object@fdata[object@fdata$Sample=="S5", ]$header_comb,]
      
      
      Coordinate_file_imp=object@fdata
      Coordinate_file_imp$X.1=0
      
      for(i in 1:nrow(df_r)){#Loop for connected lines defined by neares neighbour based on quantil similary
        inp=df_r[i,2]
        x=df_l[,2]
        FROM=rownames(df_r)[i]
        TO=rownames(df_l)[which.min(abs(x - inp))]
        
        start=map[FROM, ]
        end=map[TO, ]
        
        Coordinate_file_imp[FROM, ]$X.1=Coordinate_file_imp[FROM, ]$X.1+1
        Coordinate_file_imp[TO, ]$X.1=Coordinate_file_imp[TO, ]$X.1+1
        
        
        
        
      }
      
      
      scale_z=1
      
      mat_co=matrix(0, max(Coordinate_file_imp$x_Slide), max(Coordinate_file_imp$y_Slide))
      for(i in 1:nrow(Coordinate_file_imp)){
        mat_co[Coordinate_file_imp$x_Slide[i], Coordinate_file_imp$y_Slide[i] ]=Coordinate_file_imp$X.1[i]+scale_z
      }
      
      out_list=image.smooth(mat_co, theta=3)
      mat_out=as.matrix(out_list$z)
      mat_out[mat_out<0.5]=NA
      image(mat_out, col=colorRampPalette(viridis(50))(100), axes=F, xlim=c(-0.5,1.5), ylim=c(-0.5,1.5))
      
      
      
      
      
      
      
      
      
      
      
    }
    
    
    
    
    
    
    
    
    #Map Tcells
    
    #plot(TC@reductions$umap@cell.embeddings, pch=19, col=alpha("grey", 0.2), bty="n", axes=F, xlab="", ylab="")
    #points(TC@reductions$umap@cell.embeddings[names(ExpR[ExpR>quantile(ExpR,quantil_test)]), ],col=viridis(10)[6], pch=19, cex=0.8 )
    
    
    #compare top connected and not connected 
    
    if(Return_vislab==T){
      
      ExpL_r_up=names(y2[y2>quantile(y2,0.975)])
      ExpL_r_down=names(y2[y2<quantile(y2,0.025)])
      
      df_De=data.frame(Sample=c(ExpL_r_up,ExpL_r_down ), row.names = c(ExpL_r_up,ExpL_r_down ))
      df_De$group="up"
      df_De[ExpL_r_down,]$group="down"
      df_De$group=as.factor(df_De$group)
      df_De$treatment=as.factor(df_De$group)
      
      DeSeq_matrix=ds@assays$RNA@counts[, rownames(df_De)]
      dim(DeSeq_matrix)
      
      Data.character=list(ExpID=paste0(Ligant,"_",Receptor[1]), 
                          Researcher="DHH", 
                          Bioinformatic="DHH",
                          Institute="MILO",
                          Date_of_Analysis=Sys.Date(),
                          Datatype="scRNA-seq",
                          Sequencer="Illumina",
                          Species="Human")
      
      source("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab_v1.4.1/pipeline_Create_Vizfile.R")
      
      
      
      pipline_Create_Vizfile(Modus="fromMatrix", 
                             CountMatrix=DeSeq_matrix,
                             f_data=df_De, 
                             Data.character=Data.character, 
                             HOMER=F, 
                             Addgene=F, 
                             norm="vst",
                             minCounts=1,
                             Outputname=Data.character[[1]],
                             export="/Users/HenrikHeiland/Desktop/T-Cell Project/21_new/TC")
      
      
    }
    
    
  }
  
}






plot_PL_Trajectory(es.max,ExpR,ExpL, quantil_test=.95, modus="spatial")




source("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab_v1.4.1/Vis_Lab.R")
Vis_Lab(folder=c("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab_v1.4.1"))


















