##----------------------------------------------------------------------------##
## Server-DimRed
##----------------------------------------------------------------------------##


##----------------------------------------------------------------------------##
## UiOutputs
##----------------------------------------------------------------------------##
output$Choice <- renderUI({
selectInput(inputId="Choice", 
            label="Select Sample that was used:",
            choices = c(sample_data()@slices),
            selected= c(sample_data()@slices)[1],
            multiple = T
)
})


output$Gene <- renderUI({
  selectInput(inputId="Gene", 
              label="Select Gene:",
              choices = c(rownames(sample_data()@seuratobject@assays$RNA@scale.data)),
              selected= c(rownames(sample_data()@seuratobject@assays$RNA@scale.data))[1],
              multiple = T
  )
})


output$GeneSets_P1 <- renderUI({
  selectInput(inputId="GeneSets_P1", 
              label="Seelect a GeneSet to plot:",
              choices = unique(sample_data()@Usesed_GeneSetsets$ont),
              selected= NULL,
              
  )
})

output$Plotfeatures<- renderUI({
  selectInput(inputId="Plotfeatures", 
              label="Select Features to Plot",
              choices = names(sample_data()@seuratobject@meta.data ),
              selected= "Samples",
              
  )
})


##----------------------------------------------------------------------------##
## Functions for Tab
##----------------------------------------------------------------------------##
require(dplyr)
require(DESeq2)
source(paste0(folder,"/ST_Functions/Dim_Red.R"),local = T)





##----------------------------------------------------------------------------##
##  Tab Outputs
##----------------------------------------------------------------------------##
output$Feat <- renderPlot({
        if(is.null(input$Plotfeatures)){Plotfeatures=c("Samples")}else{Plotfeatures=input$Plotfeatures}
  
        TSNE_Groups_DHH(groups=Plotfeatures,
                        f_data_inp = sample_data()@seuratobject@meta.data,
                        tsne=sample_data()@seuratobject@reductions$umap@cell.embeddings,
                        alpha=0.7,
                        pal=brewer.pal(9, "Set1"),
                        cex=0.9)
        


 
})

output$DimRed_Gene <- renderPlot({
  
    print("in Gene Modus")
    print(!is.null(input$Gene))
    if(is.null(input$Gene)){Gene_X=c("GFAP")}else{Gene_X=input$Gene}
    
    TSNE_Genes_DHH(genes=Gene_X,
                   matrix = sample_data()@seuratobject@assays$RNA@scale.data,
                   tsne=sample_data()@seuratobject@reductions$umap@cell.embeddings,
                   alpha=0.7,
                   pal=colorRampPalette(viridis(50), bias=2)(100),
                   cex=0.9)
 
  
  
})

output$DimRed_GS <- renderPlot({
  
      if(is.null(input$GeneSets_P1)){GeneSets_P1=unique(sample_data()@Usesed_GeneSetsets$ont)[100]}else{GeneSets_P1=input$GeneSets_P1}
  
      TSNE_GeneSets_DHH(TestSet=input$GeneSets_P1,
                        matrix = sample_data()@seuratobject@assays$RNA@scale.data,
                        tsne=sample_data()@seuratobject@reductions$umap@cell.embeddings,
                        GeneSetinput=sample_data()@Usesed_GeneSetsets,
                        alpha=0.7,
                        pal=colorRampPalette(viridis(50), bias=2)(100),
                        cex=0.9)
   
  
  
})





# Downloads of Plots  
output$downloadplot_DimRed <- downloadHandler(
  filename = function() { paste('Gene.pdf', sep='') },
  content = function(file) {pdf(file, useDingbats = F)
    if(is.null(input$Gene)){Gene_X=c("GFAP")}else{Gene_X=input$Gene}
     TSNE_Genes_DHH(genes=Gene_X,
                   matrix = sample_data()@seuratobject@assays$RNA@scale.data,
                   tsne=sample_data()@seuratobject@reductions$umap@cell.embeddings,
                   alpha=0.7,
                   pal=colorRampPalette(viridis(50), bias=2)(100),
                   cex=0.9)
    dev.off()},
  contentType = "application/pdf"
)

output$downloadplot_Feat <- downloadHandler(
  filename = function() { paste('Plotfeatures.pdf', sep='') },
  content = function(file) {pdf(file, useDingbats = F)
    if(is.null(input$Plotfeatures)){Plotfeatures=c("Samples")}else{Plotfeatures=input$Plotfeatures}
    
    TSNE_Groups_DHH(groups=Plotfeatures,
                    f_data_inp = sample_data()@seuratobject@meta.data,
                    tsne=sample_data()@seuratobject@reductions$umap@cell.embeddings,
                    alpha=0.7,
                    pal=brewer.pal(9, "Set1"),
                    cex=0.9)
    dev.off()},
  contentType = "application/pdf"
)


output$downloadplot_GS <- downloadHandler(
  filename = function() { paste('Geneset.pdf', sep='') },
  content = function(file) {pdf(file, useDingbats = F)
    
    if(is.null(input$GeneSets_P1)){GeneSets_P1=unique(sample_data()@Usesed_GeneSetsets$ont)[100]}else{GeneSets_P1=input$GeneSets_P1}
    
    TSNE_GeneSets_DHH(TestSet=input$GeneSets_P1,
                      matrix = sample_data()@seuratobject@assays$RNA@scale.data,
                      tsne=sample_data()@seuratobject@reductions$umap@cell.embeddings,
                      GeneSetinput=sample_data()@Usesed_GeneSetsets,
                      alpha=0.7,
                      pal=colorRampPalette(viridis(50), bias=2)(100),
                      cex=0.9)
    dev.off()},
  contentType = "application/pdf"
)
