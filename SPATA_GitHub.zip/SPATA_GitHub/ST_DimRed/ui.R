
##----------------------------------------------------------------------------##
## UI-Dimred
##----------------------------------------------------------------------------##

tab_DimRed <- tabItem(
  tabName = "DimRed",

  
  fluidRow(
    
    
    dropdownButton(
      
      inputId = "Options1",
      tags$h2("Options"),
      tags$br(),
      tags$p("Select Paarameter for 2D dimensional reduction plots"),
      
      circle = F, 
      status = "info", 
      icon = icon("gear"), 
      width = "400px",
      tooltip = tooltipOptions(title = "Change Options Plot !"),
      
      
      #### Checkbox for Groups
      uiOutput("Choice"),
      #uiOutput("Gene"),
      #uiOutput("GeneSets_P1"),
      uiOutput("Plotfeatures")
      
      
      
      
    ),
    
    #Plot TabBox
    tabBox(
      title = "Dimensional Rediction (UMAP)", 
      id="Plots",
      width = 12,
      height="800px",
      tabPanel(title="Features",
               downloadLink("downloadplot_Feat", "PDF"),
               plotOutput("Feat", width = "700px", height = "700px"))
      
      
      #tabPanel(title="Genes",
      #         downloadLink("downloadplot_DimRed", "PDF"),
      #         plotOutput("DimRed_Gene",width = "700px", height = "700px")),
      #tabPanel(title="Genesets",
      #         downloadLink("downloadplot_GS", "PDF"),
      #         plotOutput("DimRed_GS",width = "700px", height = "700px"))
      #        

      
    ),
   
    ),
  )

