##----------------------------------------------------------------------------##
## Server-Load Data
##----------------------------------------------------------------------------##
# number of samples
output$load_data_number_of_cells <- renderValueBox({
  valueBox(
    value = if ( !is.null(sample_data()) ) formatC(nrow(sample_data()@fdata), format = "f", big.mark = ",", digits = 0) else 0,
    subtitle = "Number of Spots",
    color = "light-blue"
  )
})

output$load_data_number_of_Groups <- renderValueBox({
  valueBox(
    value = if ( !is.null(sample_data()) ) formatC(length(unique(sample_data()@fdata$Sample)), format = "f", big.mark = ",", digits = 0) else 0,
    subtitle = "Number of groups",
    color = "light-blue"
  )
})

output$load_data_number_of_Batches <- renderValueBox({
  valueBox(
    value = if ( !is.null(sample_data()) ) formatC(length(unique(sample_data()@fdata$Cluster)), format = "f", big.mark = ",", digits = 0) else 0,
    subtitle = "Number of Cluster",
    color = "light-blue"
  )
})

  




