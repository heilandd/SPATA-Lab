SPATA <- function(folder=getwd()){
  
  source(paste0(folder,"/Package_check.R"))
  #Check installed packges
  checkP_DHH(readRDS(paste0(folder,"/packages.RDS")))
  
  
  library(shinyWidgets)
  library(shinydashboard)
  library(shiny)
  library(shinydashboardPlus)
  library(shinycssloaders)
  library(plotly)
  library(dashboardthemes)
  library(RColorBrewer)
  library(shinybusy)
  library(pheatmap)
  library(RColorBrewer)
  library(viridis)
  library(scales)
  library(graphics)
  
  ################## Sources of shiny parts of the App

  ##--------------------------------------------------------------------------##
  ## Load server and UI functions.
  ##--------------------------------------------------------------------------##
  
  
  setwd(folder)
  assign("folder", value =folder , envir = globalenv())
  runApp(paste0(folder,"/ST_App"),launch.browser =  T)
  
}
SPATA()  






