##----------------------------------------------------------------------------##
## Server-State_plots
##----------------------------------------------------------------------------##


##----------------------------------------------------------------------------##
## uiOutput
##----------------------------------------------------------------------------##


output$GS1_ST=renderUI({
  selectInput(inputId="GS1_ST", 
              label="Select Pathway 1:",
              choices = c(as.character(unique(sample_data()@Usesed_GeneSetsets$ont))),
              selected= c(as.character(unique(sample_data()@Usesed_GeneSetsets$ont)))[1]
  )
})

output$GS2_ST=renderUI({
  selectInput(inputId="GS2_ST", 
              label="Select Pathway 2:",
              choices = c(as.character(unique(sample_data()@Usesed_GeneSetsets$ont))),
              selected= c(as.character(unique(sample_data()@Usesed_GeneSetsets$ont)))[2]
  )
})

output$GS3_ST=renderUI({
  selectInput(inputId="GS3_ST", 
              label="Select Pathway 3:",
              choices = c(as.character(unique(sample_data()@Usesed_GeneSetsets$ont))),
              selected= c(as.character(unique(sample_data()@Usesed_GeneSetsets$ont)))[3]
  )
})

output$GS4_ST=renderUI({
  selectInput(inputId="GS4_ST", 
              label="Select Pathway 4:",
              choices = c(as.character(unique(sample_data()@Usesed_GeneSetsets$ont))),
              selected= c(as.character(unique(sample_data()@Usesed_GeneSetsets$ont)))[4]
  )
})


output$col_enrichmnet_ST=renderUI({
  selectInput(inputId="col_enrichmnet_ST", 
              label="Select Pathway to Color:",
              choices = c(NA,as.character(unique(sample_data()@Usesed_GeneSetsets$ont))),
              selected= c(NA)
  )
})


output$Select_Gene_ST=renderUI({
  selectInput(inputId="Select_Gene_ST", 
              label="Select Gene",
              choices = c(NA,rownames(sample_data()@seuratobject@assays$RNA@scale.data)),
              selected= c(NA,rownames(sample_data()@seuratobject@assays$RNA@scale.data))[1],
              multiple = TRUE
  )
})

output$select_pal_ST=renderUI({
  selectInput(inputId="select_pal_ST", 
              label="Color Set",
              choices = c("RdYlBu", "Reds", "Blues", "Oranges", "Purples","viridis", "inferno"),
              selected= "Reds",
              multiple = F
  )
})

output$select_Treatmant_col=renderUI({
  selectInput(inputId="select_Treatmant_col", 
              label="Features: ",
              choices = c(NA,names(sample_data()@seuratobject@meta.data)),
              selected= c(NA,names(sample_data()@seuratobject@meta.data))[1],
              multiple = F
  )
})

output$xscale=renderUI({
  sliderInput("xscale", "Scale Axis:", 0, 20, 1, step=0.01)
})
output$Cex_Points=renderUI({
  sliderInput("Cex_Points", "Scale Points:", 0, 20, 1, step=0.01)
})
output$inp_quantile=renderUI({
  sliderInput("inp_quantile", "Scale Quantile:", 0, 1, c(0.025, 0.975), step=0.01)
})


output$Text_Plot=renderUI({
  sliderInput("Text_Plot", "Scale Lables:", 0, 1, 0.5, step=0.01)
})




##----------------------------------------------------------------------------##
## Functions for Tab
##----------------------------------------------------------------------------##
require(dplyr)
require(DESeq2)
require(GSVA)
source(paste0(folder,"/ST_Functions/ST_SC_Metaplot_4D_DASH.R"),local = T)









##----------------------------------------------------------------------------##
##  Tab Outputs
##----------------------------------------------------------------------------##



output$Scatter_ST <- renderPlot({
  
  
  if(is.null(input$GS1_ST)){GS1_ST="MILO_A1"}else{GS1_ST=input$GS1_ST}
  if(is.null(input$GS2_ST)){GS2_ST="MILO_A2"}else{GS2_ST=input$GS2_ST}
  if(is.null(input$GS3_ST)){GS3_ST=("MILO_fetal")}else{GS3_ST=(input$GS3_ST)}
  if(is.null(input$GS4_ST)){GS4_ST=("MILO_adult")}else{GS4_ST=(input$GS4_ST)}
  
  if(is.null(input$col_enrichmnet_ST)){col_enrichmnet_ST=("Neftel_G2.M")}else{col_enrichmnet_ST=(input$col_enrichmnet_ST)}
  if(is.null(input$Select_Gene_ST)){Select_Gene_ST=(NA)}else{Select_Gene_ST=(input$Select_Gene_ST)}
  if(is.null(input$select_Treatmant_col)){select_Treatmant_col=(NA)}else{select_Treatmant_col=(input$select_Treatmant_col)}
  if(is.null(input$select_pal_ST)){select_pal_ST=("inferno")}else{select_pal_ST=(input$select_pal_ST)}
  
  if(is.null(input$xscale)){xscale=(3.5)}else{xscale=(input$xscale)}
  if(is.null(input$Cex_Points)){Cex_Points=(1.8)}else{Cex_Points=(input$Cex_Points)}
  if(is.null(input$inp_quantile)){inp_quantile=(c(0.025, 0.975))}else{inp_quantile=(input$inp_quantile)}
  if(is.null(input$Text_Plot)){Text_Plot=(0.8)}else{Text_Plot=(input$Text_Plot)}

  
  
  
  
  
  if(select_pal_ST=="RdYlBu"){pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")))(10)}
  if(select_pal_ST=="viridis"){pal=viridis(50)}
  if(select_pal_ST=="inferno"){pal=inferno(50)}
  if(select_pal_ST=="Blues"){pal=colorRampPalette((brewer.pal(9, "Blues")))(10)}
  if(select_pal_ST=="Reds"){pal=colorRampPalette((brewer.pal(9, "Reds")))(10)}
  if(select_pal_ST=="Oranges"){pal=colorRampPalette((brewer.pal(9, "Oranges")))(10)}
  if(select_pal_ST=="Purples"){pal=colorRampPalette((brewer.pal(9, "Purples")))(10)}
  
  
  print(c(GS1_ST,GS2_ST,GS3_ST,GS4_ST))
  
  ST_SC_Metaplot_4D_DASH(object=sample_data(), 
                         Geneset=c(GS1_ST,GS2_ST,GS3_ST,GS4_ST),
                         xscale=xscale,
                         yscale=xscale, 
                         cex=Cex_Points, 
                         col_samples=select_Treatmant_col,
                         pal=pal, 
                         genes=Select_Gene_ST,
                         signature=col_enrichmnet_ST,
                         Plot=T,
                         inp_quantile=inp_quantile,
                         cex_GS=Text_Plot)

 
})




# Downloads of Plots  
output$downloadplot_Scatter_ST <- downloadHandler(
  filename = function() { paste("Scatter", input$GS1_ST,"_",input$GS2_ST,"_",input$GS3_ST,"_",input$GS4_ST, '.pdf', sep='') },
  content = function(file) {pdf(file, useDingbats = F)
    
    
    
    if(is.null(input$GS1_ST)){GS1_ST="MILO_A1"}else{GS1_ST=input$GS1_ST}
    if(is.null(input$GS2_ST)){GS2_ST="MILO_A2"}else{GS2_ST=input$GS2_ST}
    if(is.null(input$GS3_ST)){GS3_ST=("MILO_fetal")}else{GS3_ST=(input$GS3_ST)}
    if(is.null(input$GS4_ST)){GS4_ST=("MILO_adult")}else{GS4_ST=(input$GS4_ST)}
    
    if(is.null(input$col_enrichmnet_ST)){col_enrichmnet_ST=("Neftel_G2.M")}else{col_enrichmnet_ST=(input$col_enrichmnet_ST)}
    if(is.null(input$Select_Gene_ST)){Select_Gene_ST=(NA)}else{Select_Gene_ST=(input$Select_Gene_ST)}
    if(is.null(input$select_Treatmant_col)){select_Treatmant_col=(NA)}else{select_Treatmant_col=(input$select_Treatmant_col)}
    if(is.null(input$select_pal_ST)){select_pal_ST=("inferno")}else{select_pal_ST=(input$select_pal_ST)}
    
    if(is.null(input$xscale)){xscale=(3.5)}else{xscale=(input$xscale)}
    if(is.null(input$Cex_Points)){Cex_Points=(1.8)}else{Cex_Points=(input$Cex_Points)}
    if(is.null(input$inp_quantile)){inp_quantile=(c(0.025, 0.975))}else{inp_quantile=(input$inp_quantile)}
    if(is.null(input$Text_Plot)){Text_Plot=(0.8)}else{Text_Plot=(input$Text_Plot)}
    
    
    
    
    
    
    if(select_pal_ST=="RdYlBu"){pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")))(10)}
    if(select_pal_ST=="viridis"){pal=viridis(50)}
    if(select_pal_ST=="inferno"){pal=inferno(50)}
    if(select_pal_ST=="Blues"){pal=colorRampPalette((brewer.pal(9, "Blues")))(10)}
    if(select_pal_ST=="Reds"){pal=colorRampPalette((brewer.pal(9, "Reds")))(10)}
    if(select_pal_ST=="Oranges"){pal=colorRampPalette((brewer.pal(9, "Oranges")))(10)}
    if(select_pal_ST=="Purples"){pal=colorRampPalette((brewer.pal(9, "Purples")))(10)}
    
    
    print(c(GS1_ST,GS2_ST,GS3_ST,GS4_ST))
    
    ST_SC_Metaplot_4D_DASH(object=sample_data(), 
                           Geneset=c(GS1_ST,GS2_ST,GS3_ST,GS4_ST),
                           xscale=xscale,
                           yscale=xscale, 
                           cex=Cex_Points, 
                           col_samples=select_Treatmant_col,
                           pal=pal, 
                           genes=Select_Gene_ST,
                           signature=col_enrichmnet_ST,
                           Plot=T,
                           inp_quantile=inp_quantile,
                           cex_GS=Text_Plot)
    
    
    dev.off()},
  contentType = "application/pdf"
)

