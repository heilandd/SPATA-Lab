
##----------------------------------------------------------------------------##
## UI-State_Plots
##----------------------------------------------------------------------------##

tab_State_Plots <- tabItem(
  tabName = "StatePlots",

  fluidRow(
    tags$p("First select parameters of the state plot: Select the four states of interest (pathways)"),
    
    dropdownButton(
      
      inputId = "Options1",
      tags$h2("Options"),
      tags$br(),
      tags$p("Select Paarameter for state plots"),
      
      circle = F, 
      status = "info", 
      icon = icon("gear"), 
      width = "600px",
      tooltip = tooltipOptions(title = "Change Options Plot !"),
      
      
      #### Checkbox for Groups
      #### Checkbox for Groups
      tabBox(width = "500px",
      tabPanel(title="Pathways",
               uiOutput("GS1_ST"),
               uiOutput("GS2_ST"),
               uiOutput("GS3_ST"),
               uiOutput("GS4_ST")
               ),
      tabPanel(title="Parameters",
               uiOutput("xscale"),
               uiOutput("Cex_Points"),
               uiOutput("inp_quantile"),
               uiOutput("Text_Plot")
      ),
      tabPanel(title="Colors",
               uiOutput("col_enrichmnet_ST"),
               #uiOutput("Select_Gene_ST"),
               uiOutput("select_Treatmant_col"),
               uiOutput("select_pal_ST")
      )
      )
      
      
      
      
      
      
    ),
    
    #Plot TabBox
    tabBox(
      title = "", 
      id="Plots_Scatter",
      height = 10, width = "800px",
      
      tabPanel(title="State Scatter",
               downloadLink("downloadplot_Scatter_ST", "PDF"),
               withSpinner(plotOutput("Scatter_ST", height = "700px", width = "700px")))

      
    ),
    


    
    ),
  )


