
##----------------------------------------------------------------------------##
## UI-SPATIAL
##----------------------------------------------------------------------------##

tab_Spatial <- tabItem(
  tabName = "Spatial",

  fluidRow(
    uiOutput("Options_Spatial"),
    
    #Plot TabBox
    tabBox(
      title = "Spatial Maps", 
      id="Spatial",
      width = 10,
      height="800px",
      
      
      tabPanel(title="Spatial Plots",
               downloadLink("downloadplot_Spatial_Plot", "PDF"),
               withSpinner(plotOutput("Spatial_Plot",width = "700px", height = "700px"))
               
               ),
      tabPanel(title="Surface Plots",
               downloadLink("downloadplot_Surface", "PDF"),
               plotlyOutput("Surface")
               )
      
      
      
      
      
    ),

    
    ),
  )


