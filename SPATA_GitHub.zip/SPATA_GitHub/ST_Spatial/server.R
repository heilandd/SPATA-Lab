##----------------------------------------------------------------------------##
## Server-SPATIAL
##----------------------------------------------------------------------------##


##----------------------------------------------------------------------------##
## UiOutputs
##----------------------------------------------------------------------------##


reactiveOptions <- reactiveValues(data=list( # Input all options needed
                                            Slide="S5",
                                            Modus="GeneSets",
                                            Input="Neftel_Mes_Comb",
                                            Plot_Type="Smooth-Matrix",
                                            Pal_input="inferno",
                                            Threshold=0,
                                            Theta=1,
                                            polygon=T,
                                            Scale_X=0.63
                                            
                                            ))



dataModalx <- function(failed = FALSE) {
  modalDialog(
    title = "Option Parameters for Spatial Maps",
    
    #Add Option Parameters:
    
    
    selectInput(inputId="Choice1", 
                label="Select Sample that was used:",
                choices = c(sample_data()@slices),
                selected= reactiveOptions$data[["Slide"]],
                multiple = F
    ),
    selectInput(inputId="Modus", 
                label="Select Modus:",
                choices = c("Cluster", "Genes", "GeneSets"),
                selected= reactiveOptions$data[["Modus"]],
                
    ),
    
    
    selectInput(inputId="Input", 
                label="Select Input:",
                choices = {
                  if(reactiveOptions$data[["Modus"]]=="Cluster"){names(sample_data()@seuratobject@meta.data[, c("Samples", "seurat_clusters")])}else
                    
                    if(reactiveOptions$data[["Modus"]]=="GeneSets"){unique(sample_data()@Usesed_GeneSetsets$ont)}else
                      
                      if(reactiveOptions$data[["Modus"]]=="Genes"){c(rownames(sample_data()@seuratobject@assays$RNA@scale.data))}
                  
                },
                
                selected= reactiveOptions$data[["Input"]],
                  
                multiple = {
                  if(reactiveOptions$data[["Modus"]]=="Cluster"){FALSE}else
                    
                    if(reactiveOptions$data[["Modus"]]=="GeneSets"){TRUE}else
                      
                      if(reactiveOptions$data[["Modus"]]=="Genes"){TRUE}
                  
                }
    ),
    
    
    selectInput(inputId="type_plot", 
                label="Select Type of Plots:",
                choices = c("points", "Smooth-Matrix"),
                selected= reactiveOptions$data[["Plot_Type"]] ,
                
    ),
    
    selectInput(inputId="pal", 
                label="Color Set",
                choices = c("RdYlBu","RdBu", "Reds", "Blues", "Oranges", "Purples","viridis","inferno"),
                selected= reactiveOptions$data[["Pal_input"]],
                multiple = F
    ),
    
    sliderInput("Threshold", "Threshold:", -0.2, 0.5, reactiveOptions$data[["Threshold"]], step=0.01),
    sliderInput("Scale_X", "Baseline Correction:", 0, 3, reactiveOptions$data[["Scale_X"]], step=0.01),
    sliderInput("Theta", "Kernel:", 0.1, 6, reactiveOptions$data[["Theta"]], step=0.01),
    checkboxInput("polygon", "Add Polygon", reactiveOptions$data[["polygon"]]),
    
    
    
    footer = tagList(
      modalButton("Spatial_Cancel"),
      actionButton("Spatial_ok", "Save Changes")
    )
  )
}

output$Options_Spatial=renderUI({
  actionButton("Options_Spatial", "Options")
})
observeEvent(input$Options_Spatial, {
  showModal(dataModalx())
})



observeEvent(input$Spatial_ok, {
  reactiveOptions$data[["Slide"]] <-      input$Choice1
  reactiveOptions$data[["Modus"]] <-      input$Modus
  reactiveOptions$data[["Input"]] <-      input$Input
  reactiveOptions$data[["Plot_Type"]] <-  input$type_plot
  reactiveOptions$data[["Pal_input"]] <-  input$pal
  reactiveOptions$data[["Threshold"]]<-   input$Threshold
  reactiveOptions$data[["Theta"]]<-       input$Theta
  reactiveOptions$data[["polygon"]] <-    input$polygon
  reactiveOptions$data[["Scale_X"]]<-     input$Scale_X
  
  print(reactiveOptions$data)
  
  removeModal()
  
})




color_pal=reactive({
  
  col=reactiveOptions$data[["Pal_input"]]
  
  if(col=="RdYlBu"){pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")))(50)}
  if(col=="inferno"){pal=inferno(50)}
  if(col=="viridis"){pal=viridis(50)}
  if(col=="Blues"){pal=colorRampPalette((brewer.pal(9, "Blues")))(50)}
  if(col=="Reds"){pal=colorRampPalette((brewer.pal(9, "Reds")))(50)}
  if(col=="Oranges"){pal=colorRampPalette((brewer.pal(9, "Oranges")))(50)}
  if(col=="Purples"){pal=colorRampPalette((brewer.pal(9, "Purples")))(50)}
  if(col=="RdBu"){pal=rev(colorRampPalette((brewer.pal(9, "RdBu")))(50))}
  
  return(pal)
})







##----------------------------------------------------------------------------##
## Functions for Tab
##----------------------------------------------------------------------------##
require(dplyr)
require(DESeq2)
source(paste0(folder,"/ST_Functions/ST_Img_DHH.R"),local = T)
source(paste0(folder,"/ST_Functions/ST_Img_DHH_surface.R"),local = T)
source(paste0(folder,"/ST_Functions/ST_Img_DHH_multiple.R"),local = T)
source(paste0(folder,"/ST_Functions/ST_Img_DHH_surface_multiple.R"),local = T)
source(paste0(folder,"/ST_Functions/ST_Img_DHH_surface_classic.R"),local = T)

##----------------------------------------------------------------------------##
##  Tab Outputs
##----------------------------------------------------------------------------##
output$Spatial_Plot <- renderPlot({
  print(color_pal())
  print(reactiveOptions$data)
  
  if(reactiveOptions$data[["Modus"]]=="GeneSets" & length(reactiveOptions$data[["Input"]])>1){
    ST_Img_DHH_multiple(object=sample_data(),
               sample_to_print=reactiveOptions$data[["Slide"]],
               input=reactiveOptions$data[["Input"]],
               modus=reactiveOptions$data[["Modus"]],
               multiple_gene_ST="mean", 
               TXT=NA,
               BG=.8,
               threshold=reactiveOptions$data[["Threshold"]],
               bty="n",
               cex=0.8,
               pal={ if(reactiveOptions$data[["Modus"]]=="Cluster"){brewer.pal(9, "Set1")}else{brewer.pal(6, "Reds")} } )
  }else{
  
  if(reactiveOptions$data[["Plot_Type"]]=="points"){
    ST_Img_DHH(object=sample_data(),
               sample_to_print=reactiveOptions$data[["Slide"]],
               input=reactiveOptions$data[["Input"]],
               modus=reactiveOptions$data[["Modus"]],
               multiple_gene_ST="mean", 
               TXT=NA,
               BG=.8,
               threshold=reactiveOptions$data[["Threshold"]],
               bty="n",
               cex=0.8,
               pal={ if(reactiveOptions$data[["Modus"]]=="Cluster"){brewer.pal(9, "Set1")}else{brewer.pal(6, "Reds")} } )
  }else{
    
    ST_Img_DHH_surface_classic(object=sample_data(),
               sample_to_print=reactiveOptions$data[["Slide"]],
               input=reactiveOptions$data[["Input"]],
               modus=reactiveOptions$data[["Modus"]],
               scale_z=reactiveOptions$data[["Scale_X"]],
               theta=reactiveOptions$data[["Theta"]],
               multiple_gene_ST="mean", 
               TXT=NA,
               BG=.8,
               threshold=reactiveOptions$data[["Threshold"]],
               Add_polygon=reactiveOptions$data[["polygon"]],
               bty="n",
               cex=0.8,
               pal=color_pal() )
    
    
  }
  
}
 
})


  
  


library(plotly)
output$Surface <- renderPlotly({
  
  if(reactiveOptions$data[["Modus"]]=="GeneSets" & length(reactiveOptions$data[["Input"]])>1){
    
    ST_Img_DHH_surface_multiple(object=sample_data(),
                       sample_to_print=reactiveOptions$data[["Slide"]],
                       input=reactiveOptions$data[["Input"]],
                       modus=reactiveOptions$data[["Modus"]],
                       scale_z=reactiveOptions$data[["Scale_X"]],
                       theta=reactiveOptions$data[["Theta"]],
                       multiple_gene_ST="mean", 
                       TXT=NA,
                       BG=.8,
                       threshold=reactiveOptions$data[["Threshold"]],
                       bty="n",
                       cex=0.8,
                       pal={ if(input$Modus=="Cluster"){brewer.pal(9, "Set1")}else{brewer.pal(6, "Reds")} } )
  }else{
    
  ST_Img_DHH_surface(object=sample_data(),
             sample_to_print=reactiveOptions$data[["Slide"]],
             input=reactiveOptions$data[["Input"]],
             modus=reactiveOptions$data[["Modus"]],
             scale_z=reactiveOptions$data[["Scale_X"]],
             theta=reactiveOptions$data[["Theta"]],
             multiple_gene_ST="mean", 
             TXT=NA,
             BG=.8,
             threshold=reactiveOptions$data[["Threshold"]],
             bty="n",
             cex=0.8,
             pal={ if(reactiveOptions$data[["Modus"]]=="Cluster"){brewer.pal(9, "Set1")}else{brewer.pal(6, "Reds")} } )
  }
})


# Downloads of Plots  
output$downloadplot_Spatial_Plot <- downloadHandler(
  filename = function() { paste(reactiveOptions$data[["Input"]], '.pdf', sep='') },
  content = function(file) {pdf(file, useDingbats = F)
    
    print(color_pal())
    
    if(reactiveOptions$data[["Modus"]]=="GeneSets" & length(reactiveOptions$data[["Input"]])>1){
      ST_Img_DHH_multiple(object=sample_data(),
                          sample_to_print=reactiveOptions$data[["Slide"]],
                          input=reactiveOptions$data[["Input"]],
                          modus=reactiveOptions$data[["Modus"]],
                          multiple_gene_ST="mean", 
                          TXT=NA,
                          BG=.8,
                          threshold=reactiveOptions$data[["Threshold"]],
                          bty="n",
                          cex=0.8,
                          pal={ if(reactiveOptions$data[["Modus"]]=="Cluster"){brewer.pal(9, "Set1")}else{brewer.pal(6, "Reds")} } )
    }else{
      
      if(reactiveOptions$data[["Plot_Type"]]=="points"){
        ST_Img_DHH(object=sample_data(),
                   sample_to_print=reactiveOptions$data[["Slide"]],
                   input=reactiveOptions$data[["Input"]],
                   modus=reactiveOptions$data[["Modus"]],
                   multiple_gene_ST="mean", 
                   TXT=NA,
                   BG=.8,
                   threshold=reactiveOptions$data[["Threshold"]],
                   bty="n",
                   cex=0.8,
                   pal={ if(reactiveOptions$data[["Modus"]]=="Cluster"){brewer.pal(9, "Set1")}else{brewer.pal(6, "Reds")} } )
      }else{
        
        ST_Img_DHH_surface_classic(object=sample_data(),
                                   sample_to_print=reactiveOptions$data[["Slide"]],
                                   input=reactiveOptions$data[["Input"]],
                                   modus=reactiveOptions$data[["Modus"]],
                                   scale_z=reactiveOptions$data[["Scale_X"]],
                                   theta=reactiveOptions$data[["Theta"]],
                                   multiple_gene_ST="mean", 
                                   TXT=NA,
                                   BG=.8,
                                   threshold=reactiveOptions$data[["Threshold"]],
                                   bty="n",
                                   cex=0.8,
                                   Add_polygon=reactiveOptions$data[["polygon"]],
                                   pal=color_pal() )
        
        
      }
      
    }
    
    
    
    dev.off()},
  contentType = "application/pdf"
)



output$downloadplot_Surface <- downloadHandler(
  filename = function() { paste(reactiveOptions$data[["Input"]], '.pdf', sep='') },
  content = function(file) {
    plotly_IMAGE(ST_Img_DHH_surface(object=sample_data(),
                                    sample_to_print=reactiveOptions$data[["Slide"]],
                                    input=reactiveOptions$data[["Input"]],
                                    modus=reactiveOptions$data[["Modus"]],
                                    scale_z=reactiveOptions$data[["Scale_X"]],
                                    theta=reactiveOptions$data[["Theta"]],
                                    multiple_gene_ST="mean", 
                                    TXT=NA,
                                    BG=.8,
                                    threshold=reactiveOptions$data[["Threshold"]],
                                    bty="n",
                                    cex=0.8,
                                    pal={ if(reactiveOptions$data[["Modus"]]=="Cluster"){brewer.pal(9, "Set1")}else{brewer.pal(6, "Reds")} } )
                 
                 , format = "pdf",  out_file = file)

    
    
  },
  contentType = "application/pdf"
)


